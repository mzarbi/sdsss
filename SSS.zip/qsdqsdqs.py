def extract_first_and_last(number_list):
    # Helper function to convert and concatenate numbers
    def convert_to_float(segment):
        return float(''.join(segment).replace(',', '.'))

    # Extract the first segment
    first_segment = []
    while number_list:
        first_segment.append(number_list.pop(0))
        if ',' in first_segment[-1]:
            break
    first_number = convert_to_float(first_segment)

    last_segment = []
    pops1 = number_list.pop(-1)

    while number_list:
        pops = number_list.pop(-1)
        if len(last_segment) == 0:
            last_segment.insert(0, pops)
            continue
        if ',' in pops or '0' == pops[-1]:
            break
        else:
            last_segment.insert(0, pops)
    number_list.append(pops)
    last_segment.append(pops1)

    middle_number = convert_to_float(number_list)
    last_number = convert_to_float(last_segment)

    return [first_number, middle_number, last_number]

def process_number_lists(number_lists):
    return [extract_first_and_last(num_list) for num_list in number_lists]

# Example usage
number_lists = [
    ['45', '142', '620,00', '0', '45', '142', '620,00'],
    ['45', '142', '620,00', '4', '142', '142', '620,00', '45', '142', '620,00']
]

processed_lists = process_number_lists(number_lists)
for processed_list in processed_lists:
    print(processed_list)
