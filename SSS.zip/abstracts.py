import ast
import re


class SRMSParser:
    def configs(self):
        return {}

    def bundle(self):
        return {}

    def apply_bundle(self, line):
        for k, v in self.bundle().items():
            line = line.replace(k, v)
        return line
    def split_list_by_indices(self, input_list, indices):
        indices = sorted(indices)
        result = []
        previous_index = 0

        for index in indices:
            result.append(input_list[previous_index:index])
            previous_index = index

        result.append(input_list[previous_index:])
        return result

    def process_hierarchy(self, dc, hierarchy, current_tag, path=[]):
        result = []
        for idx, entry in enumerate(dc):
            if entry["TAG"] == current_tag:
                result.append(idx)

        split_lists = self.split_list_by_indices(dc, result)[1:]
        processed = []

        for sublist in split_lists:
            first_element = sublist[0]
            rest = sublist[1:]
            new_path = path + [first_element]
            processed.append(new_path)
            for tag in hierarchy.get(first_element['TAG'], []):
                processed.extend(self.process_hierarchy(rest, hierarchy, tag, new_path))
        return processed

    def is_subset(self, smaller, larger):
        return all(item in larger.items() for item in smaller.items())

    def simplify_dicts(self, dicts):
        simplified = []

        for d in dicts:
            is_contained = any(self.is_subset(d, s) for s in simplified)
            if not is_contained:
                simplified = [s for s in simplified if not self.is_subset(s, d)]
                simplified.append(d)

        return simplified

    def merge_and_simplify_dicts(self, dc, hierarchy, initial_tag):
        merged_lists = self.process_hierarchy(dc, hierarchy, initial_tag)
        merged_dicts = []

        for path in merged_lists:
            merged_dict = {}
            for element in path:
                merged_dict.update(element)
            del merged_dict['TAG']
            merged_dicts.append(merged_dict)

        return self.simplify_dicts(merged_dicts)
    def sanitize_key(self, key):
        return ''.join('_' if not char.isalnum() else char for char in key).strip('_')

    def string_similarity_measure(self, string, required_parts, regex_patterns, min_length=None, max_length=None,
                                  case_insensitive=False, include_whitespace=False, detailed_report=False,
                                  weights=None):
        # Handle case sensitivity
        if case_insensitive:
            string = string.lower()
            required_parts = {k.lower(): v for k, v in required_parts.items()}
            regex_patterns = [pattern.lower() for pattern in regex_patterns]

        # Handle whitespace inclusion
        if not include_whitespace:
            effective_string = re.sub(r'\s+', '', string)
        else:
            effective_string = string

        effective_length = len(effective_string)

        # Check if the effective length is within the specified constraints
        if (min_length is not None and effective_length < min_length) or (
                max_length is not None and effective_length > max_length):
            if detailed_report:
                return {"similarity_score": 0.0, "reason": "Length constraint not met"}
            return 0.0

        # Check if all required parts are in the string with the specified constraints
        part_score = 1.0
        for part, constraints in required_parts.items():
            min_occurrences = constraints.get('min', 1)
            max_occurrences = constraints.get('max', float('inf'))

            occurrences = len(re.findall(part, string))

            if occurrences < min_occurrences or occurrences > max_occurrences:
                if detailed_report:
                    return {"similarity_score": 0.0, "reason": f"Part '{part}' occurrence constraint not met"}
                return 0.0

        # Initialize the count of matched regex patterns
        matched_count = 0
        matched_patterns = []

        # Compile and apply each regex pattern
        for pattern in regex_patterns:
            regex = re.compile(pattern)
            if regex.search(string):
                matched_count += 1
                matched_patterns.append(pattern)

        # Calculate the similarity score for patterns
        total_patterns = len(regex_patterns)
        pattern_score = matched_count / total_patterns if total_patterns > 0 else 1.0

        # Apply weights if provided
        if weights:
            part_weight = weights.get('parts', 1)
            pattern_weight = weights.get('patterns', 1)
            total_weight = part_weight + pattern_weight
            similarity_score = (part_weight * part_score + pattern_weight * pattern_score) / total_weight
        else:
            similarity_score = pattern_score

        if detailed_report:
            return {
                "similarity_score": similarity_score,
                "matched_patterns": matched_patterns,
                "total_patterns": total_patterns
            }

        return similarity_score

    def clean_string(self, s, iteration=20):
        for tmp in range(iteration):
            s = s.replace("  ", " ")
        return s
