import json
import re
from datetime import datetime
from abstracts import SRMSParser
import pandas as pd


class EA0803(SRMSParser):
    def bundle(self):
        return {
            "CLIENT ACCOUNT OPENING AND MODIFICATION": "",
            "APERTURA Y MODIFICACION DE CUENTA DE CLIENTELA": "",
            "******* ADDRESSEE(S) ********": "",
            "**": "",
            "DESTINATARIO(S)": "",
            "BANCO": "BANK",
            "PAG.": "PAGE",
            "LISTADO": "REPORT",
            "COMERCIAL CORREDOR": "ACCOUNT OFFICER",
            "FECHA/HORA PROCESAMTO": "PROCESSING DATE/TIME",
            "OFICINA": "BRANCH",
            "COMERCIAL": "ACT.OFFICER",
            "TIPO DE CUENTA": "ACCOUNT TYPE",
            "FECHA DE APERTURA": "OPENING DATE",
            "FECHA DE ORIGEN": "ORIGINAL DATE",
            "MOTIVO APERTURA": "OPENING ORIGIN",
            "DURACION": "DURATION",
            "VENCIMIENTO": "EXPIRY",
            "SUB-RUBRICA": "SUBCODE",
            "FECHA DE ENTREGA CONTRATO": "AGREEMENT DELIVERY DATE",
            "FECHA DE FIRMA CONTRATO": "AGREEMENT SIGNATURE DATE",
            "NUMERO DE VERSION CONTRATO": "AGREEMENT VERSION NUMBER",
            "REFINANCIABLE": "REFINANCEABLE",
            "COD. PLAN CONTABLE": "ACTG.STRUCTURE CODE",
            "ENTIDAD": "ENTITY",
            "FECHA DE OPERACION": "OPERATION DATE",
            "REFERENCIA DE OPERACION": "OPERATION REFERENCE",
            "NUMERO DE OPERACION": "OPERATION NUMBER",
            "NUMERO DE ENTIDAD": "ENTITY NUMBER",
            "IMPORTE": "AMOUNT",
            "TIPO": "TYPE",
            "MONEDA": "CURRENCY"
        }

    @property
    def hierarchy(self):
        return {
            "": ["JENTACULAR"],
            "JENTACULAR": ["THERION"],
            "THERION": ["DEINGLUCK"],
        }
    def empty(self, line):
        return {}

    def empty_converter(self, dc):
        return dc

    def configs(self):
        return {
            "JENTACULAR": {
                "required_parts": {
                    "BANK": {"min": 1, "max": 2},
                    "REPORT": {"min": 1, "max": 2},
                    "PROCESSING DATE/TIME": {"min": 1, "max": 1},
                    "FOLIO": {"min": 1, "max": 2},
                    "ARCH": {"min": 1, "max": 2},
                },
                "regex_patterns": [
                    r"BANK\s*:\s*\d{2}\s+\w+",
                    r"REPORT\s*:\s*",
                    r"PROCESSING\s+DATE/TIME\s*:\s*\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}",
                    r"FOLIO\s*:\s*\d+",
                    r"ARCH\s+:\s*"
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.jentacular,
                "converter": self.jentacular_converter
            },
            "THERION": {
                "required_parts": {
                    "BRANCH": {"min": 1, "max": 4},
                    "PAGE": {"min": 1, "max": 1}
                },
                "regex_patterns": [
                    r"BRANCH\s*:\s*\d{5}\s+\w+",
                    r"PAGE\s*:\s*\d+"
                ],
                "min_length": None,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.therion,
                "converter": self.therion_converter
            },
            "DEINGLUCK": {
                "required_parts": {
                },
                "regex_patterns": [
                    r"\d{5}\s+\d{6}/\d{3}/\d{2}\s*[A-Z]{3}\s+"
                ],
                "min_length": None,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 1
                },
                "parser": self.deingluck,
                "converter": self.deingluck_converter
            }
        }

    def jentacular(self, line):
        parsed_dict = {}
        # Find the location of known keys
        keys = ['JENTACULAR#', 'BANK', 'REPORT', 'PROCESSING DATE/TIME', 'FOLIO', 'ARCH']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key
        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def jentacular_converter(self, dc):
        date_format = '%d/%m/%Y %H:%M'
        return {
            'BANK': dc.get('BANK', ''),
            'REPORT': dc.get('REPORT', ''),
            'PROCESSING_DATE_TIME': datetime.strptime(dc.get('PROCESSING_DATE_TIME', '').replace(': ','').strip(), date_format),
            'FOLIO': dc.get('FOLIO', '').replace(":","").strip(),
            'ARCH': dc.get('ARCH', '').replace(":","").strip()
        }

    def therion(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['THERION#', 'BRANCH', 'PAGE']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value
        return parsed_dict

    def therion_converter(self, dc):
        return {
            'BRANCH': dc.get('BRANCH', '').strip(" ").strip(":").strip(" "),
            'PAGE': dc.get('PAGE', '').replace(":","").strip()
        }

    def deingluck(self, line):
        parsed_dict = {}
        line = line.replace("DEINGLUCK#", "").strip()
        parts = line.split()
        parsed_dict['ACCOUNT_NO'] = parts[0] + " " + parts[1]
        parsed_dict['CCY'] = parts[2]
        parsed_dict['HOLDERS_NAME'] = " ".join(parts[3:parts.index("CLOSING")]).strip()
        parsed_dict['CLOSING_ORIGIN'] = " ".join(parts[parts.index("CLOSING"):8]).strip()

        parsed_dict['OPERATOR'] = " ".join(parts[8:parts.index("ACCOUNT")]).strip()
        parsed_dict['MESSAGES'] = parts[-1].strip()

        return parsed_dict

    def deingluck_converter(self, dc):
        return {
            'ACCOUNT_NO': dc.get('ACCOUNT_NO', ''),
            'CCY': dc.get('CCY', ''),
            'HOLDERS_NAME': dc.get('HOLDERS_NAME', ''),
            'CLOSING_ORIGIN': dc.get('CLOSING_ORIGIN', ''),
            'OPERATOR': dc.get('OPERATOR', ''),
            'MESSAGES': dc.get('MESSAGES', ''),
        }
    def tag_document(self, document):
        tagged = []
        parsed = []
        for string in document.split('\n'):

            string = self.apply_bundle(string)
            if string.strip() == "":
                continue
            scores = {}
            for tag, config in self.configs().items():
                similarity_score = self.string_similarity_measure(string, config["required_parts"],
                                                                  config["regex_patterns"],
                                                                  config["min_length"], config["max_length"],
                                                                  config["case_insensitive"],
                                                                  config["include_whitespace"],
                                                                  config["detailed_report"], config["weights"])
                if similarity_score['similarity_score'] > 0.8:
                    scores.update({tag: similarity_score['similarity_score']})
                else:
                    scores.update({"ABADON": 0})
            best_tag = max(scores, key=scores.get)
            if best_tag != "ABADON":
                tagged.append(f'{best_tag}#{self.clean_string(string)}')
                parsed_line = self.configs()[best_tag]["converter"](
                    self.configs()[best_tag]["parser"](f'{best_tag}#{self.clean_string(string)}')
                )

                parsed_line["TAG"] = best_tag
                parsed.append(parsed_line)
        simplified_dicts = self.merge_and_simplify_dicts(parsed, self.hierarchy, "JENTACULAR")
        return simplified_dicts

    def create_parquet(self, document):
        document = p.tag_document(document)
        df = pd.DataFrame(document)
        df.to_csv("EA0803.csv", sep=';', quotechar='"')


with open(r"data/EA0803A_0X276C2726DE0B6B3A78B4E00.txt", "r") as f:
    all = f.read()

p = EA0803()

for tmp in p.tag_document(all):
    print(tmp)

p.create_parquet(all)
