import json
import re
from datetime import datetime
from abstracts import SRMSParser
import pandas as pd


class EA1903B(SRMSParser):
    def bundle(self):
        return {
            "DATE/HEURE TRAITEMENT": "PROCESSING DATE/TIME",
            "DATE/HOUR PROCESSING": "PROCESSING DATE/TIME",
            "BANQUE": "BANK",
            "ETAT": "REPORT",
            "SIEGE": "BRANCH",
            "!": "|",
            "PYRAMID MEMBERSHIP GROUP": "ADDITIONAL DESCRIPTION"
        }
    @property
    def hierarchy(self):
        return {
            "": ["JENTACULAR"],
            "JENTACULAR": ["LULUSIA"],
            "LULUSIA": ["MOMONOSUKE"],
            "MOMONOSUKE": ["SHANKS"],
            "SHANKS": ["LUFFY"],
            "LUFFY": ["GARP"],
            "GARP": ["KOBY"]
        }
    def empty(self, line):
        return {}

    def empty_converter(self, dc):
        return dc

    def configs(self):
        return {
            "JENTACULAR": {
                "required_parts": {
                    "NAT.CLI.": {"min": 1, "max": 1},
                    "CLIENT LAST REVIEW": {"min": 1, "max": 1},
                    "CLIENT NEXT REVIEW": {"min": 1, "max": 1},
                },
                "regex_patterns": [
                    r"\|NAT\.CLI\.\s+:\s+\d{2}\s+\d{11}",
                    r"CLIENT\s+LAST\s+REVIEW\s+:\s+\d{2}/\d{2}/\d{4}",
                    r"CLIENT\s+NEXT\s+REVIEW\s+:\s+\d{2}/\d{2}/\d{4}",
                    r"GROUP\s+:\s+\w*"
                ],
                "min_length": 10,
                "max_length": 350,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.lilith,
                "converter": self.lilith_converter
            },
            "LULUSIA": {
                "required_parts": {
                    "INT.CLI.": {"min": 1, "max": 1},
                    "RATING": {"min": 1, "max": 2},
                    "MAIN": {"min": 1, "max": 2},
                    "INDUSTRY": {"min": 1, "max": 2},
                    "CODE": {"min": 1, "max": 2},
                },
                "regex_patterns": [
                    r"\|INT\.CLI\.\s+",
                    r"RATING",
                    r"MAIN\s+INDUSTRY\s+CODE\s+",
                ],
                "min_length": 10,
                "max_length": 350,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.lulusia,
                "converter": self.lulusia_converter
            },
            "MOMONOSUKE": {
                "required_parts": {
                    "BRCH/CL.N": {"min": 1, "max": 1},
                    "A.OFF": {"min": 1, "max": 2},
                    "COND": {"min": 1, "max": 2}
                },
                "regex_patterns": [
                ],
                "min_length": 10,
                "max_length": 350,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.momonosuke,
                "converter": self.momonosuke_converter
            },
            "SHANKS": {
                "required_parts": {
                    "\|": {"min": 10, "max": 10},
                    "ADDITIONAL DESCRIPTION": {"min": 0, "max": 0},
                },
                "regex_patterns": [
                ],
                "min_length": 10,
                "max_length": 350,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 0
                },
                "parser": self.shanks,
                "converter": self.shanks_converter
            },
            "LUFFY": {
                "required_parts": {
                    "\|": {"min": 11, "max": 11},
                    "UTILIZED AMOUNT": {"min": 0, "max": 0},
                },
                "regex_patterns": [
                ],
                "min_length": 10,
                "max_length": 350,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 0
                },
                "parser": self.luffy,
                "converter": self.luffy_converter
            },
            "GARP": {
                "required_parts": {
                    "\|": {"min": 6, "max": 6},
                    "/": {"min": 2, "max": 3},
                    "HEAD FACILITY IDENTIFIER": {"min": 0, "max": 0},
                },
                "regex_patterns": [
                ],
                "min_length": 10,
                "max_length": 350,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 0
                },
                "parser": self.garp,
                "converter": self.garp_converter
            },
            "KOBY": {
                "required_parts": {
                    "\|": {"min": 5, "max": 5},
                    "/": {"min": 0, "max": 1}
                },
                "regex_patterns": [
                ],
                "min_length": 10,
                "max_length": 350,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 0
                },
                "parser": self.koby,
                "converter": self.koby_converter
            },
        }


    def jentacular(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['JENTACULAR#', 'BANK', 'REPORT', 'PROCESSING DATE/TIME', 'FOLIO', 'ARCH']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key
        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def jentacular_converter(self, dc):
        date_format = '%d/%m/%Y %H:%M'
        return {
            'BANK': dc.get('BANK', '').replace(":","").strip(),
            'REPORT': dc.get('REPORT', '').replace(":","").strip(),
            'PROCESSING_DATE_TIME': datetime.strptime(dc.get('PROCESSING_DATE_TIME', '').replace(": ","").strip(), date_format),
            'FOLIO': dc.get('FOLIO', '').replace(":","").strip(),
            'ARCH': dc.get('ARCH', '').replace(":","").strip()
        }
    def lilith(self, line):
        parsed_dict = {}

        # Define keys and their positions
        keys = ['JENTACULAR#', '|NAT.CLI. :', 'CLIENT LAST REVIEW :', 'CLIENT NEXT REVIEW :', 'GROUP :']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def lilith_converter(self, dc):
        date_format = '%d/%m/%Y'
        return {
            'NAT_CLI': dc.get('NAT_CLI', ''),
            'CLIENT_LAST_REVIEW': datetime.strptime(dc.get('CLIENT_LAST_REVIEW', ''), date_format) if dc.get(
                'CLIENT_LAST_REVIEW') else None,
            'CLIENT_NEXT_REVIEW': datetime.strptime(dc.get('CLIENT_NEXT_REVIEW', '').replace('|','').strip(), date_format) if dc.get(
                'CLIENT_NEXT_REVIEW') else None,
        }

    def lulusia(self, line):
        parsed_dict = {}

        # Define keys and their positions
        keys = ['LULUSIA#', '|INT.CLI.', 'RATING', 'MAIN INDUSTRY CODE']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def lulusia_converter(self, dc):
        return {
            'INT_CLI': dc.get('INT_CLI', '').replace(":","").strip(),
            'RATING': dc.get('RATING', '').replace(":","").strip(),
            'MAIN_INDUSTRY_CODE': dc.get('MAIN_INDUSTRY_CODE', '').replace(":","").strip().strip('|').strip()
        }

    def momonosuke(self, line):
        parsed_dict = {}

        # Define keys and their positions
        keys = ['MOMONOSUKE#', '|BRCH/CL.N', 'A.OFF', 'COND']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value
        return parsed_dict

    def momonosuke_converter(self, dc):
        return {
            'BRCH_CLN': dc.get('BRCH_CL_N', '').replace(":","").strip(),
            'A.OFF': dc.get('A_OFF', '').replace(":","").strip(),
            'COND': dc.get('COND', '').replace(":","").strip().strip('|').strip()
        }

    def shanks(self, line):
        parsed_dict = {}
        # Split the line by the delimiter "|"
        parts = [part.strip() for part in line.split('|')]

        # Map the parts to the respective columns
        parsed_dict['NO_N_LOCAL_NOMENC'] = parts[1]
        parsed_dict['N_ORD'] = parts[2]
        parsed_dict['F_CU'] = parts[3]
        parsed_dict['VALID_AUTH_AMNT_CCY'] = parts[4]
        parsed_dict['VALID_AUTH_AMNT_CHF'] = parts[5]
        parsed_dict['ADDITIONAL_DESCRIPTION'] = parts[6]
        parsed_dict['STT'] = parts[7]
        parsed_dict['STATE'] = parts[8]
        parsed_dict['BLO'] = parts[9]

        return parsed_dict

    def shanks_converter(self, dc):

        # Convert amounts to float
        valid_auth_amnt_ccy = dc.get('VALID_AUTH_AMNT_CCY', '').replace(',', '.').replace(' ', '')
        valid_auth_amnt_chf = dc.get('VALID_AUTH_AMNT_CHF', '').replace(',', '.').replace(' ', '')

        return {
            'NO_N_LOCAL_NOMENC': dc.get('NO_N_LOCAL_NOMENC', ''),
            'N_ORD': dc.get('N_ORD', ''),
            'F_CU': dc.get('F_CU', ''),
            'VALID_AUTH_AMNT1': float(valid_auth_amnt_ccy) if valid_auth_amnt_ccy else 0.0,
            'VALID_AUTH_AMNT2': float(valid_auth_amnt_chf) if valid_auth_amnt_chf else 0.0,
            'ADDITIONAL_DESCRIPTION': dc.get('ADDITIONAL_DESCRIPTION', ''),
            'STT': dc.get('STT', ''),
            'STATE': dc.get('STATE', ''),
            'BLO': dc.get('BLO', ''),
        }

    def luffy(self, line):
        parsed_dict = {}
        # Split the line by the delimiter "|"
        parts = [part.strip() for part in line.split('|')]

        # Map the parts to the respective columns
        parsed_dict['START_DATE'] = parts[1]
        parsed_dict['STD_NOM'] = parts[2]
        parsed_dict['UTI_C'] = parts[3]
        parsed_dict['D_UT'] = parts[4]
        parsed_dict['UTILIZED_AMOUNT_CCY'] = parts[5]
        parsed_dict['UTILIZED_AMOUNT_CHF'] = parts[6]
        parsed_dict['EXCESS_CHF'] = parts[7]
        parsed_dict['ORG'] = parts[8]
        parsed_dict['EX_D'] = parts[9]
        parsed_dict['COM'] = parts[10]

        return parsed_dict

    def luffy_converter(self, dc):

        # Define the date format
        date_format = '%d/%m/%Y'

        # Parse the start date
        start_date_str = dc.get('START_DATE', '')
        start_date = datetime.strptime(start_date_str, date_format) if start_date_str else None

        # Convert amounts to float after removing commas and handling negative sign
        def convert_amount(amount_str):
            return float(amount_str.replace(' ', '').replace(',', '')) if amount_str else 0.0

        utilized_amount_ccy = convert_amount(dc.get('UTILIZED_AMOUNT_CCY', ''))
        utilized_amount_chf = convert_amount(dc.get('UTILIZED_AMOUNT_CHF', ''))
        excess_chf = convert_amount(dc.get('EXCESS_CHF', ''))

        return {
            'START_DATE': start_date,
            'STD_NOM': dc.get('STD_NOM', ''),
            'UTI_C': dc.get('UTI_C', ''),
            'D_UT': dc.get('D_UT', ''),
            'UTILIZED_AMOUNT_CCY': utilized_amount_ccy,
            'UTILIZED_AMOUNT_CHF': utilized_amount_chf,
            'EXCESS_CHF': excess_chf,
            'ORG': dc.get('ORG', ''),
            'EX_D': dc.get('EX_D', ''),
            'COM': dc.get('COM', ''),
        }

    def garp(self, line):
        parsed_dict = {}
        # Split the line by the delimiter "|"
        parts = [part.strip() for part in line.split('|')]

        # Map the parts to the respective columns
        parsed_dict['VALID_END'] = parts[1]
        parsed_dict['HEAD_FACILITY_IDENTIFIER'] = parts[2] if len(parts) > 2 else ''
        parsed_dict['ACT_TYP'] = parts[3]
        parsed_dict['ACT_CONTRACT_BAL_CHF'] = parts[4]
        parsed_dict['ACCOUNTS_OR_CONTRACTS'] = parts[5] if len(parts) > 5 else ''
        parsed_dict['OTHER_ACT_ID'] = parts[6] if len(parts) > 6 else ''

        return parsed_dict

    def garp_converter(self, dc):
        # Define the date format
        date_format = '%d/%m/%Y'

        # Parse the valid end date
        valid_end_str = dc.get('VALID_END', '')
        valid_end = datetime.strptime(valid_end_str, date_format) if valid_end_str else None

        # Convert amounts to float after removing commas and handling negative sign
        def convert_amount(amount_str):
            return float(amount_str.replace(' ', '').replace(',', '')) if amount_str else 0.0

        act_contract_bal_chf = convert_amount(dc.get('ACT_CONTRACT_BAL_CHF', ''))

        return {
            'VALID_END': valid_end,
            'HEAD_FACILITY_IDENTIFIER': dc.get('HEAD_FACILITY_IDENTIFIER', ''),
            'ACT_TYP': dc.get('ACT_TYP', ''),
            'ACT_CONTRACT_BAL': act_contract_bal_chf,
            'ACCOUNTS_OR_CONTRACTS': dc.get('ACCOUNTS_OR_CONTRACTS', ''),
            'OTHER_ACT_ID': dc.get('OTHER_ACT_ID', ''),
        }

    def koby(self, line):
        parsed_dict = {}
        # Split the line by the delimiter "|"
        parts = [part.strip() for part in line.split('|')]

        # Map the parts to the respective columns
        parsed_dict['VALID_END'] = parts[0] if len(parts) > 0 else ''
        parsed_dict['HEAD_FACILITY_IDENTIFIER'] = parts[1] if len(parts) > 1 else ''
        parsed_dict['ACT_TYP'] = parts[2] if len(parts) > 2 else ''
        parsed_dict['ACT_CONTRACT_BAL_CHF'] = parts[3] if len(parts) > 3 else ''
        parsed_dict['ACCOUNTS_OR_CONTRACTS'] = parts[4] if len(parts) > 4 else ''
        parsed_dict['OTHER_ACT_ID'] = parts[5] if len(parts) > 5 else ''

        return parsed_dict

    def koby_converter(self, dc):
        # Define the date format
        return {
            'ACT_TYP2': dc.get('ACT_TYP', ''),
            'ACT_CONTRACT_BAL2': dc.get('ACT_CONTRACT_BAL_CHF', '').replace(",",".").replace(" ","").strip(),
            'ACCOUNTS_OR_CONTRACTS2': dc.get('ACCOUNTS_OR_CONTRACTS', ''),
            'OTHER_ACT_ID2': dc.get('OTHER_ACT_ID', ''),
        }
    def tag_document(self, document):
        tagged = []
        parsed = []
        for string in document.split('\n'):
            string = self.apply_bundle(string)
            scores = {}
            for tag, config in self.configs().items():
                similarity_score = self.string_similarity_measure(string, config["required_parts"],
                                                                  config["regex_patterns"],
                                                                  config["min_length"], config["max_length"],
                                                                  config["case_insensitive"],
                                                                  config["include_whitespace"],
                                                                  config["detailed_report"], config["weights"])

                if similarity_score['similarity_score'] > 0.8:
                    scores.update({tag: similarity_score['similarity_score']})
                else:
                    scores.update({"ABADON": 0})
            best_tag = max(scores, key=scores.get)
            if best_tag not in ["ABADON"]:
                tagged.append(f'{best_tag}#{self.clean_string(string)}')

                parsed_line = self.configs()[best_tag]["converter"](
                    self.configs()[best_tag]["parser"](f'{best_tag}#{self.clean_string(string)}')
                )
                parsed_line["TAG"] = best_tag
                parsed.append(parsed_line)

        simplified_dicts = self.merge_and_simplify_dicts(parsed, self.hierarchy, "JENTACULAR")
        return simplified_dicts


    def create_parquet(self, document):
        document = p.tag_document(document)
        df = pd.DataFrame(document)
        df.to_csv("EA1903B.csv", sep=';', quotechar='"')


with open(r"data/EA1903B_0X276C2726DE0B6B3A78B4E06.txt", "r") as f:
    all = f.read()

p = EA1903B()

for tmp in p.tag_document(all):
    print("####", tmp)
p.create_parquet(all)
