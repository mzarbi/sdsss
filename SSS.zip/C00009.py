import json
import re
from datetime import datetime
from abstracts import SRMSParser
import pandas as pd


class C00009(SRMSParser):
    def bundle(self):
        return {
            " I ": " | "
        }
    @property
    def hierarchy(self):
        return {
            "": ["JENTACULAR"],
            "JENTACULAR": ["LULUSIA"]
        }
    def empty(self, line):
        return {}

    def empty_converter(self, dc):
        return dc

    def configs(self):
        return {
            "JENTACULAR": {
                "required_parts": {
                    "BANK": {"min": 1, "max": 2},
                    "REPORT": {"min": 1, "max": 2},
                    "PROCESSING DATE/TIME": {"min": 1, "max": 1},
                    "FOLIO": {"min": 1, "max": 2},
                    "ARCH": {"min": 1, "max": 2},
                },
                "regex_patterns": [
                    r"BANK\s+:\s+\d{2}\s+\w+",
                    r"REPORT:\s+EA1505",
                    r"PROCESSING\s+DATE/TIME:\s+\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}",
                    r"FOLIO:\s+\d+",
                    r"ARCH\s+:\s+\."
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.jentacular,
                "converter": self.jentacular_converter
            },
            "LULUSIA": {
                "required_parts": {
                    r"\|": {"min": 10, "max": 12},

                },
                "regex_patterns": [
                    "(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/([0-9]{4})"
                ],
                "min_length": None,
                "max_length": 300,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.lulusia,
                "converter": self.lulusia_converter
            },
        }

    def jentacular(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['JENTACULAR#', 'BANK :', 'REPORT:', 'PROCESSING DATE/TIME:', 'FOLIO', 'ARCH']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key
        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def jentacular_converter(self, dc):
        date_format = '%d/%m/%Y %H:%M'
        return {
            'BANK': dc.get('BANK', ''),
            'REPORT': dc.get('REPORT', ''),
            'PROCESSING_DATE_TIME': datetime.strptime(dc.get('PROCESSING_DATE_TIME', ''), date_format),
            'FOLIO': dc.get('FOLIO', '').replace(":","").strip(),
            'ARCH': dc.get('ARCH', '').replace(":","").strip()
        }

    def lulusia(self, line):
        parsed_dict = {}
        parts = [part.strip() for part in line.split('|')]
        # Map the parts to the respective columns
        parsed_dict['SETTLEMENT_CATEGORY'] = parts[1]
        parsed_dict['SETTLEMENT_DATE'] = parts[2]
        parsed_dict['ORIG'] = parts[3]
        parsed_dict['TYPE'] = parts[4]
        parsed_dict['PERIOD'] = parts[5]
        parsed_dict['DATE_REAL_SETTLM'] = parts[6]
        parsed_dict['LAST_PERIODIC_REAL_FICT_REDI'] = parts[7]
        parsed_dict['CLIENT_POSTING'] = parts[8]
        parsed_dict['REDISC_POSTING'] = parts[9]
        parsed_dict['N_ACTS'] = parts[10]
        parsed_dict['PROD'] = parts[11]

        return parsed_dict

    def lulusia_converter(self, dc):
        # Define the date format
        date_format = '%d/%m/%Y'

        # Parse the dates
        settlement_date_str = dc.get('SETTLEMENT_DATE', '')
        date_real_settlm_str = dc.get('DATE_REAL_SETTLM', '')
        last_periodic_real_fict_redi_str = dc.get('LAST_PERIODIC_REAL_FICT_REDI', '')

        settlement_date = datetime.strptime(settlement_date_str, date_format) if settlement_date_str else None
        date_real_settlm = datetime.strptime(date_real_settlm_str, date_format) if date_real_settlm_str else None
        last_periodic_real_fict_redi = datetime.strptime(last_periodic_real_fict_redi_str, date_format) if last_periodic_real_fict_redi_str else None

        return {
            'SETTLEMENT_CATEGORY': dc.get('SETTLEMENT_CATEGORY', ''),
            'SETTLEMENT_DATE': settlement_date,
            'ORIG': dc.get('ORIG', ''),
            'TYPE': dc.get('TYPE', ''),
            'PERIOD': dc.get('PERIOD', ''),
            'DATE_REAL_SETTLM': date_real_settlm,
            'LAST_PERIODIC_REAL_FICT_REDI': last_periodic_real_fict_redi,
            'CLIENT_POSTING': dc.get('CLIENT_POSTING', ''),
            'REDISC_POSTING': dc.get('REDISC_POSTING', ''),
            'N_ACTS': dc.get('N_ACTS', ''),
            'PROD': dc.get('PROD', '').replace('I',"").strip()
        }
    def tag_document(self, document):
        tagged = []
        parsed = []
        for string in document.split('\n'):
            string = self.apply_bundle(string)
            scores = {}
            for tag, config in self.configs().items():
                similarity_score = self.string_similarity_measure(string, config["required_parts"],
                                                                  config["regex_patterns"],
                                                                  config["min_length"], config["max_length"],
                                                                  config["case_insensitive"],
                                                                  config["include_whitespace"],
                                                                  config["detailed_report"], config["weights"])
                if similarity_score['similarity_score'] > 0.8:
                    scores.update({tag: similarity_score['similarity_score']})
                else:
                    scores.update({"ABADON": 0})
            best_tag = max(scores, key=scores.get)
            if best_tag != "ABADON":
                tagged.append(f'{best_tag}#{self.clean_string(string)}')
                parsed_line = self.configs()[best_tag]["converter"](
                    self.configs()[best_tag]["parser"](f'{best_tag}#{self.clean_string(string)}')
                )
                parsed_line["TAG"] = best_tag
                parsed.append(parsed_line)


        simplified_dicts = self.merge_and_simplify_dicts(parsed, self.hierarchy, "JENTACULAR")
        return simplified_dicts

    def create_parquet(self, document):
        document = p.tag_document(document)
        df = pd.DataFrame(document)
        df.to_csv("C00009.csv", sep=';', quotechar='"')


with open(r"data/C00009.txt", "r") as f:
    all = f.read()

p = C00009()

for tmp in p.tag_document(all):
    print(tmp)

p.create_parquet(all)
