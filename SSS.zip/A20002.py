import json
import re
from datetime import datetime
from abstracts import SRMSParser
import pandas as pd


class A20002(SRMSParser):
    @property
    def hierarchy(self):
        return {
            "": ["JENTACULAR"],
            "JENTACULAR": ["THERION"],
            "THERION": ["DEINGLUCK"],
            "DEINGLUCK": ["LILITH"],
            "LILITH": ["LULUSIA"],
        }
    def empty(self, line):
        return {}

    def empty_converter(self, dc):
        return dc

    def configs(self):
        return {
            "JENTACULAR": {
                "required_parts": {
                    "BANK": {"min": 1, "max": 2},
                    "REPORT": {"min": 1, "max": 2},
                    "PROCESSING DATE/TIME": {"min": 1, "max": 1},
                    "FOLIO": {"min": 1, "max": 2},
                    "ARCH": {"min": 1, "max": 2},
                },
                "regex_patterns": [
                    r"BANK\s+:\s+\d{2}\s+\w+",
                    r"REPORT:\s+EA1505",
                    r"PROCESSING\s+DATE/TIME:\s+\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}",
                    r"FOLIO:\s+\d+",
                    r"ARCH\s+:\s+\."
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.jentacular,
                "converter": self.jentacular_converter
            },
            "THERION": {
                "required_parts": {
                    "BRANCH": {"min": 1, "max": 4},
                    "PAGE": {"min": 1, "max": 1}
                },
                "regex_patterns": [
                    r"BRANCH\s*:\s*\d{5}\s+\w+",
                    r"PAGE\s*:\s*\d+"
                ],
                "min_length": None,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.therion,
                "converter": self.therion_converter
            },
            "DEINGLUCK": {
                "required_parts": {
                    "DEPARTMENT": {"min": 1, "max": 1},
                    "\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*\*": {"min": 1, "max": 1},
                },
                "regex_patterns": [
                ],
                "min_length": None,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 0
                },
                "parser": self.deingluck,
                "converter": self.deingluck_converter
            },
            "LILITH": {
                "required_parts": {
                    "DATE OF INPUT": {"min": 1, "max": 1},
                    "BATCH NO.": {"min": 1, "max": 1},
                    ":": {"min": 2, "max": 2},
                    "/": {"min": 2, "max": 2},
                },
                "regex_patterns": [
                ],
                "min_length": None,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 0
                },
                "parser": self.lilith,
                "converter": self.lilith_converter
            },
            "LULUSIA": {
                "required_parts": {
                    ",": {"min": 1, "max": 1},
                    "/": {"min": 4, "max": 5},
                },
                "regex_patterns": [
                    r"\d{6}/\d{3}/\d{2}/[A-Z]{3}"
                ],
                "min_length": None,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 1
                },
                "parser": self.lulusia,
                "converter": self.lulusia_converter
            },
        }

    def jentacular(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['JENTACULAR#', 'BANK :', 'REPORT:', 'PROCESSING DATE/TIME:', 'FOLIO', 'ARCH']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key
        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def jentacular_converter(self, dc):
        date_format = '%d/%m/%Y %H:%M'
        return {
            'BANK': dc.get('BANK', ''),
            'REPORT': dc.get('REPORT', ''),
            'PROCESSING_DATE_TIME': datetime.strptime(dc.get('PROCESSING_DATE_TIME', ''), date_format),
            'FOLIO': dc.get('FOLIO', '').replace(":","").strip(),
            'ARCH': dc.get('ARCH', '').replace(":","").strip()
        }

    def therion(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['THERION#', 'BRANCH', 'PAGE']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value
        return parsed_dict

    def therion_converter(self, dc):
        return {
            'BRANCH': dc.get('BRANCH', '').strip(" ").strip(":").strip(" "),
            'PAGE': dc.get('PAGE', '').replace(":","").strip()
        }

    def deingluck(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['DEINGLUCK#', 'DEPARTMENT']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value
        return parsed_dict

    def deingluck_converter(self, dc):
        return {
            'DEPARTMENT': dc.get('DEPARTMENT', '').replace(":","").strip(" ").strip("*").strip(" "),
        }

    def lilith(self, line):
        parsed_dict = {}

        # Define the known keys
        keys = ['LILITH#', 'DATE OF INPUT :', 'BATCH NO.:']
        key_positions = {}

        # Find the positions of the keys in the line
        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their positions in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def lilith_converter(self, dc):
        # Define the date format
        date_format = '%d/%m/%Y'

        # Parse the date
        date_of_input_str = dc.get('DATE_OF_INPUT', '')
        if date_of_input_str:
            try:
                date_of_input = datetime.strptime(date_of_input_str, date_format)
            except ValueError:
                date_of_input = None
        else:
            date_of_input = None

        return {
            'DATE_OF_INPUT': date_of_input,
            'BATCH_NO': dc.get('BATCH_NO', ''),
        }

    def lulusia(self, line):
        parsed_dict = {}
        sps = line.split(' ')
        parsed_dict['ACCOUNT'] = " ".join(sps[1:3]).strip()
        parsed_dict['ENT_COD'] = sps[3].strip()
        parsed_dict['OPE_REF'] = sps[4].strip()
        parsed_dict['OPERATION_DATE'] = sps[5].strip()
        parsed_dict['OPE_NO'] = sps[6].strip()
        parsed_dict['ENT_NO'] = sps[7].strip()
        parsed_dict['AMOUNT'] = float("".join(sps[8:-8]).strip().replace('+', '').replace(',', '.'))
        parsed_dict['TYPE'] = 'DEBIT' if '-' in "".join(sps[8:-8]).strip() else 'CREDIT'
        parsed_dict['CCY'] = sps[-8].strip()
        parsed_dict['OMC'] = sps[-7].strip()
        parsed_dict['AUT'] = sps[-6].strip()
        parsed_dict['GRP'] = sps[-5].strip()
        parsed_dict['STA'] = sps[-4].strip()
        parsed_dict['DEL'] = sps[-3].strip()
        parsed_dict['DEA'] = sps[-2].strip()

        return parsed_dict

    def lulusia_converter(self, dc):
        # Define the date format
        date_format = '%d/%m/%Y'

        # Parse the operation date
        operation_date_str = dc.get('OPERATION_DATE', '')
        if operation_date_str:
            try:
                operation_date = datetime.strptime(operation_date_str, date_format)
            except ValueError:
                operation_date = None
        else:
            operation_date = None

        return {
            'ACCOUNT': dc.get('ACCOUNT', ''),
            'ENT_COD': dc.get('ENT_COD', ''),
            'OPE_REF': dc.get('OPE_REF', ''),
            'OPERATION_DATE': operation_date,
            'OPE_NO': dc.get('OPE_NO', ''),
            'ENT_NO': dc.get('ENT_NO', ''),
            'AMOUNT': dc.get('AMOUNT', ''),
            'TYPE': dc.get('TYPE', ''),
            'CCY': dc.get('CCY', ''),
            'OMC': dc.get('OMC', ''),
            'AUT': dc.get('AUT', ''),
            'GRP': dc.get('GRP', ''),
            'STA': dc.get('STA', ''),
            'DEL': dc.get('DEL', ''),
            'DEA': dc.get('DEA', '')
        }
    def tag_document(self, document):
        tagged = []
        parsed = []
        for string in document.split('\n'):
            scores = {}
            for tag, config in self.configs().items():
                similarity_score = self.string_similarity_measure(string, config["required_parts"],
                                                                  config["regex_patterns"],
                                                                  config["min_length"], config["max_length"],
                                                                  config["case_insensitive"],
                                                                  config["include_whitespace"],
                                                                  config["detailed_report"], config["weights"])
                if similarity_score['similarity_score'] > 0.8:
                    scores.update({tag: similarity_score['similarity_score']})
                else:
                    scores.update({"ABADON": 0})
            best_tag = max(scores, key=scores.get)
            if best_tag != "ABADON":
                tagged.append(f'{best_tag}#{self.clean_string(string)}')
                parsed_line = self.configs()[best_tag]["converter"](
                    self.configs()[best_tag]["parser"](f'{best_tag}#{self.clean_string(string)}')
                )
                parsed_line["TAG"] = best_tag
                parsed.append(parsed_line)
        simplified_dicts = self.merge_and_simplify_dicts(parsed, self.hierarchy, "JENTACULAR")
        return simplified_dicts

    def create_parquet(self, document):
        document = p.tag_document(document)
        df = pd.DataFrame(document)
        df.to_csv("A20002.csv", sep=';', quotechar='"')


with open(r"data/A20002.txt", "r") as f:
    all = f.read()

p = A20002()

for tmp in p.tag_document(all):
    print(tmp)

p.create_parquet(all)
