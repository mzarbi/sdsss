import json
import re
from datetime import datetime
from abstracts import SRMSParser
import pandas as pd


class EA1505(SRMSParser):
    @property
    def hierarchy(self):
        return {
            "": ["JENTACULAR"],
            "JENTACULAR": ["THERION"],
            "THERION": ["DEINGLUCK"],
            "DEINGLUCK": ["LILITH"],
            "LILITH": ["LULUSIA"],
            "LULUSIA": ["SHANKS"],
            "SHANKS": ["GRAYFOX"],
            "GRAYFOX": ["BARKOS", 'SHARGRATH'],
            "BARKOS": ["KALB"],
        }
    def jentacular(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['JENTACULAR#', 'BANK :', 'REPORT:', 'PROCESSING DATE/TIME:', 'FOLIO:', 'ARCH :']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key
        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def jentacular_converter(self, dc):
        date_format = '%d/%m/%Y %H:%M'
        return {
            'BANK': dc.get('BANK', ''),
            'REPORT': dc.get('REPORT', ''),
            'PROCESSING_DATE_TIME': datetime.strptime(dc.get('PROCESSING_DATE_TIME', ''), date_format),
            'FOLIO': dc.get('FOLIO', ''),
            'ARCH': dc.get('ARCH', '')
        }

    def therion(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['THERION#', 'BRANCH :', 'PAGE :']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value
        return parsed_dict

    def therion_converter(self, dc):
        return {
            'BRANCH': dc.get('BRANCH', ''),
            'PAGE': dc.get('PAGE', '')
        }

    def deingluck(self, line):
        parsed_dict = {}

        # Define keys and their positions
        keys = ['DEINGLUCK#', '|', 'A.OFF:', 'COND:']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def deingluck_converter(self, dc):
        return {
            'A_OFF': dc.get('A_OFF', ''),
            'COND': dc.get('COND', '').split('|')[0].strip()
        }

    def lilith(self, line):
        parsed_dict = {}

        # Define keys and their positions
        keys = ['LILITH#', '|NAT.CLI. :', 'CLIENT LAST REVIEW :', 'CLIENT NEXT REVIEW :', 'GROUP :']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def lilith_converter(self, dc):
        date_format = '%d/%m/%Y'
        return {
            'NAT_CLI': dc.get('NAT_CLI', ''),
            'CLIENT_LAST_REVIEW': datetime.strptime(dc.get('CLIENT_LAST_REVIEW', ''), date_format) if dc.get(
                'CLIENT_LAST_REVIEW') else None,
            'CLIENT_NEXT_REVIEW': datetime.strptime(dc.get('CLIENT_NEXT_REVIEW', ''), date_format) if dc.get(
                'CLIENT_NEXT_REVIEW') else None,
            'GROUP': dc.get('GROUP', '').strip('|').strip()
        }

    def lulusia(self, line):
        parsed_dict = {}

        # Define keys and their positions
        keys = ['LULUSIA#', '|INT.CLI. :', 'RATING :', 'MAIN INDUSTRY CODE :']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def lulusia_converter(self, dc):
        return {
            'INT_CLI': dc.get('INT_CLI', ''),
            'RATING': dc.get('RATING', ''),
            'MAIN_INDUSTRY_CODE': dc.get('MAIN_INDUSTRY_CODE', '').strip('|').strip()
        }

    def shanks(self, line):
        parsed_dict = {}

        # Split the line by the delimiter '|'
        parts = line.split('|')

        # Assign values to the appropriate columns
        columns = [
            'NO_L_LOCAL_NOMENCLATURE',
            'SEQ_N',
            'FAC_C',
            'AUTHORIZED_AMNT_CCY',
            'AUTHORIZED_AMNT_HUF',
            'STT',
            'COMPL',
            'FRZ'
        ]

        sanitized_values = [part.strip() for part in parts]
        parsed_dict = dict(zip(columns, sanitized_values[1:]))  # Skip the first part which is SHANKS#

        return parsed_dict

    def shanks_converter(self, dc):
        # Convert amounts to floats
        def convert_amount(amount_str):
            return float(amount_str.replace(' ', '').replace(',', '.'))

        return {
            'NO_L_LOCAL_NOMENCLATURE': dc.get('NO_L_LOCAL_NOMENCLATURE', ''),
            'SEQ_N': dc.get('SEQ_N', ''),
            'FAC_C': dc.get('FAC_C', ''),
            'AUTHORIZED_AMNT_CCY': convert_amount(dc.get('AUTHORIZED_AMNT_CCY', '0')) if dc.get(
                'AUTHORIZED_AMNT_CCY') else 0.0,
            'AUTHORIZED_AMNT_HUF': convert_amount(dc.get('AUTHORIZED_AMNT_HUF', '0')) if dc.get(
                'AUTHORIZED_AMNT_HUF') else 0.0,
            'STT': dc.get('STT', ''),
            'COMPL': dc.get('COMPL', ''),
            'FRZ': dc.get('FRZ', '')
        }

    def grayfox(self, line):
        parsed_dict = {}

        # Split the line by the delimiter '|'
        parts = line.split('|')

        # Assign values to the appropriate columns
        columns = [
            'START_DATE',
            'STANDARD_NOMENCLATURE',
            'UTI_C',
            'DI_UT',
            'UTILIZED_AMOUNT_CCY',
            'UTILIZED_AMOUNT_HUF',
            'EXC',
            'COMM'
        ]

        sanitized_values = [part.strip() for part in parts]
        parsed_dict = dict(zip(columns, sanitized_values[1:]))  # Skip the first part which is GRAYFOX#

        return parsed_dict

    def grayfox_converter(self, dc):
        # Convert amounts to floats and dates to datetime objects
        def convert_amount(amount_str):
            return float(amount_str.replace(' ', '').replace(',', '.'))

        def convert_date(date_str):
            return datetime.strptime(date_str, '%d/%m/%Y')

        return {
            'START_DATE': convert_date(dc.get('START_DATE', '01/01/1970')) if dc.get('START_DATE') else None,
            'STANDARD_NOMENCLATURE': dc.get('STANDARD_NOMENCLATURE', ''),
            'UTI_C': dc.get('UTI_C', ''),
            'DI_UT': dc.get('DI_UT', ''),
            'UTILIZED_AMOUNT_CCY': convert_amount(dc.get('UTILIZED_AMOUNT_CCY', '0')) if dc.get(
                'UTILIZED_AMOUNT_CCY') else 0.0,
            'UTILIZED_AMOUNT_HUF': convert_amount(dc.get('UTILIZED_AMOUNT_HUF', '0')) if dc.get(
                'UTILIZED_AMOUNT_HUF') else 0.0,
            'EXC': dc.get('EXC', ''),
            'COMM': dc.get('COMM', '')
        }

    def barkos(self, line):
        parsed_dict = {}

        # Split the line by the delimiter '|'
        parts = line.split('|')

        # Assign values to the appropriate columns
        columns = [
            'EXPIRY_DATE',
            'IDENTIFIER_OF_FACILITY_LINKED_TO',
            'ACCOUNTS_CONTRACTS',
            'ACT_CONTR_BALANC_HUF',
            'ACT_TYPE'
        ]

        sanitized_values = [part.strip() for part in parts]
        parsed_dict = dict(zip(columns, sanitized_values[1:]))  # Skip the first part which is BARKOS#

        return parsed_dict

    def barkos_converter(self, dc):
        # Convert amounts to floats and dates to datetime objects
        def convert_amount(amount_str):
            return float(amount_str.replace(' ', '').replace(',', '.'))

        def convert_date(date_str):
            return datetime.strptime(date_str, '%d/%m/%Y')

        return {
            'EXPIRY_DATE': convert_date(dc.get('EXPIRY_DATE', '01/01/1970')) if dc.get('EXPIRY_DATE') else None,
            'IDENTIFIER_OF_FACILITY_LINKED_TO': dc.get('IDENTIFIER_OF_FACILITY_LINKED_TO', ''),
            'ACCOUNTS_CONTRACTS': dc.get('ACCOUNTS_CONTRACTS', '').replace(" ", "").replace(',', '.'),
            'ACT_CONTR_BALANC_HUF': convert_amount(dc.get('ACT_CONTR_BALANC_HUF', '0')) if dc.get(
                'ACT_CONTR_BALANC_HUF') else 0.0,
            'ACT_TYPE': dc.get('ACT_TYPE', '')
        }

    def shargrath(self, line):
        parsed_dict = {}

        # Split the line by the delimiter '|'
        parts = line.split('|')

        # Assign values to the appropriate columns
        columns = [
            'EXPIRY_DATE',
            'IDENTIFIER_OF_FACILITY_LINKED_TO',
            'ACCOUNTS_CONTRACTS',
            'ACT_CONTR_BALANC_HUF'
        ]

        sanitized_values = [part.strip() for part in parts]
        parsed_dict = dict(zip(columns, sanitized_values[1:]))  # Skip the first part which is SHARGRATH#

        return parsed_dict

    def shargrath_converter(self, dc):
        # Convert amounts to floats and dates to datetime objects
        def convert_amount(amount_str):
            return float(amount_str.replace(' ', '').replace(',', '.'))

        def convert_date(date_str):
            return datetime.strptime(date_str, '%d/%m/%Y')

        return {
            'EXPIRY_DATE': convert_date(dc.get('EXPIRY_DATE', '01/01/1970')) if dc.get('EXPIRY_DATE') else None,
            'IDENTIFIER_OF_FACILITY_LINKED_TO': dc.get('IDENTIFIER_OF_FACILITY_LINKED_TO', ''),
            'ACCOUNTS_CONTRACTS': dc.get('ACCOUNTS_CONTRACTS', ''),
            'ACT_CONTR_BALANC_HUF': convert_amount(dc.get('ACT_CONTR_BALANC_HUF', '0')) if dc.get(
                'ACT_CONTR_BALANC_HUF') else 0.0
        }

    def kalb(self, line):
        parsed_list = []

        # Define columns
        columns = [
            'EXPIRY_DATE',
            'IDENTIFIER_OF_FACILITY_LINKED_TO',
            'ACCOUNTS_CONTRACTS',
            'ACT_CONTR_BALANC_HUF',
            'ACT_TYPE'
        ]

        parsed_dict = {}
        parts = line.split('|')
        sanitized_values = [part.strip() for part in parts]
        parsed_dict = dict(zip(columns, sanitized_values[1:]))  # Skip the first part which is KALB#

        return parsed_dict

    def kalb_converter(self, parsed_dict):
        # Convert amounts to floats and dates to datetime objects
        def convert_amount(amount_str):
            try:
                return float(amount_str.replace(' ', '').replace(',', '.'))
            except ValueError:
                return amount_str

        return {

            'IDENTIFIER_OF_FACILITY_LINKED_TO': parsed_dict.get('IDENTIFIER_OF_FACILITY_LINKED_TO', ''),
            'ACCOUNTS_CONTRACTS': parsed_dict.get('ACCOUNTS_CONTRACTS', '').replace(" ", "").replace(',', '.'),
            'ACT_CONTR_BALANC_HUF': convert_amount(parsed_dict.get('ACT_CONTR_BALANC_HUF', '0')) if parsed_dict.get(
                'ACT_CONTR_BALANC_HUF') else 0.0,
            'ACT_TYPE': parsed_dict.get('ACT_TYPE', '')
        }

    def zohar(self, line):
        return {}

    def zohar_converter(self, dc):
        return {}

    def empty(self, line):
        return {}

    def empty_converter(self, dc):
        return dc

    def configs(self):
        return {
            "JENTACULAR": {
                "required_parts": {
                    "BANK": {"min": 1, "max": 2},
                    "REPORT": {"min": 1, "max": 2},
                    "PROCESSING DATE/TIME": {"min": 1, "max": 1},
                    "FOLIO": {"min": 1, "max": 2},
                    "ARCH": {"min": 1, "max": 2},
                },
                "regex_patterns": [
                    r"BANK\s+:\s+\d{2}\s+\w+",
                    r"REPORT:\s+EA1505",
                    r"PROCESSING\s+DATE/TIME:\s+\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}",
                    r"FOLIO:\s+\d+",
                    r"ARCH\s+:\s+\."
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.jentacular,
                "converter": self.jentacular_converter
            },
            "THERION": {
                "required_parts": {
                    "BRANCH": {"min": 1, "max": 4},
                    "PAGE": {"min": 1, "max": 1}
                },
                "regex_patterns": [
                    r"BRANCH\s+:\s+\d{5}\s+\w+",
                    r"PAGE\s+:\s+\d+"
                ],
                "min_length": None,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.therion,
                "converter": self.therion_converter
            },
            "DEINGLUCK": {
                "required_parts": {
                    " A.OFF": {"min": 1, "max": 2},
                    " COND": {"min": 1, "max": 2}
                },
                "regex_patterns": [
                    r"\|\d{5}/\d{6}\s+\d{2}\s+\w+",
                    r"A\.OFF:\s+\w+(\s+\w+)?",
                    r"COND:\s+\d+-"
                ],
                "min_length": 10,
                "max_length": 300,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 3,
                    "patterns": 1
                },
                "parser": self.deingluck,
                "converter": self.deingluck_converter
            },
            "LILITH": {
                "required_parts": {
                    "NAT.CLI.": {"min": 1, "max": 1},
                    "CLIENT LAST REVIEW": {"min": 1, "max": 1},
                    "CLIENT NEXT REVIEW": {"min": 1, "max": 1},
                    "GROUP": {"min": 1, "max": 2}
                },
                "regex_patterns": [
                    r"\|NAT\.CLI\.\s+:\s+\d{2}\s+\d{11}",
                    r"CLIENT\s+LAST\s+REVIEW\s+:\s+\d{2}/\d{2}/\d{4}",
                    r"CLIENT\s+NEXT\s+REVIEW\s+:\s+\d{2}/\d{2}/\d{4}",
                    r"GROUP\s+:\s+\w*"
                ],
                "min_length": 10,
                "max_length": 350,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.lilith,
                "converter": self.lilith_converter
            },
            "LULUSIA": {
                "required_parts": {
                    "INT.CLI.": {"min": 1, "max": 1},
                    "RATING": {"min": 1, "max": 2},
                    "MAIN": {"min": 1, "max": 2},
                    "INDUSTRY": {"min": 1, "max": 2},
                    "CODE": {"min": 1, "max": 2},
                },
                "regex_patterns": [
                    r"\|INT\.CLI\.\s+",
                    r"RATING",
                    r"MAIN\s+INDUSTRY\s+CODE\s+",
                ],
                "min_length": 10,
                "max_length": 350,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.lulusia,
                "converter": self.lulusia_converter
            },
            "SHANKS": {
                "required_parts": {
                    "\|": {"min": 9, "max": 9},
                    ",": {"min": 0, "max": 2}
                },
                "regex_patterns": [
                    r"\|\s+\d{3}\s+\|",
                    r"\|\s+[A-Z]{1,3}\s+\|",
                    r"\|\s+[\d\s,*.]+\s+\|",
                    r"\s+\|\d{3}\s+\d{1}",
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 5
                },
                "parser": self.shanks,
                "converter": self.shanks_converter
            },
            "GRAYFOX": {
                "required_parts": {
                    "\|": {"min": 10, "max": 10},
                    "/": {"min": 2, "max": 2},
                    ",": {"min": 0, "max": 2}
                },
                "regex_patterns": [
                    r"\|\s+\d{3}\s+\|",
                    r"\|\s+[A-Z]{1,3}\s+\|",
                    r"\|\s+[\d\s,*.]+\s+\|",
                    r"|\d{2}/\d{2}/\d{4}\s+\|",
                    r"|\d{2}/\d{2}/\d{4}\s+\|"
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 2
                },
                "parser": self.grayfox,
                "converter": self.grayfox_converter
            },
            "SHARGRATH": {
                "required_parts": {
                    "\|": {"min": 3, "max": 4},
                    "/": {"min": 2, "max": 2}
                },
                "regex_patterns": [
                    r"|\d{2}/\d{2}/\d{4}\s+\|",
                    r"|\d{2}/\d{2}/\d{4}\s+\|"
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 2
                },
                "parser": self.shargrath,
                "converter": self.shargrath_converter
            },
            "KALB": {
                "required_parts": {
                    "\|": {"min": 5, "max": 5},

                },
                "regex_patterns": [
                    r"|\d{2}/\d{2}/\d{4}\s+\|",
                    r"|\d{2}/\d{2}/\d{4}\s+\|"
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 2
                },
                "parser": self.kalb,
                "converter": self.kalb_converter
            },
            "BARKOS": {
                "required_parts": {
                    "\|": {"min": 6, "max": 6},
                    "/": {"min": 2, "max": 4}
                },
                "regex_patterns": [
                    r"\d{2}/\d{2}/\d{4}\s+"
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 1
                },
                "parser": self.barkos,
                "converter": self.barkos_converter
            }
        }

    def clean_string(self, s, iteration=20):
        for tmp in range(iteration):
            s = s.replace("  ", " ")
        return s

    def tag_document(self, document):
        tagged = []
        parsed = []
        for string in document.split('\n'):
            scores = {}
            for tag, config in self.configs().items():
                similarity_score = self.string_similarity_measure(string, config["required_parts"],
                                                                  config["regex_patterns"],
                                                                  config["min_length"], config["max_length"],
                                                                  config["case_insensitive"],
                                                                  config["include_whitespace"],
                                                                  config["detailed_report"], config["weights"])
                if similarity_score['similarity_score'] > 0.8:
                    scores.update({tag: similarity_score['similarity_score']})
                else:
                    scores.update({"ABADON": 0})
            best_tag = max(scores, key=scores.get)
            if best_tag != "ABADON":
                tagged.append(f'{best_tag}#{self.clean_string(string)}')
                parsed_line = self.configs()[best_tag]["converter"](
                    self.configs()[best_tag]["parser"](f'{best_tag}#{self.clean_string(string)}')
                )
                parsed_line["TAG"] = best_tag
                parsed.append(parsed_line)

        hierarchy = {
            "": ["JENTACULAR"],
            "JENTACULAR": ["THERION"],
            "THERION": ["DEINGLUCK"],
            "DEINGLUCK": ["LILITH"],
            "LILITH": ["LULUSIA"],
            "LULUSIA": ["SHANKS"],
            "SHANKS": ["GRAYFOX"],
            "GRAYFOX": ["BARKOS", 'SHARGRATH'],
            "BARKOS": ["KALB"],
        }
        simplified_dicts = self.merge_and_simplify_dicts(parsed, self.hierarchy, "JENTACULAR")
        return simplified_dicts

    def create_parquet(self, document):
        document = p.tag_document(document)
        df = pd.DataFrame(document)
        df.to_csv("EA1505.csv", sep=';', quotechar='"')


with open(r"data/EA1505.txt", "r") as f:
    all = f.read()

p = EA1505()

for tmp in p.tag_document(all):
    print(tmp)

p.create_parquet(all)
