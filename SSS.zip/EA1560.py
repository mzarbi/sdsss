import json
import re
from datetime import datetime
from abstracts import SRMSParser
import pandas as pd


class EA1560(SRMSParser):
    def bundle(self):
        return {
            "DATE/HEURE TRAITEMENT": "PROCESSING DATE/TIME",
            "BANQUE": "BANK",
            "ETAT": "REPORT",
            "SIEGE": "BRANCH",
        }
    @property
    def hierarchy(self):
        return {
            "": ["JENTACULAR"],
            "JENTACULAR": ["THERION"],
            "THERION": ["DEINGLUCK"],
            "DEINGLUCK": ["FUNKENSTOSS"],
        }
    def empty(self, line):
        return {}

    def empty_converter(self, dc):
        return dc

    def configs(self):
        return {
            "JENTACULAR": {
                "required_parts": {
                    "BANK": {"min": 1, "max": 2},
                    "REPORT": {"min": 1, "max": 2},
                    "PROCESSING DATE/TIME": {"min": 1, "max": 1},
                    "FOLIO": {"min": 1, "max": 2},
                    "ARCH": {"min": 1, "max": 2},
                },
                "regex_patterns": [
                    r"BANK\s*:\s*\d{2}\s+\w+",
                    r"REPORT\s*:\s+EA1505",
                    r"PROCESSING\s+DATE/TIME\s*:\s+\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}",
                    r"FOLIO\s*:\s+\d+",
                    r"ARCH\s*:\s+\."
                ],
                "min_length": 100,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.jentacular,
                "converter": self.jentacular_converter
            },
            "THERION": {
                "required_parts": {
                    "BRANCH": {"min": 1, "max": 4},
                    "PAGE": {"min": 1, "max": 1}
                },
                "regex_patterns": [
                    r"BRANCH\s*:\s*\d{5}\s+\w+",
                    r"PAGE\s*:\s*\d+"
                ],
                "min_length": None,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.therion,
                "converter": self.therion_converter
            },
            "DEINGLUCK": {
                "required_parts": {
                    r"\|": {"min": 2, "max": 2},
                    "PARTICULARITES": {"min": 1, "max": 1},
                },
                "regex_patterns": [
                ],
                "min_length": 30,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 2,
                    "patterns": 1
                },
                "parser": self.deingluck,
                "converter": self.deingluck_converter
            },
            "FUNKENSTOSS": {
                "required_parts": {
                    r"\|": {"min": 2, "max": 2}
                },
                "regex_patterns": [
                    r"\d{3} [A-Z]{3} \d{8}"
                ],
                "min_length": 30,
                "max_length": 200,
                "case_insensitive": True,
                "include_whitespace": True,
                "detailed_report": True,
                "weights": {
                    "parts": 1,
                    "patterns": 2
                },
                "parser": self.funkenstoss,
                "converter": self.funkenstoss_converter
            }
        }

    def jentacular(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['JENTACULAR#', 'BANK', 'REPORT', 'PROCESSING DATE/TIME', 'FOLIO', 'ARCH']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key
        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value

        return parsed_dict

    def jentacular_converter(self, dc):
        date_format = '%d/%m/%Y %H:%M'
        return {
            'BANK': dc.get('BANK', '').replace(":","").strip(),
            'REPORT': dc.get('REPORT', '').replace(":","").strip(),
            'PROCESSING_DATE_TIME': datetime.strptime(dc.get('PROCESSING_DATE_TIME', '').replace(": ","").strip(), date_format),
            'FOLIO': dc.get('FOLIO', '').replace(":","").strip(),
            'ARCH': dc.get('ARCH', '').replace(":","").strip()
        }

    def therion(self, line):
        parsed_dict = {}

        # Find the location of known keys
        keys = ['THERION#', 'BRANCH', 'PAGE']
        key_positions = {}

        for key in keys:
            start = line.find(key)
            if start != -1:
                key_positions[start] = key

        # Sort the keys by their position in the line
        sorted_key_positions = sorted(key_positions.items())

        # Extract values based on the positions of keys
        for i in range(len(sorted_key_positions)):
            key = sorted_key_positions[i][1]
            key_start = sorted_key_positions[i][0]
            key_length = len(key)

            # Determine the end position of the value
            if i + 1 < len(sorted_key_positions):
                next_key_start = sorted_key_positions[i + 1][0]
                value = line[key_start + key_length:next_key_start].strip()
            else:
                value = line[key_start + key_length:].strip()

            # Sanitize and assign value to dictionary
            sanitized_key = self.sanitize_key(key)
            parsed_dict[sanitized_key] = value
        return parsed_dict

    def therion_converter(self, dc):
        return {
            'BRANCH': dc.get('BRANCH', '').strip(" ").strip(":").strip(" "),
            'PAGE': dc.get('PAGE', '').replace(":","").strip()
        }

    def deingluck(self, line):
        parsed_dict = {}
        line = line.split('|')[1].strip()
        parsed_dict['RACINE'] = line.split(" ")[0].strip()
        parsed_dict['PARTICULARITES'] = line.split(" ")[-1].strip()
        parsed_dict['LABEL'] = " ".join(line.split(" ")[1:-2]).replace("PARTICULARITES","").strip()
        return parsed_dict

    def deingluck_converter(self, dc):
        return dc
    def tag_document(self, document):
        tagged = []
        parsed = []
        for string in document.split('\n'):
            string = self.apply_bundle(string)
            scores = {}
            for tag, config in self.configs().items():
                similarity_score = self.string_similarity_measure(string, config["required_parts"],
                                                                  config["regex_patterns"],
                                                                  config["min_length"], config["max_length"],
                                                                  config["case_insensitive"],
                                                                  config["include_whitespace"],
                                                                  config["detailed_report"], config["weights"])
                if similarity_score['similarity_score'] > 0.8:
                    scores.update({tag: similarity_score['similarity_score']})
                else:
                    scores.update({"ABADON": 0})
            best_tag = max(scores, key=scores.get)
            if best_tag != "ABADON":
                tagged.append(f'{best_tag}#{self.clean_string(string)}')
                parsed_line = self.configs()[best_tag]["converter"](
                    self.configs()[best_tag]["parser"](f'{best_tag}#{self.clean_string(string)}')
                )
                parsed_line["TAG"] = best_tag
                parsed.append(parsed_line)
        simplified_dicts = self.merge_and_simplify_dicts(parsed, self.hierarchy, "JENTACULAR")
        return simplified_dicts

    def extract_first_and_last(self, number_list):
        # Helper function to convert and concatenate numbers
        def convert_to_float(segment):
            return float(''.join(segment).replace(',', '.'))

        # Extract the first segment
        first_segment = []
        while number_list:
            first_segment.append(number_list.pop(0))
            if ',' in first_segment[-1]:
                break
        first_number = convert_to_float(first_segment)

        last_segment = []
        pops1 = number_list.pop(-1)

        while number_list:
            pops = number_list.pop(-1)
            if len(last_segment) == 0:
                last_segment.insert(0, pops)
                continue
            if ',' in pops or '0' == pops[-1]:
                break
            else:
                last_segment.insert(0, pops)
        number_list.append(pops)
        last_segment.append(pops1)

        middle_number = convert_to_float(number_list)
        last_number = convert_to_float(last_segment)

        return [first_number, middle_number, last_number]

    def process_number_lists(self, number_lists):
        return [self.extract_first_and_last(num_list) for num_list in number_lists]
    def funkenstoss(self, line):
        parsed_dict = {}
        # Split the line by the delimiter "|"
        parts = [part.strip() for part in line.split('|')]

        # Extract the relevant part
        main_part = parts[1] if len(parts) > 1 else ''

        # Split the main part into its components
        main_parts = main_part.split()
        # Assign the parts to the respective columns
        parsed_dict['CODE'] = main_parts[0]
        parsed_dict['CURRENCY'] = main_parts[1]
        parsed_dict['REF'] = main_parts[2]
        numbers = self.process_number_lists([main_parts[3:]])

        parsed_dict['BALANCE'] = numbers[0][0]
        parsed_dict['ACCOUNTING_BALANCE'] = numbers[0][1]
        parsed_dict['DIFFERENCE'] = numbers[0][2]

        return parsed_dict

    def funkenstoss_converter(self, dc):
        return dc

    def create_parquet(self, document):
        document = p.tag_document(document)
        df = pd.DataFrame(document)
        df.to_csv("EA1560.csv", sep=';', quotechar='"')


with open(r"data/EA1560.txt", "r") as f:
    all = f.read()

p = EA1560()

for tmp in p.tag_document(all):
    print(tmp)

p.create_parquet(all)
