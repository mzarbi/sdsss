from tq.tasks import add

add(5, 10)