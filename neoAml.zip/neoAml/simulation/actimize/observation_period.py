import pandas as pd
import numpy as np

from ..utils import constants


def get_loc(wanted_idx, idx_list, method):
    """Faster reimplementation of pd.get_loc"""
    if method == "ffill":
        wanted_idx = np.searchsorted(idx_list, wanted_idx, side="right")
        # Doing a ffill we need to substract 1 to the index
        wanted_idx = np.where(wanted_idx, wanted_idx-1, 0) 
        return wanted_idx
#     elif method == "bfill":
#         wanted_idx = np.searchsorted(idx_list, wanted_idx, side="right")
#         return wanted_idx
    else:
        raise Exception('Not implemented')


def find_begin_cumsum(daily_account_df):
    """Returns date in the dataframe after which to start the observation period"""
    n_days = pd.to_timedelta(
        daily_account_df[constants.RECURRENCE_PERIOD_NAME],
        unit="day"
    )
    wanted_idx = daily_account_df['VALUE_DATETIME'] - n_days
    df_index = np.asarray(daily_account_df.index)
    wanted_idx = get_loc(wanted_idx.values, df_index, method="ffill")
    return df_index[wanted_idx]


def list_hit_occurrences(base_dataset, hit_key, transaction_key, amount_key=None):
    """Performs Occurrence count and threshold over observation periods.
    
    Args:
        dataset: pd.DataFrame
            Postings or payments dataframe with hits only
        hit_key: string
            columns name with hit status
        transaction_key: string
            column name for transaction id, POS_ID or PAY_ID
           
    Returns:
        list of transaction keys for which an alert is generated
    """
    dataset = base_dataset.copy(deep=True)
    if hit_key not in dataset.columns:
        raise Exception(f"Cannot list hit occurrences: column {hit_key} not found")

    if dataset.dtypes[transaction_key] == np.int64 or \
       dataset.dtypes[transaction_key] == float:
        dataset["key_list"] = dataset[transaction_key].values[:, None].tolist()
    else:
        dataset["key_list"] = dataset[transaction_key]

    # Sum hits per day per account
    agg_funcs = {
        hit_key: 'count',
        constants.RECURRENCE_PERIOD_NAME: 'first',
        constants.NUMBER_OCCURRENCES_NAME: 'first',
        "key_list": list
    }
    if amount_key:
        agg_funcs[amount_key] = 'first'
    daily_df = dataset.groupby(["ACCOUNT_KEY", "VALUE_DATETIME"]).agg(agg_funcs) \
                      .reset_index().sort_values("VALUE_DATETIME", ignore_index=True)
    
    # Cumsum of hits per account over timespan
    daily_df['HIT_CUMSUM'] = daily_df.groupby(['ACCOUNT_KEY']).agg({
        hit_key: 'cumsum'
    })

    # Find beginning of observation period for each date
    # and sum hits over observation period
    list_accounts = daily_df['ACCOUNT_KEY'].unique()
    new_df_accounts = []
    for account in list_accounts:
        daily_account = daily_df[daily_df['ACCOUNT_KEY']==account].set_index(
            'VALUE_DATETIME', drop=False
        )
        if len(daily_account) == 0:
            continue

        daily_account['BEGIN_OCCURRENCES'] = find_begin_cumsum(daily_account)
        daily_account['OCCURRENCES_SPAN'] = \
            (daily_account['VALUE_DATETIME'] - daily_account['BEGIN_OCCURRENCES']).dt.days
        
        begin_df = daily_account.loc[daily_account['BEGIN_OCCURRENCES']]\
                                .reset_index(drop=True)

        daily_account = daily_account.reset_index(drop=True)
        begin_df.loc[
            daily_account['OCCURRENCES_SPAN'] < daily_account[constants.RECURRENCE_PERIOD_NAME],
            'HIT_CUMSUM'
        ] = 0

        daily_account['SUM_OCCURRENCES'] = daily_account['HIT_CUMSUM'] \
                                           - begin_df['HIT_CUMSUM']
        new_df_accounts.append(daily_account)

    occurrences_df = pd.concat(new_df_accounts, axis=0).reset_index(drop=True)

    # Filter hits on occurrence period
    sub_columns = ["ALERT_ID", transaction_key, "SUM_OCCURRENCES"]
    if amount_key:
        sub_columns.append(amount_key)
    filtered_keys = occurrences_df[
        occurrences_df['SUM_OCCURRENCES'] >= occurrences_df[constants.NUMBER_OCCURRENCES_NAME]
    ].explode("key_list")\
     .reset_index(drop=True)\
     .reset_index(drop=False)\
     .rename(columns={'index': 'ALERT_ID', 'key_list': transaction_key})[ # Get index as an ALERT_ID 
        sub_columns
    ]

    # Return list of all transaction ids matching occurrences criteria
    return filtered_keys.explode(transaction_key).reset_index(drop=True)
    
    

def filter_alerts(transactions, transaction_key, keys):
    """Filter transactions to return alerts.
    
    Args:
        transactions: pd.DataFrame
            Postings or payments dataframe
        transaction_key: string
            column name for transaction id, POS_ID or PAY_ID
        keys: pd.DataFrame
            dataframe of transaction keys for which an alert is generated with alert_id
            
    Returns:
        Dataframe with alerts filtered by observation period
    
    """
    keys[transaction_key] = keys[transaction_key].astype(str)
    transactions[transaction_key] = transactions[transaction_key].astype(str)
    transactions = keys.merge(transactions, on=transaction_key)
    return transactions


def detection_to_alerts(transactions, transaction_key, hit_key):
    """Filter transactions to return alerts.
    
    Args:
        transactions: pd.DataFrame
            Postings or payments dataframe
        transaction_key: string
            column name for transaction id, POS_ID or PAY_ID
        hit_key: string
            columns name with hit status
            
    Returns:
        Dataframe with alerts filtered by observation period
    """
    #Filter hits only
    transactions = transactions[transactions[hit_key]]
    if transactions.empty:
        return transactions
    return filter_alerts(
        transactions, transaction_key,
        list_hit_occurrences(transactions, hit_key, transaction_key)
    )