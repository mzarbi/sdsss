from .eft import ExcessiveFundsTransfers, get_submodel_name as get_submodel_name_eft
from .ftf import FlowThroughFunds, get_submodel_name as get_submodel_name_ftf
from .tsd import TransfersSensitiveDestinations, get_submodel_name as get_submodel_name_tsd

#we can probably do better for the get_sumodel_name function but for the moment it's fine
SUBMODEL_MAP = {
    "EFT": get_submodel_name_eft,
    "FTF": get_submodel_name_ftf,
    "TSD": get_submodel_name_tsd,
    "THV": get_submodel_name_tsd, #same as TSD
}