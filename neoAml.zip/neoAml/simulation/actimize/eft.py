import pandas as pd
import numpy as np

from .actimize import ActimizeModel
from .observation_period import detection_to_alerts
from ..utils import constants

# TODO: KPIs, metrics in class

def get_submodel_name(parameters, df):
    '''
    Add to transaction dataframe a column with submodel names
    
    Parameters
    ----------
    df: pandas Dataframe
    List of transactions
    '''
    if not hasattr(parameters, "eft_obj"):
        parameters.eft_obj = ExcessiveFundsTransfers({})

    df["SUBMODEL"] = parameters.eft_obj.get_submodel_name(df)


class ExcessiveFundsTransfers(ActimizeModel):
    """Implementation of Excessive Funds Transfer (EFT) Actimize model.
    Inherits from ActimizeModel object.

    ```python
    import pandas as pd
    import actimize

    path = "data\"

    postings = pd.read_csv(os.path.join(path, "postings.csv"))
    mapping = pd.read_csv(os.path.join(path, "Account_Client_Mapping.csv"))

    input_dataset = actimize.ExcessiveFundsTransfers.prepare_dataset(postings, mapping)

    eft_model = actimize.ExcessiveFundsTransfers(threshold_mapping=threshold_mapping, version="SAM3")
    hits = eft_model(input_dataset)

    hits.to_csv(os.path.join(path, "hits.csv"))
    ```

    --------------------------------------- SAM3 ---------------------------------------
    Parameters:
    * Threshold calculation formula = Avg+2STD
    * Minimum floor value = 1 M EUR
    * Default value = 10 K EUR
    * No cap value
    ------------------------------------------------------------------------------------

    --------------------------------------- SAM8 ---------------------------------------
    Comments:
    There are different rules for the threshold computation for the cash, cheques, cross borders
    and merged/shared group.

    (i) Cases:
    * Cash and cheques
    Rules : Percentile approach is not recommended, thresholds should be set by Local Compliance
    based on the applicable regulation.

    (ii) Cases:
    * Domestic transfers, 
    internal transfers (ie transfers between 2 clients in a given BNPP unit)
    * Cross border transfers
    * Shared Transactions (i.e. type of transactions which are not specific to one of the above
        buckets)

    Parameters:
    * Threshold calculation
        * Low risk client cluster: Percentile 95 %
        * Medium risk client cluster: Percentile 85 %
        * High risk client cluster: Percentile 75 %
    * Minimum floor value = 1 M EUR
    * Default value = 10 K EUR
    * No cap value
    ------------------------------------------------------------------------------------

    """

    def __init__(
        self,
        threshold_mapping: dict,
        default_value = 10_000,  # Update to 1M in 2020 ?
        version: str = "SAM8",
    ):
        """Class constructor and parameters of the model.

        Args:
            threshold_mapping: dict.
                Dictionary of client and population groups thresholds per BU.

            default_value: int
                Default value to 10000.

            version: str
                Default value to "SAM3". Can also be "SAM8".
        """
        super(ExcessiveFundsTransfers, self).__init__()

        self.version = version

        # Model parameters name and mapping with index in numpy order
        self.model_parameters = {
            'Is Whitelisted': 0,
            'No. of Occurrences': 1,
            'Recurrence Period (days)': 2,
            'Minimal Transaction Amount': 3,
            'Maximal Transaction Amount': 4
        }
        self.default_np_parameters = np.array([
            0, 1, 1, 1_000_000, np.nan
        ])
            
        self.threshold_mapping = threshold_mapping
        self.rule_id = "BNP-EFT-TRN-ALL-A-S01-EST"
        self.model = "EFT"
        
    def __call__(self, unused_params, dataset: pd.DataFrame) -> pd.DataFrame:
        """Performs transaction - posting or payment - analysis and generates corresponding
        hits if suspicious.

        This (magic) method must be overriden in a child class and contains three important
        steps :
        1. prepare_input_
        2. detection_step (including compute_score)
        3. generate_alerts (if detection_step returns True)

        Args:
            unused_params : Parameters object, here only for consistency purposes, do not use
            dataset (pd.DataFrame): output of the staticmethod prepare_dataset.

        Returns:
            A set of hits (pd.DataFrame).
        """
        # Add specialized model parameters for each transaction
        if dataset.empty:
            return dataset
    
        inv_params_idx = {v: k for k, v in self.model_parameters.items()}
        
        group_cols = ['ACCOUNT_KEY']
        if 'transaction_type' in dataset.columns:
            group_cols += ['transaction_type']
        
        # Extract data for parameters identification per account key
        accounts = dataset[
            ['BU', constants.CLUSTER_KEY] + group_cols
        ].groupby(group_cols)\
         .first().reset_index(drop=False)
        
        # Get corresponding parameters
        parameters = pd.concat([
            accounts[group_cols],
            accounts.apply(self.get_parameters_serie, axis=1) \
                    .rename(columns=inv_params_idx)
        ], axis=1)
                        
        # Join to original dataframe
        dataset = dataset.merge(parameters, on=group_cols)
                    
        # Compute the model
        dataset["EFT_Hit"] = ~dataset['Is Whitelisted'].astype(np.bool) & \
                             (dataset[constants.MAIN_AMNT_KEY] >= dataset['Minimal Transaction Amount'])

       # Generate alerts over recurrence period
        alerts = self.generate_alerts(dataset)
        if alerts is None:
            return pd.DataFrame()

        # Clean parameters from final alert results
        return alerts.drop(self.model_parameters.keys(), axis=1)

    
    def get_submodel_name(self, row):
        return constants.MODEL_FULL_NAMES[self.model]
    
    def get_default_np_parameters(self, row):
        return self.default_np_parameters

    def generate_alerts(self, transactions):
        """Generates hits for transactions following the detection_step method.
        This method must be overriden in a child class.
        Parameters
        ----------
        transactions: pd.Dataframe
        EFT hits above threshold before recurrence thresholds

        Returns:
            alerts filtered after recurrence thresholds.
        """
        if self.version == "SAM3" or 'transaction_type' not in transactions.columns:
            return detection_to_alerts(transactions, 'POS_ID', 'EFT_Hit')
        
        transaction_types = transactions["transaction_type"].unique()
        occurrence_hits = []
        for tr_type in transaction_types:
            occ_hits = detection_to_alerts(
                transactions[transactions["transaction_type"] == tr_type],
                'POS_ID',
                'EFT_Hit'
            )
            
            if occ_hits.empty:
                continue
            
            occ_hits['ALERT_ID'] = occ_hits['ALERT_ID'].astype(str) + "_" + tr_type
            occurrence_hits += [occ_hits]

        if not occurrence_hits:
            return None
        return pd.concat(occurrence_hits, axis=0)


    def get_config(self) -> dict:
        """Returns ActimizeModel config, i.e. a dictionary of the child model (object) parameters.
        This method must be overriden in a child class.

        Returns:
            config (dict): Input of from_config classmethod.
        """
        config = {
            "threshold_mapping": self.threshold_mapping,
            "default_value": self.default_value,
            "version": self.version,
        }
        return config
