import numpy as np
import pandas as pd

from .actimize import ActimizeModel
from .observation_period import detection_to_alerts
from ..utils import constants


#TAX_HAVENS = pd.read_csv(constants.TAX_HAVENS_FILE)
#TAX_HAVENS = TAX_HAVENS[TAX_HAVENS.Tax_Haven].reset_index(drop=True)


def get_submodel_name(parameters, df):
    '''
    Add to transaction dataframe a column with submodel names
    
    Parameters
    ----------
    df: pandas Dataframe
    List of transactions
    '''
    if not hasattr(parameters, "tsd_obj"):
        parameters.tsd_obj = TransfersSensitiveDestinations({})
        
    if constants.TSD_COUNTRY_KEY not in df.columns:
        raise Exception("Cannot get TSD submodel name without country risk")
        
    df["SUBMODEL"] = ""    
    for risk, model in constants.TSD_CODE_MODEL_MAPPING.items():
        df["SUBMODEL"][df[constants.TSD_COUNTRY_KEY]==risk] = model


class TransfersSensitiveDestinations(ActimizeModel):
    """Implementation of Transfers to/from High-Risk Destinations (TSD) Actimize model.
    Inherits from ActimizeModel object.

    ```python
    import pandas as pd
    import actimize

    path = "data/"

    payments = pd.read_csv(os.path.join(path, "payments.csv"))

    input_dataset = actimize.TransfersSensitiveDestinations.prepare_dataset(payments)

    tsd_model = actimize.TransfersSensitiveDestinations(version="SAM3")
    hits = tsd_model(input_dataset)

    hits.to_csv(os.path.join(path, "hits.csv"))
    ```

    --------------------------------------- SAM3 ---------------------------------------
    Risk Level (Low, Medium, High, Very High) is referred to Activity Rating

    Parameters:
    * Threshold calculation formula:
        * TSD3: Avg + [Low: 1.5; Medium: 1; High: 0.5; Very High: 0.5]*STD
        * TSD4: Avg + [Low: 1; Medium: 0.5; High: 0.25; Very High: 0.25]*STD
        * THV: N/A
    * No minimum floor value
    * Default value (minimum transaction value):
        * TSD3: 50 K EUR
        * TSD4: 100 EUR
        * THV: 1 K EUR
    * Cap value:
        * TSD3: 1 M EUR
        * TSD4: 150 K EUR or TSD3 value for risk rating group
        * THV: N/A

    TSD3/4 Logic
    ----------
    (1) Single Payment amount >= MINIMAL TRANSACTION VALUE threshold
    (2) The Highest risk country contained in the payment is part of Actimize HIGH RISK COUNTRY LIST
    TSD condition = (1) & (2)

    TSD3/4 Recurrence
    ---------------
    * Recurrence >= NO OF OCCURRENCES threshold value over RECURRENCE PERIOD (DAYS) threshold
    * This means that detection conditions (1) & (2) have to be met more than NO OF OCCURRENCES times over a
    period of days defined by RECURRENCE PERIOD (DAYS) threshold in order for a hit to be generated)

    ------------------------------------------------------------------------------------

    --------------------------------------- SAM8 ---------------------------------------
    Risk Level (Low, Medium, High) is referred to KYC Risk Level (client cluster)

    ------------------------------------------------------------------------------------

    """

    def __init__(
        self,
        threshold_mapping: dict,
        default_value: dict = {"TSD3": constants.DEFAULT_VALUES['TSD3'], "TSD4": constants.DEFAULT_VALUES['TSD4'],
                              "THV": constants.DEFAULT_VALUES['THV'], "LTH": constants.DEFAULT_VALUES['LTH']},
        version: str = "SAM3",
        model: str = "TSD",
    ):
        """Class constructor and parameters of the model.
        Note that
            - Tax Havens list is not considered as model parameters.
            - May consider following parameters:
                cap_value: dict = {"TSD3": 1_000_000, "TSD4": 150_000}

        Args:
            threshold_mapping: dict.
                Dictionary of client and population groups thresholds per BU.

            tax_havens: pd.DataFrame.
                Tax Havens list.

            default_value: dict.
                Default value to 1000.

            version: str.
                Default value to "SAM3". Can also be "SAM8".
        """
        super(TransfersSensitiveDestinations, self).__init__()

        self.version = version

        self.threshold_mapping = threshold_mapping
        #self.tax_havens = TAX_HAVENS
        self.default_value = default_value
         # Model parameters name and mapping with index in numpy order
        self.model_parameters = {
            'Is Whitelisted': 0,
            'No. of Occurrences': 1,
            'Recurrence Period (days)': 2,
            'Minimal Transaction Value': 3
        }
        self.default_np_parameters = {
            0: np.array([1, 1, 1, 1_000]),
            3: np.array([0, 1, 1, constants.DEFAULT_VALUES['TSD3']]),
            4: np.array([0, 1, 1, constants.DEFAULT_VALUES['TSD4']]),
            5: np.array([0, 1, 1, constants.DEFAULT_VALUES['THV']]),
            6: np.array([0, 1, 1, constants.DEFAULT_VALUES['LTH']])
        }
        self.model = model

    def __call__(self, unused_params, dataset: pd.DataFrame) -> pd.DataFrame:
        """Performs transaction - posting or payment - analysis and generates corresponding
        hits if suspicious.

        This (magic) method contains three important steps :
        1. prepare_input_
        2. detection_step
        3. generate_alerts (including compute_score)

        Args:
            unused_params : Parameters object, here only for consistency purposes, do not use
            dataset (pd.DataFrame): output of the staticmethod prepare_dataset.

        Returns:
            A set of hits (pd.DataFrame).
        """
        if dataset.empty:
            return dataset

        # Add specialized model parameters for each transaction
        inv_params_idx = {v: k for k, v in self.model_parameters.items()}
        parameters = dataset[
            ['ACCOUNT_KEY', 'BU', constants.CLUSTER_KEY, constants.TSD_COUNTRY_KEY]
        ].apply(self.get_parameters_serie, axis=1).rename(columns=inv_params_idx)
        if parameters.empty:
            return parameters
        
        dataset = pd.concat([dataset, parameters], axis=1)
        for key, val in self.model_parameters.items():
            dataset[key] = dataset[key].fillna(self.default_np_parameters[0][val]) 

        # Compute the model
        dataset[f"{self.model}_Hit"] = ~dataset['Is Whitelisted'].astype(np.bool) & \
                             (dataset[constants.MAIN_AMNT_KEY] >= dataset['Minimal Transaction Value'])

        # Generate alerts over recurrence period
        alerts = self.generate_alerts(dataset)
 
        # Clean parameters from final alert results
        return alerts.drop(self.model_parameters.keys(), axis=1)
    
    def get_submodel_name(self, row):
        if row[constants.TSD_COUNTRY_KEY] in constants.TSD_CODE_MODEL_MAPPING:
            return constants.TSD_CODE_MODEL_MAPPING[row[constants.TSD_COUNTRY_KEY]]
        return None
    
    def get_default_np_parameters(self, row):
        if row[constants.TSD_COUNTRY_KEY] in self.default_np_parameters:
            return self.default_np_parameters[row[constants.TSD_COUNTRY_KEY]]
        return self.default_np_parameters[0]
    
    def generate_alerts(self, dataset: pd.DataFrame) -> pd.DataFrame:
        """Generates alerts/hits from detected transactions following the detection_step method.
        Must invovle compute_score method and may depends on the observation period or
        number of occurrences...

        Returns:
            alerts: pd.DataFrame.
                Dataframe of alerts.
        """
        alerts_dataset = (
            dataset[dataset[f'{self.model}_Hit']]
            .sort_values(by=["TRANS_INSERT_DATE", "ACCOUNT_KEY"])
            .reset_index(drop=True)
        )
        if alerts_dataset.empty:
            return alerts_dataset
        return detection_to_alerts(alerts_dataset, 'PAY_ID', f'{self.model}_Hit')
    
    def get_config(self) -> dict:
        """Returns ActimizeModel config, i.e. a dictionary of the model (object) parameters.
        Note that Tax Havens list is not considered as model parameters.

        Returns:
            config (dict): Input of from_config classmethod.
        """
        config = {
            "threshold_mapping": self.threshold_mapping,
            "default_value": self.default_value,
            "version": self.version,
        }
        return config