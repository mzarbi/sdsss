import abc
import numpy as np
import pandas as pd

from ..utils import constants


class ActimizeModel:
    """Abstract class for Actimize models."""

    @abc.abstractmethod
    def __call__(self, dataset: pd.DataFrame) -> pd.DataFrame:
        """Performs transaction - posting or payment - analysis and generates corresponding
        hits if suspicious.

        This (magic) method must be overriden in a child class and contains three important
        steps :
        1. prepare_input_
        2. detection_step (including compute_score)
        3. generate_alerts (if detection_step returns True)

        Args:
            dataset (pd.DataFrame): output of the staticmethod prepare_dataset.

        Returns:
            A set of hits (pd.DataFrame).
        """
        raise NotImplementedError("Actimize models must override __call__")

    
    def get_parameters(
        self,
        account_num: str,
        submodel: str = None,
        cluster: str = None,
        transaction_type: str = None,
        default_np_params: np.array = None,
    ) -> np.array:
        '''Fetch model parameters as numpy array
        
        Args:
            account_num: string for account number
            submodel: string for full text name of the model
            cluster: string representing cluster
            default_np_params: np.array with default value to use in case not found
        
        Returns:
            np.array of model parameters
        '''
        res = default_np_params.copy()
        params_mapping = self.threshold_mapping
        
        if account_num in params_mapping['whitelist'] or submodel is None:
            res[0] = 1
            return res
        
        if self.model in params_mapping['user']:
            for param, value \
                in params_mapping['user'][self.model][submodel].items():
                if param in self.model_parameters:
                    if isinstance(value, dict):
                        if transaction_type in value:
                            res[self.model_parameters[param]] = value[transaction_type]
                    else:
                        res[self.model_parameters[param]] = value
        
        if self.model in params_mapping["cluster"]:
            if submodel in params_mapping["cluster"][self.model]:
                for param, values \
                    in params_mapping["cluster"][self.model][submodel].items():
                    if self.version == "SAM8" and self.model == "EFT" \
                       and transaction_type in values:
                        if cluster in values[transaction_type]:
                            res[self.model_parameters[param]] = \
                            values[transaction_type][cluster]
                
                    elif cluster in values and param in self.model_parameters:
                        res[self.model_parameters[param]] = values[cluster]
        
        if params_mapping['individual'] is None:
            return res

        if self.model in params_mapping['individual']:
            if submodel in params_mapping["individual"][self.model]:
                for param,values \
                    in params_mapping['individual'][self.model][submodel].items():
                    if self.model == "EFT" and transaction_type in values:
                        if account_num in values[transaction_type]\
                            and param in self.model_parameters:
                            res[self.model_parameters[param]] = values[transaction_type][account_num]
                    elif  account_num in values and param in self.model_parameters:
                        res[self.model_parameters[param]] = values[account_num]
                        
        return res
            
    
    def get_parameters_serie(self, row):
        '''Fetch model parameters as pd.Series
        Args:
            row: pd.Series with input keys "BU", "ACCOUNT_KEY", cluster

        Returns:
            pd.Series of model parameters
        '''
        transaction_type = None
        if 'transaction_type' in row:
            transaction_type = row.transaction_type
        
        return pd.Series(
            self.get_parameters(
                row.ACCOUNT_KEY,
                self.get_submodel_name(row),
                row[constants.CLUSTER_KEY],
                transaction_type,
                self.get_default_np_parameters(row)
            )
        )
    
    def get_parameters_df(
        self,
        dataset,
        columns=['ACCOUNT_KEY', 'BU', constants.CLUSTER_KEY]
    ):
        '''Fetch model parameters for a whole dataframe, assuming they are constant
           for all transactions of an account. Only true for FTF.
           
        Args:
            dataset: pd.DataFrame of transactions
            columns: minimal set of columns to use for retrieving parameters
            
        Returns:
            pd.DataFrame of transactions with parameters added as new columns
        '''
        inv_params_idx = {v: k for k, v in self.model_parameters.items()}
        
        # Extract data for parameters identification per account key
        accounts = dataset[columns].groupby(['ACCOUNT_KEY'])\
                                   .first().reset_index(drop=False)
        if len(accounts) == 0:
            constants.LOGGER.info("Get parameters for acimize models: No accounts found in dataset")
            return accounts
        
        # Get corresponding parameters
        parameters = pd.concat([
            accounts['ACCOUNT_KEY'],
            accounts.apply(self.get_parameters_serie, axis=1) \
                    .rename(columns=inv_params_idx)
        ], axis=1)
                        
        # Join to original dataframe
        return dataset.merge(parameters, on='ACCOUNT_KEY')

    
    @abc.abstractmethod
    def get_submodel_name(self, row):  # May be redundant with prepare_dataset...
        """Helper to return Name of submodel depending on specificities of the transaction.

        Args:
            row: pd.Serie
            data of one transaction
        Returns:
            String containing matchin submodel name
        """
        raise NotImplementedError("Actimize models must override get_submodel_name")

    @abc.abstractmethod
    def generate_alerts(self, transactions):  # What's happen with alerts composed by several hits ?
        """Generates hits for transactions following the detection_step method.
        This method must be overriden in a child class.

        Returns:
            hit.
        """
        raise NotImplementedError("Actimize models must override generate_alerts")

    @abc.abstractmethod
    def get_config(self) -> dict:
        """Returns ActimizeModel config, i.e. a dictionary of the child model (object) parameters.
        This method must be overriden in a child class.

        Returns:
            config (dict): Input of from_config classmethod.
        """
        raise NotImplementedError("Actimize models must override get_config")

    @classmethod
    def from_config(cls, config: dict):
        """Instantiates an ActimizeModel class from its config.

        Args:
            config (dict): Output of `get_config()`.

        Returns:
            An ActimizeModel instance.
        """
        return cls(**config)