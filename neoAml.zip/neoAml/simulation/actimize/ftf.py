import os
import numpy as np
import pandas as pd
import tqdm
import pyarrow

from .actimize import ActimizeModel
from ..utils import constants

from ..utils.parquet import get_transactions_by_chunk, ParquetStreamer
from ..utils.utils import lookup
from .observation_period import find_begin_cumsum, filter_alerts, list_hit_occurrences

tqdm.tqdm().pandas()


def get_submodel_name(parameters, df):
    '''
    Add to transaction dataframe a column with submodel names
    
    Parameters
    ----------
    df: pandas Dataframe
    List of transactions
    '''
    if not hasattr(parameters, "ftf_obj"):
        parameters.ftf_obj = FlowThroughFunds({})
    df["SUBMODEL"] = parameters.ftf_obj.get_submodel_name(df)


def agg_lookback_posid(parameters, x, daily_account):
    """Agglomerate transaction keys for the lookback period
       ending at a specified row.
    
    Args:
        x: pd.Serie
            Row for one transaction
        daily_account: pd.DataFrame
           
    Returns:
        list of transaction keys agglomerated over the observation period.
    """
    if not x.FTF_Hit:
        return []
    loc1 = daily_account.index.get_loc(x.BEGIN_LOOKBACK, method='bfill')

    # If no exact match is found, reject this line as dataset was truncated
    if daily_account['VALUE_DATETIME'].iloc[loc1] != x['BEGIN_LOOKBACK']:
        return []
    loc2 = daily_account.index.get_loc(x.VALUE_DATETIME)
    loc1 += (x.LOOKBACK_SPAN >= parameters.LOOKBACK_PERIOD) 
    res = sum(list(daily_account['POS_ID'].iloc[loc1:loc2+1]), [])
    return res


def get_lookback_sums(parameters, dataset):
    '''Compute lookback sums per account on credit and debit
    
    Args:
        dataset: pd.Dataframe
            Postings
            
    Returns:
        pd.Dataframe of lookback sums per account
    '''
    if dataset.empty:
        return dataset

    dataset['POSTING_DIRECTION'] = dataset['TRANS_TYPE_CD'].str[0]
    
    constants.LOGGER.info("FTF compute incoming and outgoing sums over lookback")
    # Daily sum of credit and debit per account
    daily_df = dataset.groupby(["ACCOUNT_KEY", "POSTING_DIRECTION", "VALUE_DATETIME"])\
                      .agg({
                          constants.MAIN_AMNT_KEY: 'sum',
                          'POS_ID': list,
                          'BU': 'first',
                          constants.CLUSTER_KEY: 'first'
                      })\
                      .reset_index().sort_values("VALUE_DATETIME", ignore_index=True)
    
    # Separate credit and debit on 2 columns, per date
    daily_df['CREDIT'] = daily_df[
        (daily_df['POSTING_DIRECTION']=='Credit') \
        | (daily_df['POSTING_DIRECTION']=='C')
    ][constants.MAIN_AMNT_KEY]
    daily_df['DEBIT'] = daily_df[
        (daily_df['POSTING_DIRECTION']=='Debit') \
        | (daily_df['POSTING_DIRECTION']=='D')
    ][constants.MAIN_AMNT_KEY]

    # Reduce eventual 0 between credits and debits per date per account
    daily_df = daily_df.fillna(0.0)\
                       .drop(['POSTING_DIRECTION', constants.MAIN_AMNT_KEY], axis=1) \
                       .groupby(['ACCOUNT_KEY', 'VALUE_DATETIME']) \
                       .agg({
                           'CREDIT': 'sum', 'DEBIT': 'sum',
                           'POS_ID': (lambda x: sum(list(x),[])),
                           'BU': 'first',
                           constants.CLUSTER_KEY: 'first'
                       }) \
                       .reset_index()

    # Cumulative sums for credits and debits per account
    cumsum = daily_df.groupby(['ACCOUNT_KEY']) \
                     .agg({
                         'CREDIT': 'cumsum',
                         'DEBIT': 'cumsum'
                     }) \
                     .rename(columns={
                         'CREDIT': 'CUMSUM_CREDIT',
                         'DEBIT':'CUMSUM_DEBIT'
                     })
    daily_df = pd.concat([daily_df, cumsum], axis=1)

    list_accounts = daily_df['ACCOUNT_KEY'].unique()

    # Lookback sums per day for credits and debits
    new_df_accounts = []
    for account in list_accounts:
        daily_account = daily_df[daily_df['ACCOUNT_KEY']==account].set_index(
            'VALUE_DATETIME', drop=False
        )
        if len(daily_account) == 0:
            continue

        daily_account[constants.RECURRENCE_PERIOD_NAME] = parameters.LOOKBACK_PERIOD
        daily_account['BEGIN_LOOKBACK'] = find_begin_cumsum(daily_account)
        daily_account['LOOKBACK_SPAN'] = \
            (daily_account['VALUE_DATETIME'] - daily_account['BEGIN_LOOKBACK']).dt.days

        begin_df = daily_account.loc[daily_account['BEGIN_LOOKBACK']]\
                                .reset_index(drop=True)

        daily_account = daily_account.reset_index(drop=True)
        is_origin = daily_account['LOOKBACK_SPAN'] < parameters.LOOKBACK_PERIOD
        begin_df.loc[is_origin, 'CUMSUM_CREDIT'] \
            = begin_df.loc[is_origin, 'CUMSUM_DEBIT'] = 0

        daily_account['SUM_INCOMING'] = daily_account['CUMSUM_CREDIT'] \
                                        - begin_df['CUMSUM_CREDIT']
        daily_account['SUM_OUTGOING'] = daily_account['CUMSUM_DEBIT'] \
                                        - begin_df['CUMSUM_DEBIT']

        new_df_accounts += [daily_account]

    return pd.concat(new_df_accounts, axis=0).reset_index(drop=True)


class FlowThroughFunds(ActimizeModel):
    """Implementation of Flow Through Funds (FTF) Actimize model.
    Inherits from ActimizeModel object.

    ```python
    import pandas as pd
    import actimize

    path = "data\"

    postings = pd.read_csv(os.path.join(path, "postings.csv"))

    input_dataset = actimize.FlowThroughFunds.prepare_dataset(postings)

    ftf_model = actimize.FlowThroughFunds(version="SAM3")
    hits = ftf_model(input_dataset)

    hits.to_csv(os.path.join(path, "hits.csv"))
    ```

    --------------------------------------- SAM3 ---------------------------------------
    Parameters:

    ------------------------------------------------------------------------------------

    --------------------------------------- SAM8 ---------------------------------------

    ------------------------------------------------------------------------------------

    """

    def __init__(
        self,
        threshold_mapping: dict,
        version: str = "SAM3",
        lookback_sums = None
    ):
        """Class constructor and parameters of the model.

        Args:
            threshold_mapping: dict.
                Dictionary of client and population groups thresholds per BU.

            version: str
                Default value to "SAM3". Can also be "SAM8".
        """
        super(FlowThroughFunds, self).__init__()

        self.version = version  
                
        self.threshold_mapping = threshold_mapping        
        self.model_parameters = {
            'Is Whitelisted': 0,
            'No. of Occurrences': 1,
            'Recurrence Period (days)': 2,
            'Ratio Lower Bound': 3,
            'Ratio Upper Bound': 4,
            'Sum Lower Bound': 5
        }
        self.default_np_parameters = np.array([
            0, 1, 2, 90, 110, 10_000
        ])
        
        self.threshold_mapping = threshold_mapping
        
        self.model = "FTF"
        self.rule_id = "BNP-FTF-TRN-ALL-A-B02-FTR"
        
        self.lookback_sums = lookback_sums

        
    def __call__(self, parameters, dataset: pd.DataFrame) -> pd.DataFrame:
        """Performs transaction - posting or payment - analysis and generates corresponding
        hits if suspicious.

        This (magic) method must be overriden in a child class and contains three important
        steps :
        1. prepare_input_
        2. detection_step (including compute_score)
        3. generate_alerts (if detection_step returns True)

        Args:
            dataset (pd.DataFrame): output of the staticmethod prepare_dataset.

        Returns:
            A set of hits (pd.DataFrame).
        """
        # Compute lookback sums for credits and debits

        if self.lookback_sums is None:
            lookback_df = get_lookback_sums(parameters, dataset)
        else:
            lookback_df = self.lookback_sums[
                self.lookback_sums['ACCOUNT_KEY'].isin(dataset['ACCOUNT_KEY'].unique())
            ]


        # Detection step
        constants.LOGGER.info("FTF performs detection step")
        
        lookback_df = self.get_parameters_df(lookback_df)
        withdebit_df = lookback_df[lookback_df['SUM_INCOMING'] > 0.0]

        if withdebit_df.empty:
            return withdebit_df
        lookback_df["RATIO"] = \
            100.0 * withdebit_df['SUM_INCOMING'] / withdebit_df['SUM_OUTGOING']
        lookback_df["RATIO"] = lookback_df["RATIO"].fillna(0.0)
        lookback_df["FTF_Hit"] = ~lookback_df['Is Whitelisted'].astype(np.bool) & \
            (lookback_df['RATIO'] >= lookback_df['Ratio Lower Bound']) & \
            (lookback_df['RATIO'] <= lookback_df['Ratio Upper Bound']) & \
            (lookback_df['SUM_INCOMING'] >= lookback_df['Sum Lower Bound'])

        # Agg POS_ID over lookback for hitted dates
        constants.LOGGER.info("FTF Agg POS_ID over lookback")
        new_df_accounts = []
        list_accounts = lookback_df['ACCOUNT_KEY'].unique()

        for account in list_accounts:
            daily_account = lookback_df[lookback_df['ACCOUNT_KEY']==account].set_index(
                'VALUE_DATETIME', drop=False
            )
            if len(daily_account) == 0:
                continue

            new_df_accounts += [pd.concat([
                daily_account,
                daily_account.apply(lambda x: agg_lookback_posid(parameters, x, daily_account), axis=1)
            ], axis=1).reset_index(drop=True)]
       
        lookback_df = pd.concat(new_df_accounts, axis=0).reset_index(drop=True) \
                        .drop('POS_ID', axis=1).rename(columns={0: 'POS_ID'})

        # Filters on dataset for hits found with observation period threshold
        constants.LOGGER.info("FTF filters alert from base dataset")
        lookback_df = lookback_df[lookback_df['FTF_Hit']].reset_index(drop=True)
        if lookback_df.empty:
            return lookback_df
        
        filtered_dataset = filter_alerts(
            dataset, 'POS_ID',
            list_hit_occurrences(lookback_df, 'FTF_Hit', 'POS_ID', 'SUM_INCOMING')
        )
        filtered_dataset['FTF_Hit'] = True
        return filtered_dataset
    
    def get_submodel_name(self, row):
        """Constant reference to complete sub model names, 
           as used in parameters definition
           
           Returns:
               string of complete FTF sub model name 
           """
        return constants.MODEL_FULL_NAMES[self.model]
    
    def get_default_np_parameters(self, row):
        """Constant reference to default FTF parameters
        
        Returns:
            np.array of default FTF parameters
        """
        return self.default_np_parameters

    def generate_alerts(self):
        """Generates hits for transactions following the detection_step method.
        This method must be overriden in a child class.

        Returns:
            alerts.
        """
        return

    def get_config(self) -> dict:
        """Returns model config, i.e. a dictionary of parameters.
        This method is overriden in a child class.

        Returns:
            config (dict): Input of from_config classmethod.
        """
        config = super(FlowThroughFunds, self).get_config()
        config.update(
            {
                "threshold_mapping": self.threshold_mapping,
                "lower_bound_ratio": self.lower_bound_ratio,
                "upper_bound_ratio": self.upper_bound_ratio,
                "default_value": self.default_value,  # default_value for FTF : Sum Lower Bound
            }
        )
        return config
        

def get_ftf_lookback_sums(parameters, key, thresholds):

    inputfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'processed/CTP_{}_{}_{}.parquet'.format(
            parameters.BU,
            'Postings',
            key
        )
    )

    ftf_counts = []
    for chunk in tqdm.tqdm(get_transactions_by_chunk(inputfile)):
        # filter whitelisted accounts for FTF model
        chunk = chunk[~chunk['ACCOUNT_KEY'].isin(thresholds['model_whitelist']['FTF'])]\
        .reset_index(drop=True)    
        
        account_map = chunk.groupby(['ACCOUNT_KEY'])[[
            'CLIENTNUM', 'CRDS_CODE', constants.RISK_SCORE_KEY
        ]] \
                           .first().reset_index(drop=False)
        chunk["VALUE_DATETIME"] = lookup(chunk["TRANS_INSERT_DATE"])
        chunk = chunk.groupby("POS_ID")\
               .first()\
               .reset_index(drop=False)
        
        if "CLUSTER_ID" not in chunk.columns:
            chunk["CLUSTER_ID"] = ""
        
        ftf_hits = get_lookback_sums(parameters, chunk)
        ftf_hits = ftf_hits.drop(["Recurrence Period (days)"], axis=1)
        if ftf_hits.empty:
            continue
            
        ftf_hits = ftf_hits.merge(account_map, how='left', on='ACCOUNT_KEY')
        ftf_hits['TRANS_INSERT_DATE'] = ftf_hits['VALUE_DATETIME']
                
        ftf_counts += [ftf_hits]

    return pd.concat(ftf_counts, axis=0)

def compute_lookback_sums(parameters, thresholds):
    lookback_sums = pyarrow.Table.from_pandas(get_ftf_lookback_sums(parameters, 'RAW', thresholds))
    outfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        f'processed/FTF_lookback_sums_{parameters.BU}_RAW.parquet'
    )
    writer = ParquetStreamer(
        outfile,
        lookback_sums.schema
    )
    writer.write_table(lookback_sums)