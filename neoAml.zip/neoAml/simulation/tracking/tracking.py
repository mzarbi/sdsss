import os
import pandas as pd
import mlflow
from mlflow.tracking import MlflowClient

from ..utils import constants

def mlflow_tracking(parameters):
    client = MlflowClient()
        
    MLFLOW_EXPERIMENT_KEY = parameters.BU
    
    for model in parameters.LIST_MODEL:
                    
        RUN_KEY = parameters.EXPERIMENT_KEY
        
        current_experiment = mlflow.get_experiment_by_name(MLFLOW_EXPERIMENT_KEY)
        if current_experiment == None:
            experiment_id = mlflow.create_experiment(MLFLOW_EXPERIMENT_KEY)
        if current_experiment.lifecycle_stage == "deleted":
            client.restore_experiment(current_experiment.experiment_id)
        
        mlflow.set_experiment(MLFLOW_EXPERIMENT_KEY)

        with mlflow.start_run(run_name=RUN_KEY):
            os.popen('cp ./.env ./env.txt') 
            mlflow.log_artifact("./env.txt")
            os.remove("./env.txt")
            
            if 'KPIS' in parameters.PIPELINE_STEPS:
                kpis_file = os.path.join(constants.READ_WRITE_DATA_PATH, parameters.BU, "kpis", (f'hit_kpis_{parameters.EXPERIMENT_KEY}') +\
                                        (f'_{parameters.KPIS.BASELINE}' if parameters.KPIS.BASELINE is not None else '') +\
                                        ('.csv'))
                hit_stats = pd.read_csv(kpis_file, sep=";")
                mlflow.log_artifact(kpis_file)
                current_stats = hit_stats[(hit_stats["Model"]==model) & (hit_stats["Business Unit"]==parameters.BU)].to_dict(orient="record")[0]
                mlflow.log_param("model", model)
                mlflow.log_param("pipeline steps", parameters.PIPELINE_STEPS)
                numerator = current_stats["S-B+L1"] + current_stats["S-B+N"] - current_stats["S+B-L1"] - current_stats["S+B-N"]
                denominator = current_stats["S+B+L2+"] + current_stats["S+B-L2+"] + current_stats["S-B+L2+"] + current_stats["S-B-L2+"] +\
                                current_stats["S+B+L1"] + current_stats["S+B-L1"] + current_stats["S-B+L1"] + current_stats["S-B-L1"]
                mlflow.log_metric("noise reduction", numerator/denominator)
                numerator = current_stats["S+B+L1"]
                denominator = current_stats["S+B+L1"] + current_stats["S-B+L2+"]
                mlflow.log_metric("L2p recall baseline", numerator/denominator)
                numerator = current_stats["S+B+L1"] + current_stats["S+B-L2+"]
                denominator = current_stats["S+B+L1"] + current_stats["S+B-L2+"] + current_stats["S-B+L2+"] + current_stats["S-B-L2+"]
                mlflow.log_metric("L2p recall alerts", numerator/denominator)