import os
import pyarrow.parquet as pq
import pandas as pd

from ..thresholds import utils_thresholds
from ..thresholds.base_thresholds import ThresholdHandler
from ..utils import constants

from ..utils.utils import filter_transactions, update_min


class EFTThresholdHandler(ThresholdHandler):
    def __init__(self, parameters, **kwargs):
        super().__init__(parameters, **kwargs)
        self.cap_value = None
        self.amount_key = constants.MAIN_AMNT_KEY
        self.model = "EFT"
        self.model_full_name = constants.MODEL_FULL_NAMES[self.model]
        self.threshold_name = constants.MODEL_THRESHOLD_NAME[self.model]
        self.score_name = constants.MODEL_SCORE_NAME[self.model]
        self.default_value = constants.DEFAULT_VALUES[self.model] * self.parameters.LOCAL_CURRENCY_RATE
        self.outliers = {}
        if hasattr(parameters, "EFT_CONSTANT_THRESHOLDS"):
            self.eft_constant_thresholds = parameters.EFT_CONSTANT_THRESHOLDS
        else:
            self.eft_constant_thresholds = {}
        self.build_default_thresholds()

    def open_transactions(self, whitelist, transactions_key, lookback_sums_key):
        inputfile = os.path.join(
            constants.READ_WRITE_DATA_PATH, self.business_unit,
            'processed/CTP_{}_{}_{}.parquet'.format(
                self.business_unit,
                "Postings",
                transactions_key
            )
        )
        cols_to_load = [
            constants.TRANS_DATE_KEY, "CLIENTNUM", "ACCOUNT_KEY",
            constants.MAIN_AMNT_KEY, constants.RISK_SCORE_KEY,
            constants.MODEL_TRANSACTION_KEY[self.model],
            "transaction_type"
        ]

        input_schema = pq.read_schema(inputfile)
        if constants.CLUSTER_KEY in input_schema.names:
            cols_to_load += [constants.CLUSTER_KEY]
        elif "POPULATION_GROUP_ID" in input_schema.names:
            constants.LOGGER.info("Thresholds computation use default clustering")
            cols_to_load += ["POPULATION_GROUP_ID"]
        else:
            raise Exception("No cluster column found in dataset")
        if "transaction_type" not in input_schema.names:
            raise Exception(
                "Cannot compute EFT thresholds without transaction_type column"
            )
            
        self.transactions = pq.read_table(inputfile, columns=cols_to_load).to_pandas()
        self.transactions = utils_thresholds.clean_transactions(
            self.transactions,
            whitelist
        )
        self.minimum_hit_amount = self.get_hits_amounts()
        self.remove_sct_from_minimum_escalations()
        
        self.get_account_cluster_mapping()
        self.transactions = filter_transactions(
            self.transactions,
            self.parameters.ANALYSIS_DATES['THRESHOLDS_TRAIN']
       )

    def handle_sct_alerts(self):
        ''' Temporary adds sct escalations to minimum hit amounts and
            outliers accounts before computing individual thresholds.
            Accounts with SCT escalations have thresholds on EFT
            adjusted to the min amount of escalations
        '''
        self.sct_outliers_accounts = []
        for rule, alerts_per_rules in self.minimum_hit_amount.items():
            for group, alerts_per_group in alerts_per_rules.items():
                if "test_sct" in alerts_per_group:
                    self.sct_outliers_accounts += [group]
                    self.outliers[self.rule] += [group]
                    self.minimum_hit_amount[rule][group]["test"] = \
                        self.minimum_hit_amount[rule][group]["test_sct"]

    def remove_sct_from_minimum_escalations(self):
        ''' Put minimum escalation hits of accounts with SCT escalations
            in outliers and remove them from cluster list, as such accounts
            are necessarily outliers.
        '''
        list_sct_accounts = set()
        for rule, alerts_per_rules in self.minimum_hit_amount.items():
            for group, alerts_per_group in alerts_per_rules.items():
                if "test_sct" in alerts_per_group:
                    list_sct_accounts.add(group)
                    
        for rule, alerts_per_rules in self.minimum_hit_amount.items():
            for group, alerts_per_group in alerts_per_rules.items():
                # This is an individual and not a cluster
                if "test_sct" in alerts_per_group:
                    continue
                to_remove = list_sct_accounts & set(alerts_per_group.keys())
                for account in to_remove:
                    self.minimum_hit_amount[rule][group].pop(account, None)

    def remove_sct_from_outliers(self):
        ''' Clear sct escalations from outliers list, so as to differentiate
            with specific outliers accounts that do not propagate their
            thresholds to other accounts of the same client, whereas accounts
            with SCT escalations do. (see fn. fill_missing_accounts_thresholds)
        '''
        for sct_account in self.sct_outliers_accounts:
            if sct_account in self.outliers[self.rule]:
                self.outliers[self.rule].remove(sct_account)

    def compute_cluster_thresholds(self):
        ''' Compute thresholds for clusters of EFT model
        '''
        for bucket, threshold in self.eft_constant_thresholds.items():
            self.thresholds["cluster"][self.model][self.model_full_name]\
                           [self.threshold_name][bucket] = {}
            utils_thresholds.fill_missing_thresholds(
                threshold,
                self.thresholds["cluster"][self.model][self.model_full_name]\
                               [self.threshold_name][bucket],
                self.cluster_mapping
            )

        for bucket, transactions in self.transactions.groupby(["transaction_type"]):
            if bucket not in self.parameters.BUCKETS:
                continue
                
            self.rule = constants.MODEL_FULL_NAMES["EFT"] + f" - {bucket}"
            if self.rule not in self.outliers:
                self.outliers[self.rule] = []
                
            if bucket in self.eft_constant_thresholds:
                continue
                
            self.min_value = self.parameters.EFT_BUCKET_MIN_VALUE[bucket]
            if self.min_value is not None:
                self.min_value *= self.parameters.LOCAL_CURRENCY_RATE


            transactions = self.get_transactions_without_outliers(transactions)

            self.thresholds["cluster"][self.model][self.model_full_name]\
                           [self.threshold_name][bucket] = {}
            self.thresholds["cluster"][self.model][self.model_full_name] \
                           [self.threshold_name][bucket] = \
                self.compute_group_threshold(
                    transactions,
                    constants.CLUSTER_KEY,
                )

            if self.compute_outliers:
                self.compute_outliers_with_significantly_above_transactions(
                    transactions,
                    "ACCOUNT_KEY",
                    self.thresholds["cluster"][self.model][self.model_full_name]\
                                   [self.threshold_name][bucket]
                )

            utils_thresholds.fill_missing_thresholds(
                self.default_value,
                self.thresholds["cluster"][self.model][self.model_full_name]\
                               [self.threshold_name][bucket],
                self.cluster_mapping
            )

            utils_thresholds.fill_new_clients_clusters(
                self.thresholds["cluster"][self.model][self.model_full_name]\
                               [self.threshold_name][bucket],
                self.cluster_mapping
            )

    def compute_individual_thresholds(self):
        
        self.individual_accounts = set()

        for bucket, transactions in self.transactions.groupby(["transaction_type"]):
            if bucket not in self.parameters.BUCKETS:
                continue
            self.rule = "Excessive Single Transactions - " + bucket
            self.handle_sct_alerts()
            if self.outliers and self.rule in self.outliers:
                accounts = self.outliers[self.rule]
            else:
                accounts = []

            bucket_transactions = transactions[
                (transactions[constants.CLUSTER_KEY] == "0") \
                | transactions["ACCOUNT_KEY"].isin(accounts)
            ]
            if bucket_transactions.empty:
                continue

            self.thresholds["individual"]["EFT"][self.model_full_name] \
                           [self.threshold_name][bucket] = {}
            self.thresholds["individual"]["EFT"][self.model_full_name]\
                               [self.threshold_name][bucket] = \
                self.compute_group_threshold(
                    bucket_transactions,
                    "ACCOUNT_KEY",
                )

            # For accounts in cluster 0, set minimum of individual thresholds to all accounts
            self.thresholds["individual"]["EFT"][self.model_full_name]\
                               [self.threshold_name][bucket] = \
            self.fill_missing_accounts_thresholds(
                self.thresholds["individual"]["EFT"][self.model_full_name]\
                               [self.threshold_name][bucket]
            )
            
            self.individual_accounts = \
                self.individual_accounts.union(set(self.outliers[self.rule]))

            self.remove_sct_from_outliers()

        self.individual_accounts = list(self.individual_accounts)
        self.escalations_audit_trail.loc[
            (self.escalations_audit_trail["CLIENT_RISK"] != "2-HIGH") \
            & (self.escalations_audit_trail["RULE_ID_V3"] == "BNP-SCT-RSK-ACT-P-D01-EAT"),
            "THRESHOLD_OVERRIDE"
        ] = "NOT ELIGIBLE SCT ESCALATION, CLIENT NOT HIGH RISK ANYMORE"
        
    def get_truth_alerts(self, alert_cols):
        raw_alerts_file = os.path.join(
            constants.READ_WRITE_DATA_PATH, self.business_unit, 'alerts',
            '{}_{}_{}.parquet'.format("EFT", self.business_unit, 'truth')
        )
        truth = pd.read_parquet(
            raw_alerts_file,
            engine='pyarrow',
            columns=alert_cols
        )

        raw_sct_alerts_file = os.path.join(
            constants.READ_WRITE_DATA_PATH, self.business_unit, 'alerts',
            '{}_{}_{}.parquet'.format('SCT', self.business_unit, 'truth')
        )
        if os.path.isfile(raw_sct_alerts_file):
            truth_sct = pd.read_parquet(
                raw_sct_alerts_file,
                engine='pyarrow',
                columns=alert_cols
            )
            truth = pd.concat([truth, truth_sct], axis=0, ignore_index=True)
        truth["RULE_ID_V3"] = truth["RULE_ID"]
        truth['RULE_ID'] = truth['RULE_ID'].map(self.parameters.RULE_ID_SUBMODEL_MAP) 
        self.transactions[constants.MODEL_TRANSACTION_KEY["EFT"]] = \
                self.transactions[constants.MODEL_TRANSACTION_KEY["EFT"]].astype(str)
        return truth

    def merge_truth_transactions(self, truth):
        merged_alerts = pd.merge(
            truth, self.transactions[[
                constants.MODEL_TRANSACTION_KEY["EFT"],
                'transaction_type',
                constants.CLUSTER_KEY,
                constants.MAIN_AMNT_KEY,
                'CLIENTNUM'
            ]].drop_duplicates(),
            how='left', on=constants.MODEL_TRANSACTION_KEY["EFT"]
        )
        merged_alerts["RULE_ID"] = merged_alerts["RULE_ID"] \
            + " - " + merged_alerts["transaction_type"]
        return merged_alerts
                          
    def postprocess_minimum_hits(
        self, clusters_minimum_hits_train, truth_test,
        individual_truth_test, recall_test
    ):
        individual_minimum_sct_hits_test = self.interpolate_recall_hits(
            pd.concat([truth_test, individual_truth_test], axis=0), ['CLIENTNUM'],
            recall_test, self.party_account_mapping, model="SCT"
        )
        utils_thresholds.add_key_to_dict(individual_minimum_sct_hits_test, 'test_sct')
        clusters_minimum_hits_train = update_min(
            clusters_minimum_hits_train, individual_minimum_sct_hits_test
        )
        return clusters_minimum_hits_train
    
    def prepare_minimum_hits_dataframe(self, df, group, model):
        list_group = ['RULE_ID'] + group
        if model == "SCT":
            df = df[df.RULE_ID_V3 == 'BNP-SCT-RSK-ACT-P-D01-EAT']
            df['INTERPOLATED_AMOUNT'] = df[constants.MAIN_AMNT_KEY]
            df['CLUSTER_RISK'] = df['CLIENTNUM'].map(self.kyc_risk_mapping)
            df = df[df.CLUSTER_RISK == '2-HIGH']
            return df, list_group
                          
        df = df[df.RULE_ID_V3 == 'BNP-EFT-TRN-ALL-A-S01-EST']

        #list_group = ['transaction_type'] + group
        df['INTERPOLATED_AMOUNT'] = df[constants.MAIN_AMNT_KEY]
        return df, list_group
   