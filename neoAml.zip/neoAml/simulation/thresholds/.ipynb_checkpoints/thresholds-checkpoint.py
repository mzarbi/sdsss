import os
import pickle
import pandas as pd

from ..thresholds import tsd, ftf, eft
from ..utils import constants

from ..utils.serialization import load_parameters
from ..thresholds.utils_thresholds import get_kyc_risk_mapping, get_cluster_mapping_from_postings

def generate_thresholds(parameters):
    '''Compute thresholds from transaction data'''
    THRESHOLD_CLASSES = {
        "EFT": eft.EFTThresholdHandler,
        "FTF": ftf.FTFThresholdHandler,
        "TSD": tsd.TSDThresholdHandler
    }

    GENERATED_THRESHOLDS_PATH = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'thresholds'
    )
    pickle_parameters = load_parameters(parameters.BU, parameters.THRESHOLDS.PARAMETERS)
    whitelist = pickle_parameters['whitelist']

    kyc_risk_mapping = get_kyc_risk_mapping(parameters)
    cluster_mapping = get_cluster_mapping_from_postings( 
        parameters, whitelist, kyc_risk_mapping, parameters.THRESHOLDS.TRANSACTIONS
    )

    audit_trail = []
    audit_trail_group = []

    for model in parameters.LIST_MODEL:
        
        if model not in ['EFT', 'FTF', 'TSD']:
            continue
    
        constants.LOGGER.info('Computing Thresholds for BU {} for Model {}'.format(
            parameters.BU, model
        ))
        
        outputfile = os.path.join(
            GENERATED_THRESHOLDS_PATH,
            '{}_{}_{}.pickle'.format(
                model, parameters.BU, parameters.EXPERIMENT_KEY
            )
        )
        
        threshold_handler = THRESHOLD_CLASSES[model](
            parameters,
            kyc_risk_mapping=kyc_risk_mapping,
            cluster_mapping=cluster_mapping,
            pickle_parameters=pickle_parameters
        )
        threshold_handler.open_transactions(
            whitelist, parameters.THRESHOLDS.TRANSACTIONS, parameters.THRESHOLDS.LOOKBACK_SUMS
        )
        threshold_handler.compute_thresholds()

        res = threshold_handler.thresholds

        with open(outputfile, 'wb') as f:
            pickle.dump(res, f)
            
        audit_trail += [threshold_handler.escalations_audit_trail]
        audit_trail_group += [threshold_handler.group_audit_trail]
        
    audit_trail_dir = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'exports', 'audit_trail'
    )
    os.makedirs(audit_trail_dir, exist_ok=True)
    audit_trail_path = os.path.join(
        audit_trail_dir,
        f"audit_trail_{parameters.BU}_{parameters.EXPERIMENT_KEY}.csv"
    )
    audit_trail = pd.concat(audit_trail, axis=0)
    audit_trail.to_csv(audit_trail_path, sep=';', index=False)
    
    group_audit_trail_path = os.path.join(
        audit_trail_dir,
        f"audit_trail_group_{parameters.BU}_{parameters.EXPERIMENT_KEY}.csv"
    )
    audit_trail_group = pd.concat(audit_trail_group, axis=0)
    audit_trail_group.to_csv(group_audit_trail_path, sep=';', index=False)