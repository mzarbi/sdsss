import os
from datetime import timedelta
import pyarrow.parquet as pq
import pandas as pd
import datetime

from ..actimize.ftf import get_lookback_sums
from ..utils import constants

from ..utils.utils import lookup, filter_transactions
from ..utils.parquet import get_transactions_by_chunk
from ..thresholds import utils_thresholds
from ..thresholds.base_thresholds import ThresholdHandler

def recurrence_period_min(x, daily_account, amt_col, ndays, nocc):
    if nocc == 1:
        return x[amt_col]
    loc1 = daily_account.index.get_loc(
        x.VALUE_DATETIME-datetime.timedelta(days=ndays), method='bfill'
    )
    loc2 = daily_account.index.get_loc(x.VALUE_DATETIME)
    
    amounts = list(daily_account.iloc[loc1:loc2][amt_col])
    
    if len(amounts) < nocc-1:
        return x[amt_col]
    else:
        return min(x[amt_col], sorted(amounts)[-nocc+1])


def apply_recurrence_parameters(chunk, amt_col, ndays, nocc):
    list_accounts = chunk['ACCOUNT_KEY'].unique()
    
    new_df_accounts = []
    for account in list_accounts:
        daily_account = chunk[chunk['ACCOUNT_KEY']==account].set_index(
            'VALUE_DATETIME', drop=False
        )
        if len(daily_account) == 0:
            continue
        
        daily_account['AMOUNT_AFTER_RECURRENCE'] = daily_account.apply(
            lambda x: recurrence_period_min(x, daily_account, amt_col, ndays, nocc), axis=1
        )
            
        new_df_accounts += [daily_account]
        
    return pd.concat(new_df_accounts, axis=0).reset_index(drop=True)


class FTFThresholdHandler(ThresholdHandler):
    def __init__(self, parameters, **kwargs):
        super().__init__(parameters, **kwargs)
        self.min_value = None
        self.cap_value = None
        self.model = "FTF"
        self.amount_key = "SUM_INCOMING"
        self.model_full_name = constants.MODEL_FULL_NAMES[self.model]
        self.threshold_name = constants.MODEL_THRESHOLD_NAME[self.model]
        self.score_name = constants.MODEL_SCORE_NAME[self.model]
        self.default_value = constants.DEFAULT_VALUES[self.model] * self.parameters.LOCAL_CURRENCY_RATE
        self.outliers = {}
        self.build_default_thresholds()

    def open_transactions(self, whitelist, transactions_key, lookback_sums_key=None):
        inputfile = os.path.join(
            constants.READ_WRITE_DATA_PATH, self.business_unit,
            'processed/CTP_{}_{}_{}.parquet'.format(
                self.business_unit,
                "Postings",
                transactions_key
            )
        )
        if lookback_sums_key is not None:
            inputfile = os.path.join(
                constants.READ_WRITE_DATA_PATH, self.business_unit,
                'processed/FTF_lookback_sums_{}_{}.parquet'.format(
                    self.business_unit,
                    lookback_sums_key
                )
            )

        cols_to_load = [
            constants.TRANS_DATE_KEY, "CLIENTNUM", "ACCOUNT_KEY",
            constants.MAIN_AMNT_KEY, constants.RISK_SCORE_KEY,
            constants.MODEL_TRANSACTION_KEY[self.model]
        ]

        input_schema = pq.read_schema(inputfile)
        if constants.CLUSTER_KEY in input_schema.names:
            cols_to_load += [constants.CLUSTER_KEY]
        elif "POPULATION_GROUP_ID" in input_schema.names:
            constants.LOGGER.info("Thresholds computation use default clustering")
            cols_to_load += ["POPULATION_GROUP_ID"]
        else:
            raise Exception("No cluster column found in dataset")
                
        df_list = []
        df_list_unfiltered = []
        cols_to_load += ["BU"]
        if lookback_sums_key is not None:
            cols_to_load += ['SUM_INCOMING', 'SUM_OUTGOING']
        else:
             cols_to_load += ["TRANS_TYPE_CD", "POS_ID"]
        for chunk in get_transactions_by_chunk(inputfile, cols=cols_to_load):
            chunk["VALUE_DATETIME"] = lookup(
                chunk[constants.TRANS_DATE_KEY]
            )

            if lookback_sums_key is None:
                client_risk_levels = chunk.groupby(["ACCOUNT_KEY"]).agg({
                    constants.RISK_SCORE_KEY: "first"
                    }).reset_index(drop=False)
                lookback_sums = get_lookback_sums(chunk)
                chunk = lookback_sums.merge(client_risk_levels, on="ACCOUNT_KEY")

            df_list_unfiltered.append(chunk)
            chunk = chunk[chunk['SUM_INCOMING'] > 0]
            chunk["RATIO"] = \
                100.0 *chunk['SUM_INCOMING'] / chunk['SUM_OUTGOING']
            chunk["RATIO"] = chunk["RATIO"].fillna(0.0)
            ratio_lower_bound = self.model_parameters['user']['FTF']\
                                 [constants.MODEL_FULL_NAMES['FTF']]\
                                 ['Ratio Lower Bound']
            ratio_upper_bound = self.model_parameters['user']['FTF']\
                                 [constants.MODEL_FULL_NAMES['FTF']]\
                                 ['Ratio Upper Bound']

            chunk = chunk[
                (chunk['RATIO'] > float(ratio_lower_bound)) \
                & (chunk['RATIO'] < float(ratio_upper_bound))
            ]

            chunk = apply_recurrence_parameters(
                chunk, 'SUM_INCOMING',
                int(self.model_parameters['user']['FTF']\
                                 [constants.MODEL_FULL_NAMES['FTF']]\
                                 [constants.RECURRENCE_PERIOD_NAME]),
                int(self.model_parameters['user']['FTF']\
                                 [constants.MODEL_FULL_NAMES['FTF']]\
                                 [constants.NUMBER_OCCURRENCES_NAME])
            )

            df_list.append(chunk)

        self.transactions = pd.concat(df_list) 
        self.minimum_hit_amount = self.get_hits_amounts()
        self.get_account_cluster_mapping()
        self.transactions = filter_transactions(
            self.transactions, self.parameters.ANALYSIS_DATES['THRESHOLDS_TRAIN']
        )       

    def compute_cluster_thresholds(self):
        ''' Compute thresholds for population groups of FTF model

        Parameters
        ----------
        transaction_data: pandas dataframe
            Postings data, minimal columns should be: TRANS_VALUE_DATE, POPULATION_GROUP_ID, ACCOUNT_KEY, MAIN_CURRENCY_AMT

        Returns
        -------
        population group thresholds: dict
            Dictionnary giving thresholds for different population groups for EFT model
        '''
        self.rule = constants.MODEL_FULL_NAMES["FTF"]        
        if self.rule not in self.outliers:
            self.outliers[self.rule] = []

        transactions = self.get_transactions_without_outliers()
        self.thresholds["cluster"]["FTF"][self.model_full_name][self.threshold_name] = {}
        self.thresholds["cluster"]["FTF"][self.model_full_name][self.threshold_name] = \
            self.compute_group_threshold(
                transactions,
                constants.CLUSTER_KEY,
            )
        
        if self.compute_outliers:
            self.compute_outliers_with_significantly_above_transactions(
                transactions,
                "ACCOUNT_KEY",
                self.thresholds["cluster"]["FTF"][self.model_full_name][self.threshold_name]
            )
        utils_thresholds.fill_missing_thresholds(
            self.default_value,
            self.thresholds["cluster"]["FTF"][self.model_full_name][self.threshold_name],
            self.cluster_mapping
        )

        utils_thresholds.fill_new_clients_clusters(
            self.thresholds["cluster"]["FTF"][self.model_full_name][self.threshold_name],
            self.cluster_mapping
        )

    def compute_individual_thresholds(self):
        self.rule = constants.MODEL_FULL_NAMES["FTF"]        
        
        if self.outliers:
            accounts = self.outliers.get(self.rule, [])
        else:
            accounts = []
        
        transactions_outliers = self.transactions[
            (self.transactions[constants.CLUSTER_KEY] == "0") \
            | self.transactions["ACCOUNT_KEY"].isin(accounts)
        ]
        if transactions_outliers.empty:
            self.individual_accounts = []
            return {}

        self.thresholds["individual"]["FTF"][self.model_full_name] \
                       [self.threshold_name] = {}
        self.thresholds["individual"]["FTF"][self.model_full_name][self.threshold_name] = \
            self.compute_group_threshold(
                transactions_outliers,
                "ACCOUNT_KEY",
            )
        self.thresholds["individual"]["FTF"][self.model_full_name]\
                       [self.threshold_name] = \
        self.fill_missing_accounts_thresholds(
            self.thresholds["individual"]["FTF"][self.model_full_name]\
                           [self.threshold_name]
        )

        self.individual_accounts = self.outliers[self.rule]

    def get_truth_alerts(self, alert_cols):
        raw_alerts_file = os.path.join(
            constants.READ_WRITE_DATA_PATH, self.business_unit, 'alerts',
            '{}_{}_{}.parquet'.format("FTF", self.business_unit, 'truth')
        )
        truth = pd.read_parquet(
            raw_alerts_file,
            engine='pyarrow',
            columns=alert_cols
        )
        truth["RULE_ID_V3"] = truth["RULE_ID"]
        truth['RULE_ID'] = truth['RULE_ID'].map(self.parameters.RULE_ID_SUBMODEL_MAP)
        return truth
    
    def merge_truth_transactions(self, truth):
        return pd.merge(
            truth, self.transactions[
                ['ACCOUNT_KEY', 'VALUE_DATETIME', 'AMOUNT_AFTER_RECURRENCE', constants.CLUSTER_KEY, 'CLIENTNUM']
            ].drop_duplicates(),
            how='left', on=['ACCOUNT_KEY', 'VALUE_DATETIME']
        )[[
            "RULE_ID", "RULE_ID_V3", "ALERT_ID", "STEP", constants.CLUSTER_KEY,
            "AMOUNT_AFTER_RECURRENCE", "CLIENTNUM", "ACCOUNT_KEY", "VALUE_DATETIME"
        ]].drop_duplicates() \
          .rename(columns={"AMOUNT_AFTER_RECURRENCE": constants.MAIN_AMNT_KEY})
    
    def postprocess_minimum_hits(
        self, clusters_minimum_hits_train, truth_test,
        individual_truth_test, recall_test
    ):
        pass
    
    def prepare_minimum_hits_dataframe(self, df, group, model):
        list_group = ['RULE_ID'] + group
        df['INTERPOLATED_AMOUNT'] = df[constants.MAIN_AMNT_KEY]
        return df, list_group