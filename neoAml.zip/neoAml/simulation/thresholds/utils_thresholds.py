import os
import pandas as pd
import numpy as np
import math
import pyarrow.parquet as pq

from ..utils import constants
from ..utils.utils import get_accounts, get_parties, filter_transactions


def get_percentile(value, list_amounts):
    values_arr = np.array(list_amounts + [value])
    sort_index = np.argsort(values_arr)
    idx = np.where(sort_index==len(list_amounts))[0][0]
    return float(100*idx/len(list_amounts))


def get_percentile_from_sorted_list(value, sorted_list_amounts):
    idx = np.searchsorted(sorted_list_amounts, value)
    return float(100*idx/sorted_list_amounts.shape[0])

        
def add_key_to_dict(amounts, key):
    if not isinstance(amounts, dict):
        return {key: amounts}
    for k,v in amounts.items():
        amounts[k] = add_key_to_dict(v, key)
    return amounts

    
def multiindex_dict(df, columns):
    if len(columns) == 1:
        return df[columns[0]].item()
    groups = df.groupby(columns[0])
    base_dict = {}
    for name, group in groups:
        base_dict[name] = multiindex_dict(group, columns[1:])
    return base_dict

                
def get_party_account_mapping(parameters):
    accounts = get_accounts(parameters)
    party_account_mapping = accounts[['ACCOUNT_KEY', 'CLIENTNUM']].drop_duplicates()
    return party_account_mapping


def risk_level_as_int(transactions, kyc_risk_mapping):
    transactions['TMP_RISK_SCORE_KEY'] = \
    transactions['CLIENTNUM'].map(kyc_risk_mapping)
    transactions[constants.RISK_SCORE_KEY] = np.where(
        pd.isnull(transactions['TMP_RISK_SCORE_KEY']), 
        transactions[constants.RISK_SCORE_KEY],
        transactions['TMP_RISK_SCORE_KEY']
    )

         
def clean_transactions(transactions, whitelist):
    # Filter whitelisted accounts
    transactions = transactions[
        ~transactions['ACCOUNT_KEY'].isin(whitelist)
    ].reset_index(drop=True)
    #Homogeneize risk score key
    transactions[constants.RISK_SCORE_KEY] = \
        transactions[constants.RISK_SCORE_KEY].astype(str)
    isold_format = transactions[constants.RISK_SCORE_KEY].isin(["0", "1", "2"])
    transactions.loc[isold_format, constants.RISK_SCORE_KEY] = \
        transactions.loc[isold_format, constants.RISK_SCORE_KEY].map({
        "0": "0-LOW", "1": "1-MEDIUM", "2": "2-HIGH",
    })
    if "POPULATION_GROUP_ID" in transactions.columns:
        transactions = \
            transactions.rename(columns={"POPULATION_GROUP_ID": constants.CLUSTER_KEY})
    return transactions


def get_cluster_mapping_from_postings(
    parameters, whitelist,
    kyc_risk_mapping, transactions_key):
    ''' Build mapping between new clients clusters per risk and other
        other clusters. Eg: {"1": ["4", "5"], "2": ["6", "7"], "3": ["8", "9"]}
        This is used to compute thresholds on new clients clusters as minimum
        of thresholds from other clusters with same risk level.
    '''
    inputfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        f'processed/CTP_{parameters.BU}_Postings_{transactions_key}.parquet'
    )
    cols_to_load = [
        constants.TRANS_DATE_KEY, constants.CLUSTER_KEY, 'TRANSACTION_KEY', 'ACCOUNT_KEY', 'CLIENTNUM',
        constants.RISK_SCORE_KEY
    ]
    df = pq.read_table(inputfile, columns=cols_to_load).to_pandas()
    df = df.sort_values(by="TRANS_INSERT_DATE")
    transactions = filter_transactions(
        df,
        parameters.ANALYSIS_DATES['THRESHOLDS_TRAIN']
    )
    transactions['TMP_RISK_SCORE_KEY'] = transactions['CLIENTNUM'].map(kyc_risk_mapping)  
    transactions[constants.RISK_SCORE_KEY] = np.where(
        pd.isnull(transactions['TMP_RISK_SCORE_KEY']), transactions[constants.RISK_SCORE_KEY],
        transactions['TMP_RISK_SCORE_KEY']
    )

    transactions.drop('TMP_RISK_SCORE_KEY', axis=1, inplace=True)
    transactions = clean_transactions(transactions, whitelist)
    
    count_transactions = transactions.groupby([constants.CLUSTER_KEY])[
        [constants.RISK_SCORE_KEY]
    ].agg({
        constants.RISK_SCORE_KEY: lambda x: list(x.value_counts().index)
    }).to_dict()
    for key, val in count_transactions[constants.RISK_SCORE_KEY].items():
        val.sort()
        count_transactions[constants.RISK_SCORE_KEY][key] = val[-1]

    cluster_mapping = get_cluster_risk_mapping(
        count_transactions[constants.RISK_SCORE_KEY]
    )

    return cluster_mapping


def get_cluster_risk_mapping(risk_cluster):
    cluster_mapping = {}
    
    for new_cluster in constants.NEW_CLIENTS_CLUSTER_RISK_MAPPING.values():
        cluster_mapping[new_cluster] = []
        
    for cluster, risk in risk_cluster.items():
        if cluster == '0':
            # We don't want to look at outlier cluster threshold
            continue
        cluster_mapping[
            constants.NEW_CLIENTS_CLUSTER_RISK_MAPPING[risk]
        ] += [cluster]
        
    return cluster_mapping


def fill_missing_thresholds(base_threshold, thresholds, cluster_mapping, tsd3_thresh=None):
    ''' Add default value as threshold to clusters that were not computed
        (for instance if there are no transactions)
    '''
    list_clusters = [item for sublist in cluster_mapping.values() for item in sublist]
    if '0' not in list_clusters:
        list_clusters.append('0')
    for cluster in list_clusters:
        if thresholds.get(cluster) is None or cluster == '0':
            if tsd3_thresh:
                thresholds[cluster] = min(base_threshold, tsd3_thresh[cluster])
            else:
                thresholds[cluster] = base_threshold


def fill_new_clients_clusters(clusters, cluster_mapping):
    ''' Compute thresholds for new clients clusters (1, 2, 3)
        as minimum of thresholds of clusters with same risk level
    '''
    for group in ['1', '2', '3']:
        clusters[group] = 1e10
        for c in cluster_mapping[group]:
            if c in clusters:
                if clusters[c] < clusters[group]:
                    clusters[group] = clusters[c]

    #Remove thresholds from cluster 0 as it has to be set individually
    clusters.pop(0, None)


def get_risk_for_cluster(clusterid, cluster_mapping):
    if not cluster_mapping:
        return None
    for key, values in cluster_mapping.items():
        if clusterid in values or clusterid == key:
            return key
    

def get_score_for_model(submodel, risk=None):
    if submodel == 'Excessive Single Transactions' and risk is not None:
        if risk == '1':
            return 10
        if risk == '2':
            return 20
        return 40
    return constants.SUBMODEL_SCORE_THRESHOLDS[submodel]
    

def fill_score_threshold(cluster, cluster_score, submodel, cluster_mapping):
    for cluster_name, threshold in cluster.items():
        cluster_score[cluster_name] = {
            threshold: get_score_for_model(
                submodel,
                get_risk_for_cluster(cluster_name, cluster_mapping)
            )
        }

    
def fill_cluster_score_thresholds(parameters, cluster, cluster_score, cluster_mapping):
    ''' Add score to thresholds
    '''
    for submodel, thresholds in cluster.items():
        cluster_score[submodel] = {}
        for threshold_name, clusters in thresholds.items():
            score_threshold = constants.THRESHOLDS_SCORING_NAME[threshold_name]
            cluster_score[submodel][score_threshold] = {}
            if len(set(clusters) & set(parameters.BUCKETS)) > 0:
                for bucket_name, bucket in clusters.items():
                    cluster_score[submodel][score_threshold][bucket_name] = {}
                    bucket_cluster_mapping = None if bucket_name in ['Cash', 'Check'] else cluster_mapping
                    fill_score_threshold(
                        bucket,
                        cluster_score[submodel][score_threshold][bucket_name],
                        submodel,
                        bucket_cluster_mapping
                    )
            else:
                fill_score_threshold(
                    clusters,
                    cluster_score[submodel][score_threshold],
                    submodel,
                    cluster_mapping
                )


def rounddown(x, scale=0):
    if scale == -1:
        return rounddown(x, scale=10**(min(3, int(math.log10(x)))))
    if scale == 0:
        return math.floor(x)
    return x if x % scale == 0 else x - x % scale


def build_outliers_audit_trail(audit_trail_group, outliers_method):
    outliers_data = {
        "ACCOUNT_KEY": [],
        "RULE_ID": [],
        "METHOD": []
    }
    for account, rules in outliers_method.items():
        for rule, method in rules.items():
            outliers_data["ACCOUNT_KEY"].append(account)
            outliers_data["RULE_ID"].append(rule)
            outliers_data["METHOD"].append(method)
    df_outliers_method = pd.DataFrame.from_dict(outliers_data)
    df_outliers_method = audit_trail_group.rename(columns={
        "GROUP": "ACCOUNT_KEY"
    }).merge(df_outliers_method, how="left", on=["ACCOUNT_KEY", "RULE_ID"])
    df_outliers_method = df_outliers_method[
        ~df_outliers_method["METHOD"].isna()
    ]
    return df_outliers_method


def fill_crds_codes_for_accounts(parameters, audit_trail_group):
    accounts = get_party_account_mapping(parameters).rename(
        columns={"CLIENTNUM": "PARTY_KEY"}
    )
    audit_trail_group = audit_trail_group.merge(
        accounts, how="left", on="ACCOUNT_KEY"
    )
    parties = get_parties(parameters)
    parties = parties[['CRDS_CODE', 'PARTY_KEY']].drop_duplicates()
    audit_trail_group = audit_trail_group.merge(
        parties, how="left", on="PARTY_KEY"
    )
    return audit_trail_group
    