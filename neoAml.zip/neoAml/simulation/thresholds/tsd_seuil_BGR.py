import os
import pyarrow.parquet as pq
import pandas as pd

from ..utils import constants

from ..utils.parquet import get_transactions_by_chunk
from ..utils.utils import filter_transactions
from ..thresholds import utils_thresholds
from ..thresholds.base_thresholds import ThresholdHandler
                                                            

class TSDThresholdHandler(ThresholdHandler):
    def __init__(self, parameters, **kwargs):
        super().__init__(parameters, **kwargs)
        self.min_value = None
        self.cap_values = [50_000, 100]
        self.amount_key = constants.MAIN_AMNT_KEY
        self.model = "TSD"
        self.model_full_name = constants.MODEL_FULL_NAMES[self.model]
        self.rules = parameters.ALL_MODEL_FULL_NAMES[self.model]
        self.threshold_name = constants.MODEL_THRESHOLD_NAME[self.model]
        self.score_name = constants.MODEL_SCORE_NAME[self.model]
        self.default_values = [
            constants.DEFAULT_VALUES['TSD3'] * self.parameters.LOCAL_CURRENCY_RATE,
            constants.DEFAULT_VALUES['TSD4'] * self.parameters.LOCAL_CURRENCY_RATE
        ]
        self.outliers = {}
        self.build_default_thresholds()

    def build_default_thresholds(self):
        self.thresholds = {
            "cluster": {
                "TSD": {}
            },
            "individual": {
                "TSD": {}
            },
            "cluster_score": {
                "TSD": {}
            },
            "individual_score": {
                "TSD": {}
            }
        }
        for rule in self.rules:
            self.thresholds["cluster"][self.model][rule] = {self.threshold_name: {}}
            self.thresholds["individual"][self.model][rule] = {self.threshold_name: {}}
            self.thresholds["cluster_score"][self.model][rule] = {self.score_name: {}}
            self.thresholds["individual_score"][self.model][rule] = {self.score_name: {}}
        
    def open_transactions(self, whitelist, transactions_key, lookback_sums_key):
        inputfile = os.path.join(
            constants.READ_WRITE_DATA_PATH, self.business_unit,
            'processed/CTP_{}_{}_{}.parquet'.format(
                self.business_unit,
                "Payments",
                transactions_key
            )
        )
        cols_to_load = [
            constants.TRANS_DATE_KEY, "CLIENTNUM", "ACCOUNT_KEY",
            constants.MAIN_AMNT_KEY, constants.RISK_SCORE_KEY,
            constants.MODEL_TRANSACTION_KEY[self.model],
            "transaction_type"
        ]

        input_schema = pq.read_schema(inputfile)
        if constants.CLUSTER_KEY in input_schema.names:
            cols_to_load += [constants.CLUSTER_KEY]
        elif "POPULATION_GROUP_ID" in input_schema.names:
            constants.LOGGER.info("Thresholds computation use default clustering")
            cols_to_load += ["POPULATION_GROUP_ID"]
        else:
            raise Exception("No cluster column found in dataset")
         
        cols_to_load += [constants.TSD_COUNTRY_KEY]
        if constants.TSD_COUNTRY_KEY not in input_schema.names:
            raise Exception(
                f"Cannot compute TSD thresholds without {constants.TSD_COUNTRY_KEY} column"
            )
        df_list = []
        for chunk in get_transactions_by_chunk(inputfile, cols=cols_to_load):
            chunk = chunk[chunk.CNTY_AML_RISK.isin([3, 4])]
            df_list.append(chunk)
        self.transactions = pd.concat(df_list)
            
        self.transactions = utils_thresholds.clean_transactions(
            self.transactions,
            whitelist
        )
        self.minimum_hit_amount = self.get_hits_amounts()
        self.get_account_cluster_mapping()
        
        self.transactions = filter_transactions(
            self.transactions,
            self.parameters.ANALYSIS_DATES["THRESHOLDS_TRAIN"]
       )

    def compute_cluster_thresholds(self):
        ''' Compute thresholds for clusters of TSD model

        Parameters
        ----------
        transaction_data: pandas dataframe
            Postings data, minimal columns should be: TRANS_VALUE_DATE, POPULATION_GROUP_ID, ACCOUNT_KEY, MAIN_CURRENCY_AMT

        Returns
        -------
        population group thresholds: dict
            Dictionnary giving thresholds for different population groups for EFT model
        '''
        for risk in [3, 4]:
            self.rule = self.rules[risk-3]           
            if self.rule not in self.outliers:
                self.outliers[self.rule] = []
            
            transactions_data = self.get_transactions_without_outliers()
            transactions_data = transactions_data[
                transactions_data[constants.TSD_COUNTRY_KEY] == risk
            ]

            self.cap_value = self.cap_values[risk-3] * self.parameters.LOCAL_CURRENCY_RATE
            self.default_value = self.default_values[risk-3] * self.parameters.LOCAL_CURRENCY_RATE
            self.thresholds["cluster"]["TSD"][self.rule][self.threshold_name] = \
                self.compute_group_threshold(
                    transactions_data,
                    constants.CLUSTER_KEY,
                )
            
            if self.compute_outliers:
                self.compute_outliers_with_significantly_above_transactions(
                    transactions_data,
                    "ACCOUNT_KEY",
                    self.thresholds["cluster"]["TSD"][self.rule][self.threshold_name]
                )

            utils_thresholds.fill_missing_thresholds(
                self.default_values[risk-3],
                self.thresholds["cluster"]["TSD"][self.rule][self.threshold_name],
                self.cluster_mapping
            )
            
        self.minimum_tsd_thresholds("cluster")

        for risk in [3, 4]:
            self.rule = self.rules[risk-3]           
            utils_thresholds.fill_new_clients_clusters(
                self.thresholds["cluster"]["TSD"][self.rule][self.threshold_name],
                self.cluster_mapping
            )

    def compute_individual_thresholds(self):
        self.individual_accounts = set()
        for risk in [3, 4]:
            self.rule = self.rules[risk-3]           
            self.cap_value = self.cap_values[risk-3] * self.parameters.LOCAL_CURRENCY_RATE
            self.default_value = self.default_values[risk-3] * self.parameters.LOCAL_CURRENCY_RATE

            if self.outliers and self.rule in self.outliers:
                accounts = self.outliers[self.rule]
            else:
                accounts = []

            transactions_outliers = self.transactions[
                ((self.transactions[constants.CLUSTER_KEY] == "0") \
                | self.transactions["ACCOUNT_KEY"].isin(accounts)) \
                & (self.transactions[constants.TSD_COUNTRY_KEY] == risk)
            ]
            if transactions_outliers.empty:
                continue

            self.thresholds["individual"]["TSD"][self.rule][self.threshold_name] = \
                self.compute_group_threshold(
                    transactions_outliers,
                    "ACCOUNT_KEY",
                )
        
            self.thresholds["individual"]["TSD"][self.rule]\
                               [self.threshold_name] = \
            self.fill_missing_accounts_thresholds(
                self.thresholds["individual"]["TSD"][self.rule]\
                               [self.threshold_name]
            )
            self.individual_accounts = \
                self.individual_accounts.union(set(self.outliers[self.rule]))
        
        self.individual_accounts = list(self.individual_accounts)
        self.minimum_tsd_thresholds("individual")
        self.minimum_tsd_individual_thresholds()

    def minimum_tsd_thresholds(self, key):
        rule3 = self.rules[0]
        rule4 = self.rules[1]
        for group, threshold in self.thresholds[key]["TSD"][rule4]\
                                            [self.threshold_name].items():
            if rule3 in self.thresholds[key]["TSD"] \
            and group in self.thresholds[key]["TSD"][rule3]\
                                     [self.threshold_name]:
                self.thresholds[key]["TSD"][rule4]\
                               [self.threshold_name][group] = \
                min(
                    self.thresholds[key]["TSD"][rule3]\
                               [self.threshold_name][group],
                    self.thresholds[key]["TSD"][rule4]\
                               [self.threshold_name][group]
                )

    def minimum_tsd_individual_thresholds(self):
        rule3 = self.rules[0]
        rule4 = self.rules[1]
        for account, threshold in self.thresholds["individual"]["TSD"][rule4]\
                                            [self.threshold_name].items():
            if rule3 in self.thresholds["individual"]["TSD"] \
            and account in self.thresholds["individual"]["TSD"][rule3]\
                                     [self.threshold_name]:
                # Already at min with TSD3
                continue
            cluster = self.account_cluster_mapping[account]
            self.thresholds["individual"]["TSD"][rule4]\
                      [self.threshold_name][account] = min(
                threshold,
                self.thresholds["cluster"]["TSD"][rule3]\
                          [self.threshold_name][cluster]
            )
        
        
    def get_truth_alerts(self, alert_cols):
        raw_alerts_file = os.path.join(
            constants.READ_WRITE_DATA_PATH, self.business_unit, 'alerts',
            '{}_{}_{}.parquet'.format(self.model, self.business_unit, 'truth')
        )
        truth = pd.read_parquet(
            raw_alerts_file,
            engine='pyarrow',
            columns=alert_cols
        )
        truth["RULE_ID_V3"] = truth["RULE_ID"]
        truth['RULE_ID'] = truth['RULE_ID'].map(self.parameters.RULE_ID_SUBMODEL_MAP)
        self.transactions[constants.MODEL_TRANSACTION_KEY[self.model]] = \
                self.transactions[constants.MODEL_TRANSACTION_KEY[self.model]].astype(str)
        truth = truth[truth['RULE_ID'] != 'BNP-TSD-EFT-ALL-A-S01-THV'].reset_index(drop=True)
        return truth
                          
    def merge_truth_transactions(self, truth):
        return pd.merge(
            truth, self.transactions[[
                constants.MODEL_TRANSACTION_KEY[self.model],
                constants.CLUSTER_KEY,
                constants.MAIN_AMNT_KEY,
                'CLIENTNUM'
            ]].drop_duplicates(),
            how='left', on=constants.MODEL_TRANSACTION_KEY[self.model]
        )
                          
    def postprocess_minimum_hits(
        self, clusters_minimum_hits_train, truth_test,
        individual_truth_test, recall_test
    ):
        pass
                          
    def prepare_minimum_hits_dataframe(self, df, group, model):
        df['INTERPOLATED_AMOUNT'] = df[constants.MAIN_AMNT_KEY]
        list_group = ['RULE_ID'] + group
        return df, list_group
