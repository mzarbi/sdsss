import pandas as pd
import abc
import copy
import numpy as np

from ..utils import constants
from ..utils.utils import lookup, update_min, filter_transactions
from ..thresholds import utils_thresholds


class ThresholdHandler:
    def __init__(self, parameters, **kwargs):
        self.parameters = parameters
        self.model_parameters = kwargs["pickle_parameters"]
        self.L2_recall_train = self.parameters.THRESHOLDS.L2_RECALL_TRAIN
        self.L2_recall_test = self.parameters.THRESHOLDS.L2_RECALL_TEST
        self.kyc_risk_mapping = kwargs["kyc_risk_mapping"]
        self.cluster_mapping = kwargs["cluster_mapping"]
        self.compute_outliers = True
        self.update_audit_trail = True
        self.business_unit = self.parameters.BU
        self.outliers_method = {}
        self.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW = parameters.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW
        
    def build_default_thresholds(self):
        self.thresholds = {
            "cluster": {
                self.model: {
                    self.model_full_name: {
                        self.threshold_name: {}
                    }
                }
            },
            "individual": {
                self.model: {
                    self.model_full_name: {
                        self.threshold_name: {}
                    }
                }
            },
            "cluster_score": {
                self.model: {
                    self.model_full_name: {
                        self.score_name: {}
                    }
                }
            },
            "individual_score": {
                self.model: {
                    self.model_full_name: {
                        self.score_name: {}
                    }
                }
            }
        }

    def merge_outliers_minimum_hits(self):
        res = set()
        for entry in self.outliers[self.rule]:
            if type(entry) == dict:
                for account, data in entry.items():
                    self.minimum_hit_amount[self.rule][account] = data
                    res.add(account)
            else:
                res.add(entry)
        self.outliers[self.rule].clear()
        for account in res:
            self.outliers[self.rule] += [account]

    def compute_outliers_with_significantly_above_transactions(
        self,
        transaction_data,
        group,
        thresholds
    ):
        accounts_minimum_hits = []
        group_minimum_hit = self.minimum_hit_amount.get(self.rule, {})
        for cluster, accounts in group_minimum_hit.items():
            accounts_minimum_hits += list(accounts.keys())

        transactions_per_accounts = transaction_data.groupby(group)
        for account, data in transactions_per_accounts:
            if str(data["CLUSTER_ID"].iloc[0]) in ["0", "1", "2", "3"] or str(data["CLUSTER_ID"].iloc[0]) not in thresholds:
                continue
            threshold = thresholds[str(data["CLUSTER_ID"].iloc[0])]
            if type(threshold) == dict or threshold is None:
                continue
            threshold_percent = utils_thresholds.get_percentile(
                threshold, list(data[self.amount_key])
            )
            percent_rule = self.parameters.STANDARD_PERCENTILE[self.rule][
                int(data.iloc[0][constants.RISK_SCORE_KEY][0])
            ]
            if self.cap_value is not None:
                percent_upper_limit = utils_thresholds.get_percentile(
                    self.cap_value, list(data[self.amount_key])
                )
                percent_rule = min(percent_rule, percent_upper_limit)

            if ((percent_rule-threshold_percent)*len(data) \
                > 100*self.parameters.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE[self.rule]) \
            and account not in accounts_minimum_hits:
                self.outliers[self.rule] += [account]
                if group not in self.outliers_method:
                    self.outliers_method[account] = {}
                self.outliers_method[account][self.rule] = "Significantly above transactions"

    def compute_outliers_with_significantly_below_escalation(
        self,
        transaction_data,
        group
    ):
        escalations_to_keep = {}
        transaction_data.sort()
        transaction_data = np.asarray(transaction_data)
        
        accounts_to_remove = set()
        
        for account, thresholds in self.minimum_hit_amount[self.rule][group].items():
            for period, value in thresholds.items():
                if period == "test_sct":
                    continue
                percent_rule = utils_thresholds.get_percentile_from_sorted_list(
                    value, transaction_data
                )
                is_outlier = (
                    percent_rule < self.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW[self.rule]
                )
                if self.cap_value is not None and self.cap_value < value:
                    is_outlier = False
                if is_outlier:
                    self.outliers[self.rule].append(account)
                    accounts_to_remove.add(account)
                    if account not in self.outliers_method:
                        self.outliers_method[account] = {}
                    self.outliers_method[account][self.rule] = "Significantly below escalation"

        for account in accounts_to_remove:
            self.minimum_hit_amount[self.rule][account] = \
                self.minimum_hit_amount[self.rule][group][account]
            self.minimum_hit_amount[self.rule][group].pop(account, None)

    def compute_outliers_with_significantly_above_escalation(
        self,
        transaction_data,
        group,
        thresholds
    ):

        transactions_per_accounts = transaction_data.groupby(group)
        for account, data in transactions_per_accounts:
            cluster_id = str(data["CLUSTER_ID"].iloc[0])
            
            if cluster_id not in self.minimum_hit_amount[self.rule]:
                continue
            if account not in self.minimum_hit_amount[self.rule][cluster_id]:
                continue
            if 'train' not in self.minimum_hit_amount[self.rule][cluster_id][account]:
                continue
            minimum_hit = self.minimum_hit_amount[self.rule][cluster_id][account]['train']
            if self.cap_value is not None:
                minimum_hit = min(minimum_hit, self.cap_value)
            hit_percent = utils_thresholds.get_percentile(
                minimum_hit, list(data[self.amount_key])
            )

            if cluster_id not in thresholds:
                continue
            threshold = thresholds[cluster_id]
            if type(threshold) == dict or threshold is None:
                continue
            threshold_percent = utils_thresholds.get_percentile(
                threshold, list(data[self.amount_key])
            )

            if ((hit_percent-threshold_percent)*len(data)
                > 100*self.parameters.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE[self.rule]):
                self.outliers[self.rule] += [account]
                if account not in self.outliers_method:
                    self.outliers_method[account] = {}
                self.outliers_method[account][self.rule] = "Significantly above escalation"
                
            self.minimum_hit_amount[self.rule][account] = \
                self.minimum_hit_amount[self.rule][cluster_id][account]
            self.minimum_hit_amount[self.rule][cluster_id].pop(account, None)

    def get_group_minimum_hits(self, group):
        if group not in self.minimum_hit_amount[self.rule]:
            return {}
        res = {}
        for k, v in self.minimum_hit_amount[self.rule][group].items():
            if not isinstance(v, dict):
                # Case of group is an account
                return self.minimum_hit_amount[self.rule][group]
            # Case of group is a cluster
            for period, threshold in v.items():
                if period == "test_sct":
                    continue
                if period not in res:
                    res[period] = threshold
                else:
                    res[period] = min(threshold, res[period])
        return res
    
    def add_thresholds_to_escalations(
        self,
        group,
        threshold,
        std_threshold,
        percentile,
        std_percentile,
        transaction_data,
        
    ):
        is_group_individual = (len(group) > 8)
        cond1 = (self.escalations_audit_trail["RULE_ID"] == self.rule)
        if is_group_individual:
            cond2 = (self.escalations_audit_trail["ACCOUNT_KEY"] == group)
            type_group = "ACCOUNT"
        else:
            cond2 = (self.escalations_audit_trail["CLUSTER_ID"] == group)
            type_group = "CLUSTER"
            # SCT alerts are only handled at account level
            if self.rule.startswith("Excessive Single Transactions"):
                cond2 = cond2 & (self.escalations_audit_trail["RULE_ID_V3"] \
                                     != "BNP-SCT-RSK-ACT-P-D01-EAT")
        idx = (cond1 & cond2)    
        if idx.sum() == 0:
            return

        self.escalations_audit_trail.loc[idx, "STD_THRESHOLD"] = std_threshold
        self.escalations_audit_trail.loc[idx, "THRESHOLD"] = threshold
        self.escalations_audit_trail.loc[idx, "STD_PERCENTILE"] = std_percentile
        self.escalations_audit_trail.loc[idx, "PERCENTILE"] = percentile
        
        self.escalations_audit_trail.loc[idx, "HIT_PERCENTILE"] = \
            self.escalations_audit_trail.loc[idx].apply(
                lambda x: utils_thresholds.get_percentile(
                    x[constants.MAIN_AMNT_KEY],
                    transaction_data
                ),
                axis=1
            )

        # Initialize actions (Re-initialize for individual)
        self.escalations_audit_trail.loc[idx, "ACTION"] = np.nan
        
        # Only output action for minimum escalation amount per group
        idx_train = idx & (self.escalations_audit_trail["PERIOD"] == "train")
        if idx_train.sum() > 0:
            idx_train = (self.escalations_audit_trail.index == \
                         self.escalations_audit_trail[idx_train][constants.MAIN_AMNT_KEY].idxmin())
        idx_test = idx & (self.escalations_audit_trail["PERIOD"] == "test")
        if idx_test.sum() > 0:
            idx_test = (self.escalations_audit_trail.index == \
                        self.escalations_audit_trail[idx_test][constants.MAIN_AMNT_KEY].idxmin())

        self.escalations_audit_trail.loc[idx_train, "ACTION"] = np.where(
            self.escalations_audit_trail.loc[idx_train, constants.MAIN_AMNT_KEY] \
                < self.escalations_audit_trail.loc[idx_train, "STD_THRESHOLD"],
            f"DECREASED AT {type_group} LEVEL",
            f"INCREASED AT {type_group} LEVEL"
        )
        self.escalations_audit_trail.loc[idx_test, "ACTION"] = np.where(
            self.escalations_audit_trail.loc[idx_test, constants.MAIN_AMNT_KEY] \
                < self.escalations_audit_trail.loc[idx_test, "STD_THRESHOLD"],
            f"DECREASED AT {type_group} LEVEL",
            np.nan
        )
        
        self.escalations_audit_trail.loc[idx, "THRESHOLD_OVERRIDE"] = \
            ~self.escalations_audit_trail.loc[idx, "ACTION"].isna()
        
    def add_thresholds_to_audit_trail(
        self,
        group,
        threshold,
        std_threshold,
        percentile,
        std_percentile,
        ntransactions
    ):  
        df = pd.DataFrame.from_dict({
            "RULE_ID": [self.rule],
            "GROUP": [group],
            "STD_THREHOLD": [std_threshold],
            "THRESHOLD": [threshold],
            "STD_PERCENTILE": [std_percentile],
            "PERCENTILE": [percentile],
            "NUMBER_OF_TRANSACTIONS": [ntransactions]
        })
        
        if not hasattr(self, "group_audit_trail"):
            self.group_audit_trail = df
        else:
            idx = (self.group_audit_trail["RULE_ID"] == self.rule) \
                & (self.group_audit_trail["GROUP"] == group)
            if idx.sum() == len(df):
                self.group_audit_trail.loc[idx] = df
            else:
                self.group_audit_trail = pd.concat([
                    self.group_audit_trail, df
                ], axis=0)
    
    def compute_threshold(
        self,
        transaction_data,
        risk,
        group
    ):
        min_test_escalation = 1e12
        
        threshold = None
        group_minimum_hit = {}
        if self.minimum_hit_amount and self.rule in self.minimum_hit_amount:
            if self.outliers is not None and self.compute_outliers \
                and group in self.minimum_hit_amount[self.rule]:
                self.compute_outliers_with_significantly_below_escalation(
                    transaction_data,
                    group
                )
            
            if group in self.minimum_hit_amount[self.rule]:
                group_minimum_hit = self.get_group_minimum_hits(group)
            if 'train' in group_minimum_hit:
                if 'test' in group_minimum_hit:
                    threshold = min(
                        group_minimum_hit['train'],
                        group_minimum_hit['test']
                    )
                else:
                    threshold = group_minimum_hit['train']
            elif 'test' in group_minimum_hit:
                min_test_escalation = group_minimum_hit['test']

        if len(transaction_data)==0:
            std_perc_threshold =  self.default_value
        else:     
            std_perc_threshold = np.percentile(
                transaction_data,
                self.parameters.STANDARD_PERCENTILE[self.rule][int(risk[0])]
            )

        if threshold is None:
            threshold = std_perc_threshold

        if self.min_value is not None:
            threshold = max(threshold, self.min_value)
            std_perc_threshold = max(std_perc_threshold, self.min_value)

        if self.cap_value is not None:
            threshold = min(threshold, self.cap_value)
            std_perc_threshold = min(std_perc_threshold, self.cap_value)
        
        threshold = utils_thresholds.rounddown(
            min(threshold, min_test_escalation)
        )
        
        if self.rule == "Transfer to/from Very High-Risk Countries (Level 4)":
            tsd3_threshold = self.get_tsd3_threshold(group)
            if tsd3_threshold is not None and tsd3_threshold < threshold:
                threshold = tsd3_threshold
        
        std_perc_threshold = utils_thresholds.rounddown(
            std_perc_threshold
        )
        
        # For audit trail purposes
        std_perc = utils_thresholds.get_percentile(std_perc_threshold, transaction_data)
        perc = utils_thresholds.get_percentile(threshold, transaction_data)
        self.add_thresholds_to_audit_trail(
            group,
            threshold=threshold,
            std_threshold=std_perc_threshold,
            percentile=perc,
            std_percentile=std_perc,
            ntransactions=len(transaction_data)
        )
        if self.update_audit_trail:
            self.add_thresholds_to_escalations(
                group,
                threshold=threshold,
                std_threshold=std_perc_threshold,
                percentile=perc,
                std_percentile=std_perc,
                transaction_data=transaction_data
            )
            
        return threshold

    def compute_group_threshold(
        self,
        transaction_data,
        group_key,
    ):
        data = transaction_data.groupby([group_key])[
            [self.amount_key, constants.RISK_SCORE_KEY]
        ].agg({
            self.amount_key: list,
            constants.RISK_SCORE_KEY: 'max'
        }).to_dict()

        data = {key: {
            "amount": amount, "risk": risk_level
        } for (key, amount), (_, risk_level) in zip(
            data[self.amount_key].items(),
            data[constants.RISK_SCORE_KEY].items()
        )}
        
        thresholds = {
            str(key): self.compute_threshold(
                item_data["amount"],
                item_data["risk"],
                group=str(key)
            ) for key, item_data in data.items()
        }
        if thresholds.get('0') is not None:
            thresholds['0'] = self.default_value
        return thresholds
    
    def add_test_only_outliers(self, thresholds):
        # Handle specific case of accounts outliered based on escalation on
        # test period that do not have transactions on train period
        for account in self.outliers[self.rule]:
            if account not in thresholds:
                if self.rule in self.minimum_hit_amount \
                and account in self.minimum_hit_amount[self.rule] \
                and "test" in self.minimum_hit_amount[self.rule][account]:
                    thresholds[account] = utils_thresholds.rounddown(
                        self.minimum_hit_amount[self.rule][account]["test"]
                    )

    @abc.abstractmethod
    def compute_cluster_thresholds(self, transaction_data):
        raise NotImplementedError(
            "Thresholds handler must override compute_cluster_thresholds"
        )
        
    @abc.abstractmethod
    def compute_individual_thresholds(self, transaction_data):
        raise NotImplementedError(
            "Thresholds handler must override compute_cluster_thresholds"
        )
            
    def compute_thresholds(
        self,
    ):
        self.escalations_audit_trail = self.escalations_audit_trail.reset_index(drop=True)
        # First pass on cluster thresholds, identification of outliers
        self.compute_cluster_thresholds()

        # No further identification of outliers
        self.compute_outliers = False

        # Compute individual thresholds, for outliers
        utils_thresholds.risk_level_as_int(self.transactions, self.kyc_risk_mapping)
        self.compute_individual_thresholds()
        self.get_individual_risk_mapping()
        utils_thresholds.fill_cluster_score_thresholds(
            self.parameters,
            self.thresholds['individual'][self.model],
            self.thresholds['individual_score'][self.model],
            self.individual_mapping
        )
        
        # Second pass on cluster thresholds without outliers transactions
        self.update_audit_trail = False
        self.compute_cluster_thresholds()
        utils_thresholds.fill_cluster_score_thresholds(
            self.parameters,
            self.thresholds['cluster'][self.model],
            self.thresholds['cluster_score'][self.model],
            self.cluster_mapping
        )

    def fill_missing_accounts_thresholds(self, thresholds):
        ''' Accounts with SCT escalations propagate their individual threshold
            to all the accounts of the same client.
            + Add thresholds for individual accounts with no transactions on the
            train period that are therefore missed in compute_individual_thresholds
            method.
        '''
        # Handle cornercase of accounts outliered based on escalation on test period
        # with no transactions on train period. 
        self.add_test_only_outliers(thresholds)
        
        # Add all accounts of one client that is an outlier
        # even if they don't have transactions, except for accounts
        # that have been outliered during the threshold setting
        df = pd.DataFrame(
            thresholds.items(),
            columns=['ACCOUNT_KEY', 'THRESHOLD_AMOUNT']
        )
        df['CLIENTNUM'] = df['ACCOUNT_KEY'].str[:15]
        
        # Exclude outliered accounts identified during threshold computation
        is_outliers = df["ACCOUNT_KEY"].isin(self.outliers[self.rule])
        df_out = df[is_outliers]
        df = df[~is_outliers]

        dt = self.party_account_mapping[
            self.party_account_mapping.CLIENTNUM.isin(df.CLIENTNUM.unique())
        ]
        dt = pd.merge(dt, df, how='left', on=['ACCOUNT_KEY', 'CLIENTNUM'])
        dt['THRESHOLD_AMOUNT'] = dt.groupby('CLIENTNUM')['THRESHOLD_AMOUNT'].transform(min)
        dt = pd.concat([dt, df_out], axis=0)
        all_thresholds = dt[['ACCOUNT_KEY', 'THRESHOLD_AMOUNT']]
        return dict(
            zip(all_thresholds['ACCOUNT_KEY'], all_thresholds['THRESHOLD_AMOUNT'])
        )

    def get_individual_risk_mapping(self):
        ''' Build mapping between risk and accounts. Risk
            is represented as the number for the corresponding
            new clients cluster (1, 2, 3) for coherence with cluster mapping
        '''
        dic_party_account_mapping = dict(zip(
            self.party_account_mapping['ACCOUNT_KEY'],
            self.party_account_mapping['CLIENTNUM']
        ))
        individual_account_risks = [
            self.kyc_risk_mapping[dic_party_account_mapping[account]]
            for account in self.individual_accounts
        ]
        df = pd.DataFrame({
            'ACCOUNT_KEY': self.individual_accounts,
            constants.RISK_SCORE_KEY: individual_account_risks
        })

        self.individual_mapping = {}
        for risk, new_cluster in constants.NEW_CLIENTS_CLUSTER_RISK_MAPPING.items():
            self.individual_mapping[new_cluster] = list(
                df[df[constants.RISK_SCORE_KEY] == risk]["ACCOUNT_KEY"].unique()
            )

    def get_hits_amounts(self):
        ''' Get the minimum threshold values per cluster/accounts (for indivudual
        thresholds) to have a given recall on L2 or L3 alerts.
        '''
        self.party_account_mapping = utils_thresholds.get_party_account_mapping(
            self.parameters, 
        )
        alert_cols = [
            'TRANSACTION_KEY', 'STEP', 'ALERT_ID',
            'ALERT_DATE', 'RULE_ID', 'ACCOUNT_KEY'
        ]
        truth = self.get_truth_alerts(alert_cols)
        debug = True
        if debug:
            truth = truth.sort_values(by="ALERT_ID")
            print(truth)
            truth.to_parquet(r"C:\Users\medzi\Desktop\bnp\amltm\debug\aaaa2.parquet")
        truth = truth.rename(
            columns={
                'ALERT_DATE': constants.TRANS_DATE_KEY,
                'TRANSACTION_KEY': constants.MODEL_TRANSACTION_KEY[self.model]
            }
        )

        truth[constants.MODEL_TRANSACTION_KEY[self.model]] = \
            truth[constants.MODEL_TRANSACTION_KEY[self.model]].astype(str)
        truth["VALUE_DATETIME"] = lookup(
            truth[constants.TRANS_DATE_KEY]
        )

        minimum_hits_train = {}
        constants.LOGGER.info("Fine-tune on L2 hits")
        l2_truth = truth[
            truth.STEP.str.contains(
                'to L2|L2 - clos|Closed - L2|to Level 2',
                regex=True)
        ]

        minimum_l2_hits_train = self.get_clusters_minimum(
            l2_truth, self.L2_recall_train, self.L2_recall_test
        )

        minimum_hits_train = update_min(
            minimum_hits_train, minimum_l2_hits_train
        )

        constants.LOGGER.info("Fine-tune on L3 hits")
        l3_truth = truth[
            truth.STEP.str.contains(
                'to L3|to Level 3|L3 - clos|L3 - Level 3',
                regex=True)
        ]
        minimum_l3_hits_train = self.get_clusters_minimum(
            l3_truth, 100, 100
        )
        minimum_hits_train = update_min(
            minimum_hits_train, minimum_l3_hits_train
        )

        self.escalations_audit_trail["CLIENT_RISK"] = \
            self.escalations_audit_trail["CLIENTNUM"].map(self.kyc_risk_mapping)
        return minimum_hits_train
    

    def get_clusters_minimum(self, truth, recall_train, recall_test):
        if recall_train == 0 and recall_test == 0:
            return {}


        truth = self.merge_truth_transactions(truth)

        truth[constants.CLUSTER_KEY] = truth[constants.CLUSTER_KEY].astype(str)

        individual_truth = truth[truth[constants.CLUSTER_KEY] == '0']
        truth = truth[truth[constants.CLUSTER_KEY] != '0']


        truth_test = filter_transactions(truth, self.parameters.ANALYSIS_DATES['THRESHOLDS_TEST'])
        truth_train = filter_transactions(truth, self.parameters.ANALYSIS_DATES['THRESHOLDS_TRAIN'])

        individual_truth_test = filter_transactions(individual_truth, self.parameters.ANALYSIS_DATES['THRESHOLDS_TEST'])
        individual_truth_train = filter_transactions(individual_truth, self.parameters.ANALYSIS_DATES['THRESHOLDS_TRAIN'])


        self.store_escalations(truth_train, "train")
        self.store_escalations(truth_test, "test")
        self.store_escalations(individual_truth_train, "train")
        self.store_escalations(individual_truth_test, "test")

        clusters_minimum_hits_train = {}

        if recall_train != 0:
            individual_minimum_hits_train = self.interpolate_recall_hits(
                individual_truth_train, ['ACCOUNT_KEY'], recall_train,
                self.party_account_mapping
            )

            clusters_minimum_hits_train = self.interpolate_recall_hits(
                truth_train, [constants.CLUSTER_KEY, "ACCOUNT_KEY"], recall_train, debug=True
            )

            utils_thresholds.add_key_to_dict(individual_minimum_hits_train, 'train')
            utils_thresholds.add_key_to_dict(clusters_minimum_hits_train, 'train')
            clusters_minimum_hits_train = update_min(
                clusters_minimum_hits_train, individual_minimum_hits_train
            )
            self.postprocess_minimum_hits(
                clusters_minimum_hits_train, truth_train,
                individual_truth_train, recall_train
            )

        if recall_test != 0:
            individual_minimum_hits_test = self.interpolate_recall_hits(
                individual_truth_test, ['ACCOUNT_KEY'], recall_test,
                self.party_account_mapping
            )
            clusters_minimum_hits_test = self.interpolate_recall_hits(
                truth_test, [constants.CLUSTER_KEY, "ACCOUNT_KEY"], recall_test
            )
            utils_thresholds.add_key_to_dict(individual_minimum_hits_test, 'test')
            utils_thresholds.add_key_to_dict(clusters_minimum_hits_test, 'test')
            clusters_minimum_hits_train = update_min(
                clusters_minimum_hits_train, individual_minimum_hits_test
            )
            clusters_minimum_hits_train = update_min(
                clusters_minimum_hits_train, clusters_minimum_hits_test
            )
            self.postprocess_minimum_hits(
                clusters_minimum_hits_train, truth_test,
                individual_truth_test, recall_test
            )        

        return clusters_minimum_hits_train

    def interpolate_recall_hits(self, df, group, recall, party_account_mapping=None, model="", debug=False):

        df, list_group = self.prepare_minimum_hits_dataframe(df, group, model)

        df = df.groupby(['ALERT_ID'] + list_group).agg({'INTERPOLATED_AMOUNT': 'min'})\
               .reset_index(drop=False)


        percent_group = copy.deepcopy(list_group)
        if "ACCOUNT_KEY" in percent_group and len(percent_group) > 1:
            percent_group.remove("ACCOUNT_KEY")
        df = df.sort_values(
            percent_group + ['INTERPOLATED_AMOUNT'],
            ascending=[True]*len(percent_group)+[False]
        )
        df['nb_alerts'] = df.groupby(percent_group)['INTERPOLATED_AMOUNT'].transform(np.size)
        df['cum_alerts'] = df.groupby(percent_group)['INTERPOLATED_AMOUNT'].cumcount()
        df['cum_pct'] = 100 * df['cum_alerts'] / df['nb_alerts']
        agg_df = df[df.cum_pct <= recall].groupby(list_group).last().reset_index(drop=False)

        if party_account_mapping is not None:
            # Apply individual threshold to all accounts of the client  
            #constants.LOGGER.info(f"Individual thresholds for model {model}")
            agg_df = pd.merge(party_account_mapping, agg_df, how='inner', on=group)
            group = 'ACCOUNT_KEY'
            list_group[-1] = group
 
        return utils_thresholds.multiindex_dict(
            agg_df, list_group + ["INTERPOLATED_AMOUNT"]
        )

    def store_escalations(self, escalations, period):
        escalations["PERIOD"] = period
        if not hasattr(self, "escalations_audit_trail"):
            self.escalations_audit_trail = escalations
        else:
            self.escalations_audit_trail = pd.concat([
                self.escalations_audit_trail,
                escalations
            ])


    def get_account_cluster_mapping(self):
        self.account_cluster_mapping = self.transactions[
            ["ACCOUNT_KEY", "CLUSTER_ID"]
        ].drop_duplicates().set_index("ACCOUNT_KEY").to_dict()["CLUSTER_ID"]


    def get_transactions_without_outliers(self, transactions=None):
        if transactions is None:
            return self.transactions[
                ~self.transactions["ACCOUNT_KEY"].isin(self.outliers[self.rule])
            ]
        return transactions[
            ~transactions["ACCOUNT_KEY"].isin(self.outliers[self.rule])
        ]
    