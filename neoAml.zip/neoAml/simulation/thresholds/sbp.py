import pandas as pd
import os
import numpy as np

from ..utils import constants
from ..utils.utils import filter_transactions
from ..utils.serialization import load_parameters


def get_min(clusters_risk, cluster_threshold, risk_level):
    val = 1e12
    for cluster, risk in clusters_risk.items():
        if cluster_threshold.get(cluster) is not None:
            if risk == risk_level and cluster_threshold.get(cluster) <= val:
                val = cluster_threshold.get(cluster)
    
    return val


def get_clusters_risk(business_unit, clkey):
    cols = ['CLUSTER_ID', 'RISK_LEVEL']
    clusters = pd.read_csv(os.path.join(
        constants.READ_WRITE_DATA_PATH, business_unit,
        f'Clusters/{business_unit}_SAM8_Cluster_Mapping_{clkey}.csv'
    ), sep=';', usecols=cols).drop_duplicates()

    clusters['CLUSTER_ID'] = clusters['CLUSTER_ID'].astype(str)
    clusters = clusters[clusters.CLUSTER_ID != '0']
    clusters['CLUSTER_ID'] = 'CLUP' + clusters['CLUSTER_ID'].str.zfill(3)
    clusters = clusters.groupby("CLUSTER_ID") \
                       .agg({"RISK_LEVEL": max}) \
                       .reset_index(drop=False)
    clusters['RISK_LEVEL'] = clusters['RISK_LEVEL'].map({
        0: '0-LOW',
        1: '1-MEDIUM',
        2: '2-HIGH'
    })
    return dict(zip(clusters['CLUSTER_ID'], clusters['RISK_LEVEL']))


def SBP_threshold_rule(risk, amounts, rounding=0):
    if len(amounts)==0:
        return 1_000_000
    
    else:
        if risk == "0-LOW":
            return int(round(np.percentile(amounts, 95), -rounding))
        elif risk == "1-MEDIUM":
            return int(round(np.percentile(amounts, 85), -rounding))
        elif risk == "2-HIGH":
            return int(round(np.percentile(amounts, 75), -rounding))
        else:
            raise ValueError("risk must be in ['0-LOW', '1-MEDIUM', '2-HIGH']")


def compute_sbp_thresholds(parameters, trkey):
    cols = [
        'CLUSTER_ID', 'CLIENT_FINAL_RISK_SCORE', 'AMOUNT_LOCAL_CURR',
        'TRANS_INSERT_DATE', 'ACCOUNT_KEY', 'TRANS_TYPE_CD'
    ]
    postings = pd.read_parquet(os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        f'processed/CTP_{parameters.BU}_Postings_{trkey}.parquet'
    ), columns=cols)
    
    thresholds = load_parameters(parameters.BU, 'RAW')
    # filter whitelisted accounts for TSD model
    postings = postings[~postings['ACCOUNT_KEY'].isin(thresholds['model_whitelist'].get('SBP', []))]\
    .reset_index(drop=True)
    
    postings['CLUSTER_ID'] = postings['CLUSTER_ID'].astype(int)
    postings = postings[postings.CLUSTER_ID != 0]
    postings = filter_transactions(postings, parameters.ANALYSIS_DATES['THRESHOLDS_TRAIN'])

    postings['YEAR'] = postings['VALUE_DATETIME'].dt.year
    postings['MONTH'] = postings['VALUE_DATETIME'].dt.month
    postings['DIRECTION'] = np.where(postings['TRANS_TYPE_CD'].str.startswith('C_'), 'TRN-INN', 'TRN-OUT')
    monthly_agg_postings = postings.groupby([
        'YEAR', 'MONTH', 'ACCOUNT_KEY', 'CLIENT_FINAL_RISK_SCORE', 'CLUSTER_ID', 'DIRECTION'
    ])['AMOUNT_LOCAL_CURR'].agg(VALUES='sum', VOLUMES='count').reset_index(drop=False)
    monthly_agg_postings = monthly_agg_postings.groupby(['CLUSTER_ID', 'DIRECTION'])\
                                               .agg({
        'VALUES': list, 'VOLUMES': list, 'CLIENT_FINAL_RISK_SCORE': max
    })

    postings_dict = {(cluster, direction): {
        "values": value, "volumes": volume, "risk": risk_level
    } for ((cluster, direction), value), (_, volume), (_, risk_level) in zip(
        monthly_agg_postings['VALUES'].items(),
        monthly_agg_postings['VOLUMES'].items(),
        monthly_agg_postings['CLIENT_FINAL_RISK_SCORE'].items()
    )}

    sbp_computed_thresholds = {}
    for direction in ['TRN-INN', 'TRN-OUT']:
        sbp_computed_thresholds[direction] = {}
        sbp_computed_thresholds[direction]['values'] = {
                'CLUP' + str(key[0]).zfill(3): max(20000, SBP_threshold_rule(data["risk"], data["values"], rounding=3))
            for key, data in postings_dict.items() if key[1] == direction
        }
        sbp_computed_thresholds[direction]['volumes'] = {
                'CLUP' + str(key[0]).zfill(3): max(5, SBP_threshold_rule(data["risk"], data["volumes"]))
            for key, data in postings_dict.items() if key[1] == direction
        }
        
    return sbp_computed_thresholds


def complete_sbp_thresholds(sbp_computed_thresholds, clusters_risk):
    for direction in ['TRN-INN', 'TRN-OUT']:
        sbp_computed_thresholds[direction]['values']['CLUP000'] = 20_000
        sbp_computed_thresholds[direction]['volumes']['CLUP000'] = 5
        for treshold_type in ['values', 'volumes']:
            sbp_computed_thresholds[direction][treshold_type]['CLUP001'] \
                = get_min(clusters_risk, sbp_computed_thresholds[direction][treshold_type], '0-LOW')
            sbp_computed_thresholds[direction][treshold_type]['CLUP002'] \
                = get_min(clusters_risk, sbp_computed_thresholds[direction][treshold_type], '1-MEDIUM')
            sbp_computed_thresholds[direction][treshold_type]['CLUP003'] \
                = get_min(clusters_risk, sbp_computed_thresholds[direction][treshold_type], '2-HIGH')


def replace_clusters_risk(clusters_risk):
    for cluster, risk in clusters_risk.items():
        if risk == '0-LOW':
            clusters_risk[cluster] = 3
        elif risk == '1-MEDIUM':
            clusters_risk[cluster] = 2
        else:
            clusters_risk[cluster] = 1
    clusters_risk['CLUP000'] = 3
    for i in range(3):
        clusters_risk[f'CLUP00{i + 1}'] = 3 - i


def fill_sbp_thresholds(sbp_thresholds, group_columns, clusters):
    original_clusters = ['CLUP' + str(e).zfill(3) for e in list(range(13))]
    new_clusters = ['CLUP' + str(e).zfill(3) for e in list(set(['1', '2', '3'] + clusters))]
    add_clusters = list(set(new_clusters) - set(original_clusters))
    add_clusters.sort()
    sbp_thresholds = sbp_thresholds[sbp_thresholds.POPULATION_GROUP_CD.isin(original_clusters)]
    
    if len(add_clusters) <= 0:
        sbp_thresholds = sbp_thresholds[sbp_thresholds.POPULATION_GROUP_CD.isin(new_clusters)]
    else:
        sampled_rows = sbp_thresholds.groupby(group_columns).apply(lambda x: x.sample(len(add_clusters), replace=True)).reset_index(drop=True)
        n_groups = sampled_rows.shape[0] // len(add_clusters)
        sampled_rows['POPULATION_GROUP_CD'] = add_clusters * n_groups
        sbp_thresholds = pd.concat([sbp_thresholds, sampled_rows], axis=0, ignore_index=True)
        sbp_thresholds.sort_values(group_columns + ['POPULATION_GROUP_CD'], inplace=True)
        
    return sbp_thresholds


def fill_sbp_event_thresholds(parameters, sbp_event_thresholds, trkey, clkey):
    sbp_computed_thresholds = compute_sbp_thresholds(parameters, trkey)
    clusters_risk = get_clusters_risk(parameters.BU, clkey)
    complete_sbp_thresholds(sbp_computed_thresholds, clusters_risk)
    replace_clusters_risk(clusters_risk)
    list_df = [sbp_event_thresholds[sbp_event_thresholds.EVENT_TYPE_CD == 'Insufficient Party Profile']]
    for event_type in ['Party Monthly Value', 'Party Monthly Volume']:
        for direction in ['TRN-INN', 'TRN-OUT']:
            df = sbp_event_thresholds[(sbp_event_thresholds.EVENT_TYPE_CD == event_type) & (sbp_event_thresholds.TRANSACTION_TYPE_CD == direction)]
            if event_type == 'Party Monthly Value':
                df['MIN_TRX_SUM_USER'] = df['POPULATION_GROUP_CD'].map(sbp_computed_thresholds[direction]['values'])
                mean_val = np.nanmean(df[df.EVENT_TYPE_CD == event_type]['MIN_TRX_SUM_USER'])
                df['MIN_TRX_SUM_USER'] = df['MIN_TRX_SUM_USER'].fillna(mean_val)
            else:
                df['MIN_TRX_QTY_USER'] = df['POPULATION_GROUP_CD'].map(sbp_computed_thresholds[direction]['volumes'])
                mean_val = np.nanmean(df[df.EVENT_TYPE_CD == event_type]['MIN_TRX_QTY_USER'])
                df['MIN_TRX_QTY_USER'] = df['MIN_TRX_QTY_USER'].fillna(mean_val)
            df['MIN_SD_USER'] = df['POPULATION_GROUP_CD'].map(clusters_risk)
            list_df.append(df)
    
    final_df = pd.concat(list_df, axis=0, ignore_index=True)
    final_df['MIN_SD_USER'] = final_df['MIN_SD_USER'].fillna(1)
    final_df['MIN_INCREASE_USER'] = final_df['MIN_INCREASE_USER'].fillna(1)
    for col in ['MIN_TRX_SUM_USER', 'MIN_TRX_QTY_USER', 'MIN_SD_USER', 'MIN_INCREASE_USER']:
        final_df[col] = final_df[col].astype(int)
            
    return final_df


def fill_all_sbp_thresholds(parameters, template_parameters, clusters, trkey, clkey):
    constants.LOGGER.info("Computing SBP thresholds")
    sbp_thresholds = template_parameters['SBP - SB Thresholds']
    group_columns = ['TENANT_CD', 'REGION_CD', 'PARAMETER_DESC']
    sbp_thresholds = fill_sbp_thresholds(sbp_thresholds, group_columns, clusters)

    sbp_event_thresholds = template_parameters['SBP - Event Thresholds']
    group_columns = ['TENANT_CD', 'REGION_CD', 'TRANSACTION_TYPE_CD', 'EVENT_TYPE_CD']
    sbp_event_thresholds = fill_sbp_thresholds(sbp_event_thresholds, group_columns, clusters)
    sbp_event_thresholds = fill_sbp_event_thresholds(parameters, sbp_event_thresholds, trkey, clkey)

    return sbp_thresholds, sbp_event_thresholds
    
