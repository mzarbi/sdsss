import os
import pandas as pd
import numpy as np
from tqdm import tqdm

import pyarrow.parquet as pq

np.warnings.filterwarnings('ignore')

from ..utils import constants

from ..utils.parquet import get_transactions_by_chunk
from ..utils.serialization import load_parameters
from ..utils.utils import filter_transactions, lookup
from ..utils.kyc import load_kyc

def check_all_models(parameters):
    GENERATED_ALERT_PATH = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts'
    )
    list_files = os.listdir(GENERATED_ALERT_PATH)
    if f'ALL_{parameters.BU}_truth.parquet' not in list_files:
        constants.LOGGER.info(f'Missing ALL_{parameters.BU}_truth.parquet file to compute aggregate KPIs')
        return False
    elif f'ALL_{parameters.BU}_{parameters.KPIS.ALERTS}.parquet' not in list_files:
        constants.LOGGER.info(f'Missing ALL_{parameters.BU}_{parameters.EXPERIMENT_KEY}.parquet file to compute aggregate KPIs')
        return False
    else:
        return True


def remove_whitelist(parameters, df):
    ''' Remove the whitelist accounts from the monitoring scope.
    
    Parameters
    ----------
    df: pandas dataframe
        Postings or Payments data
    
    Returns
    -------
    df: pandas dataframe
        Postings or Payments data without accounts that should not be
        monitored
    '''
    payments_thresh = load_parameters(parameters.BU, parameters.KPIS.PARAMETERS)
    if "whitelist" not in payments_thresh:
        return df
    whitelist = payments_thresh["whitelist"]
    df = df[~df['ACCOUNT_KEY'].isin(whitelist)]
    
    return df

def get_risk_mapping(business_unit):
    kyc = load_kyc(business_unit)
    risk_mapping = kyc[['CRDS_CODE', 'RISK_LEVEL']].drop_duplicates().fillna('').set_index('CRDS_CODE').to_dict()['RISK_LEVEL']
    return risk_mapping

def get_transaction_info(parameters, transaction_type, risk=None):
    ''' Get the payment information for the BU
    
    Parameters
    ----------
    transaction_type: str
        'Postings' or 'Payments'
        
    Returns
    -------
    info: dict
        Dictionary with list of payments, accounts and clients
    '''
    assert risk in [None, '0-LOW', '1-MEDIUM', '2-HIGH']
    constants.LOGGER.info(f'Get {transaction_type} for BU {parameters.BU}')
    payment_cols = ['POS_ID', 'CRDS_CODE', 'ACCOUNT_KEY', constants.TRANS_DATE_KEY]
    mapping = {
        'POS_ID': 'posid',
        'CRDS_CODE': 'client',
        'ACCOUNT_KEY': 'account',
    }
    if transaction_type == 'Payments':
        payment_cols += ['TRANSACTION_KEY']
        mapping['TRANSACTION_KEY'] = 'tkey'
    
    inputfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'processed/CTP_{}_{}_{}.parquet'.format(
            parameters.BU, transaction_type, parameters.KPIS.TRANSACTIONS
        )
    )
    if risk is not None:
        risk_mapping = get_risk_mapping(parameters.BU)
        
    unique_values = {}
    for col in mapping.keys():
        unique_values[col] = []

    for chunk in tqdm(
        get_transactions_by_chunk(inputfile, payment_cols)
    ):
        chunk = filter_transactions( 
            remove_whitelist(parameters, chunk),
            parameters.KPIS.ANALYSIS_DATES
        )

        if risk is not None:
            chunk = chunk[chunk['CRDS_CODE'].map(risk_mapping) == risk]
                        
        if chunk.empty:
            continue

        for col in mapping.keys():
            unique_values[col] += [pd.Series(chunk[col].unique())]

    info = {}

    for col in mapping.keys():
        info[mapping[col]] = list(
            pd.concat(unique_values[col]).unique()
        )

    return info


def count_elements(payment_info, posting_info):
    ''' Count the number of transactions, clients and accounts
    
    Parameters
    ----------
    payment_info: dict
        Dictionary with list of payments, accounts and clients from
        payments data
    posting_info: dict
        Dictionary with list of postings, accounts and clients from
        postings data
        
    Returns
    -------
    counts: dict
        Dictionary with counts of different elements such as postings, payments ...
    '''
    counts = {}
    # There are postings not appearing in the payments (not tied to payments)
    only_posting = set(posting_info['posid']) - set(payment_info['posid'])
    all_client = set(payment_info['client'] + posting_info['client'])
    all_account = set(payment_info['account'] + posting_info['account'])

    # Count the elements of interest
    counts['payment'] = len(set(payment_info['tkey']))
    counts['transac'] = counts['payment'] + len(only_posting)
    counts['posting'] = len(set(posting_info['posid']))
    counts['payment_client'] = len(set(payment_info['client']))
    counts['posting_client'] = len(set(posting_info['client']))
    counts['all_client'] = len(all_client)
    counts['payment_account'] = len(set(payment_info['account']))
    counts['posting_account'] = len(set(posting_info['account']))
    counts['all_account'] = len(all_account)

    return counts


def get_counts(parameters, risk=None):
    ''' Count different elements such as postings, payments ... 
    
    Returns
    -------
    counts: dict
        Dictionary with counts of different elements such as postings, payments ...,
    '''
    info = {}
    info['payment'] = get_transaction_info(parameters, 'Payments', risk)
    info['posting'] = get_transaction_info(parameters, 'Postings', risk)
    
    constants.LOGGER.info(f'Count the number of transactions, clients and accounts for BU {parameters.BU}')
    counts = count_elements(info['payment'], info['posting'])
        
    return counts


def clean_alert_labels(df):
    '''
    Clean the alert Levels so that we only have two levels, 1 and 2.
    
    Parameters
    ----------
    df: pandas dataframe
        Dataframe of alerts data
        
    Returns
    -------
    df: pandas dataframe
        Dataframe of alerts data with alerts STEP changed to Level 1, Level 2 and Level 3
    '''
    df['STEP'] = df['STEP'].fillna('Level 1')
    # Create the labels for the classification problem
    df['alert_level_temp'] = 'Level 1'
    df['alert_level_temp'] = np.where(
        df['STEP'].str.contains(
            'to L2|L2 - clos|Closed - L2|to Level 2',
            regex=True),
        'Level 2', df['alert_level_temp']
    )
    df['alert_level_temp'] = np.where(
        df['STEP'].str.contains(
            'to L3|to Level 3|L3 - clos|L3 - Level 3',
            regex=True),
        'Level 3', df['alert_level_temp']
    )
    # Only keep data with level 1 or 2
    df['STEP'] = df['alert_level_temp']
    df.drop('alert_level_temp', axis=1, inplace=True)

    return df


def get_actimize_kpis(stats, truth, model):
    ''' Get the statistics for the Actimize alerts
    
    Parameters
    ----------
    stats: dict
        Dictionary where the different statistics are stored
    truth: pandas dataframe
        Dataframe with Actimize alerts
    model: str
        Model (e.g. 'EFT', 'TSD' or 'FTF')
    business_unit: str
        Business Unit (e.g. 'ES', 'NL' or 'DE')
         
    Returns
    -------
    stats: dict
        Dictionary where the different statistics are stored
    '''
    transaction_key = "ALERT_ID" if constants.KPIS_BASE == "ALERTS" else "TRANSACTION_KEY"

    # Count the number of alerts
    tmp = truth[['ALERT_ID', 'STEP']]
    tmp.drop_duplicates(inplace=True)
    l2_alerts = tmp[tmp['STEP'] == 'Level 2'].shape[0]
    l3_alerts = tmp[tmp['STEP'] == 'Level 3'].shape[0]
    stats[model]['Actimize L2 alerts'] = l2_alerts
    stats[model]['Actimize L3 alerts'] = l3_alerts
    # Count the number of actimize hits
    alert_hits = set(truth[transaction_key])
    alert_hits_l2 = set(truth[truth['STEP'] == 'Level 2'][transaction_key])
    alert_hits_l3 = set(truth[truth['STEP'] == 'Level 3'][transaction_key])
    stats[model]['Actimize hits'] = len(alert_hits)
    stats[model]['Actimize L2 hits'] = len(alert_hits_l2 - alert_hits_l3)
    stats[model]['Actimize L3 hits'] = len(alert_hits_l3)
    

def get_generated_kpis(stats, truth, predicted, model, baseline=None):
    ''' Get the kpis for the generated alerts
    
    Parameters
    ----------
    stats: dict
        Dictionary where the different statistics are stored
    truth: pandas dataframe
        Dataframe with Actimize alerts
    predicted: pandas dataframe
        Dataframe with generated hits
    model: str
        Model (e.g. 'EFT', 'TSD' or 'FTF')
    business_unit: str
        Business Unit (e.g. 'ES', 'NL' or 'DE')
    baseline: pd.Dataframe
        list of alerts used as baseline
         
    Returns
    -------
    stats: dict
        Dictionary where the different statistics are stored
    '''
    transaction_key = "ALERT_ID" if constants.KPIS_BASE == "ALERTS" else "TRANSACTION_KEY"
    
    # Get actimize hits
    alert_hits = set(truth[transaction_key])
    alert_hits_l2 = set(truth[truth['STEP'] == 'Level 2'][transaction_key])
    alert_hits_l3 = set(truth[truth['STEP'] == 'Level 3'][transaction_key])
    alert_hits_l2p = alert_hits_l2 | alert_hits_l3
    alert_hits_l1 = alert_hits - alert_hits_l2p
    
    # Get generated hits
    if not predicted.empty:
        s_hits = set(predicted[transaction_key])
    else:
        s_hits = set([])

    if baseline is not None:
        b_hits = set(baseline[transaction_key])        
        spbp_hits = s_hits.intersection(b_hits)
        stats[model]['S+B+L3'] = len(spbp_hits.intersection(alert_hits_l3))
        stats[model]['S+B+L2+'] = len(spbp_hits.intersection(alert_hits_l2p))
        stats[model]['S+B+L1'] = len(spbp_hits.intersection(alert_hits_l1))
        stats[model]['S+B+N'] = len(spbp_hits) \
            - stats[model]['S+B+L2+'] \
            - stats[model]['S+B+L1']
        
        smbp_hits = b_hits - s_hits
        stats[model]['S-B+L3'] = len(smbp_hits.intersection(alert_hits_l3))
        stats[model]['S-B+L2+'] = len(smbp_hits.intersection(alert_hits_l2p))
        stats[model]['S-B+L1'] = len(smbp_hits.intersection(alert_hits_l1))
        stats[model]['S-B+N'] = len(smbp_hits) \
            - stats[model]['S-B+L2+'] \
            - stats[model]['S-B+L1']
        
        spbm_hits = s_hits - b_hits
        stats[model]['S+B-L3'] = len(spbm_hits.intersection(alert_hits_l3))
        stats[model]['S+B-L2+'] = len(spbm_hits.intersection(alert_hits_l2p))
        stats[model]['S+B-L1'] = len(spbm_hits.intersection(alert_hits_l1))
        stats[model]['S+B-N'] = len(spbm_hits) \
            - stats[model]['S+B-L2+'] \
            - stats[model]['S+B-L1']
        
        stats[model]['S-B-L3'] = len(alert_hits_l3)\
            - stats[model]['S+B+L3'] \
            - stats[model]['S+B-L3'] \
            - stats[model]['S-B+L3']
        stats[model]['S-B-L2+'] = len(alert_hits_l2p)\
            -  stats[model]['S+B+L2+'] \
            -  stats[model]['S+B-L2+'] \
            -  stats[model]['S-B+L2+']
        stats[model]['S-B-L1'] = len(alert_hits_l1)\
            -  stats[model]['S+B+L1'] \
            -  stats[model]['S+B-L1'] \
            -  stats[model]['S-B+L1']        

    else:
        stats[model]['Generated hits'] = len(s_hits)
        stats[model]['Same hits'] = len(s_hits.intersection(alert_hits))
        stats[model]['Precision'] = round(
            stats[model]['Same hits'] \
            / stats[model]['Generated hits'] * 100, 1
        )
        stats[model]['Recall'] = round(
            stats[model]['Same hits'] / len(alert_hits) * 100, 1
        )
    
        try:
            stats[model]['Recall L2+'] = round(
                len(alert_hits_l2p.intersection(s_hits)) \
                / (len(alert_hits_l2p)) * 100, 1)
        except ZeroDivisionError:
            stats[model]['Recall L2+'] = None
        
        try:
            stats[model]['Recall L3'] = round(
                len(alert_hits_l3.intersection(s_hits)) \
                / len(alert_hits_l3) * 100, 1)
        except ZeroDivisionError:
            stats[model]['Recall L3'] = None

            
def associate_alert_ids(truth, preds, daily_agg=True):
    '''
    Associate actimize alerts to simulated alerts
    
    Parameters
    ----------
    truth: pd.Dataframe
    list of actimize alerts
    
    preds: pd.Dataframe
    list of simulated alerts
    '''
    if preds.empty:
        return preds
    
    if truth.empty:
        return truth
    
    if daily_agg:
        daily_preds = preds.groupby(["ALERT_ID"]).agg({
            constants.PARTY_KEY: "first",
            "VALUE_DATETIME": max
        }).reset_index(drop=False)
    else:
        daily_preds = preds
    
    truth = truth.groupby([constants.TRANS_DATE_KEY, constants.PARTY_KEY])['ALERT_ID'] \
                 .first().reset_index(drop=False)
    
    daily_preds = daily_preds.reset_index().merge(
        truth.rename(columns={
            constants.TRANS_DATE_KEY: 'VALUE_DATETIME',
            'ALERT_ID': "TRUTH_ALERT_ID"
        }),
        on=['VALUE_DATETIME', constants.PARTY_KEY], how='left'
    ).set_index('index')

    daily_preds['ALERT_ID'] = np.where(
        daily_preds['TRUTH_ALERT_ID'].isna(),
        daily_preds['ALERT_ID'],
        daily_preds['TRUTH_ALERT_ID']
    )
    return daily_preds.drop(['TRUTH_ALERT_ID'], axis=1)


def open_alerts_file(parameters, alerts_file, model):
    # Open predicted alerts        
    generated_alert_cols = [constants.PARTY_KEY, 'TRANSACTION_KEY', constants.TRANS_DATE_KEY, 'CRDS_CODE']
    if constants.KPIS_BASE == "ALERTS":
        generated_alert_cols += ['ALERT_ID']
    if model == "ALL":
        generated_alert_cols += ['RULE_ID']

    schema = pq.read_schema(alerts_file)
    if constants.TRANS_DATE_KEY not in schema.names:
        generated_alert_cols.remove(constants.TRANS_DATE_KEY)
        generated_alert_cols += ['ALERT_DATE']

    alerts = pd.read_parquet(
        alerts_file,
        engine='pyarrow',
        columns=generated_alert_cols
    )
    if 'ALERT_DATE' in alerts.columns:
        alerts[constants.TRANS_DATE_KEY] = alerts['ALERT_DATE']

    alerts = filter_transactions(alerts, parameters.KPIS.ANALYSIS_DATES)

    if constants.KPIS_BASE == "ALERTS" and not alerts.empty:
        alerts = alerts.groupby(['ALERT_ID']).agg({
            "VALUE_DATETIME": max,
            constants.PARTY_KEY: "first",
            "CRDS_CODE": "first"
        }).reset_index(drop=False)
    return alerts


def compare_hits(parameters, stats, model, risk=None):
    ''' Compare hits between alerts and GENERATED alerts
    
    Parameters
    ----------
    stats: dict
        Dictionary where the different statistics are stored
    model: str
        Model (e.g. 'EFT', 'TSD' or 'FTF')

    Returns
    -------
    stats: dict
        Dictionary where the different statistics are stored
    '''
    
    if risk is not None:
        risk_mapping = get_risk_mapping(parameters.BU)
        
    # Get alerts hits
    alert_cols = ['ALERT_ID', 'TRANSACTION_KEY', 'STEP', 'ALERT_DATE', constants.PARTY_KEY, 'RULE_ID', 'CRDS_CODE']
    raw_alerts_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts',
        '{}_{}_{}.parquet'.format(model, parameters.BU, 'truth')
    )

    truth = pd.read_parquet(
        raw_alerts_file,
        engine='pyarrow',
        columns=alert_cols
    )
    
    truth.rename(columns={'ALERT_DATE': constants.TRANS_DATE_KEY}, inplace=True)
    truth = filter_transactions(truth, parameters.KPIS.ANALYSIS_DATES)
    if risk is not None:
        truth = truth[truth['CRDS_CODE'].map(risk_mapping) == risk]

    truth[constants.TRANS_DATE_KEY] = lookup(truth[constants.TRANS_DATE_KEY], '%Y%m%d')

    if constants.KPIS_BASE == "ALERTS":
        truth = clean_alert_labels(truth)
        truth['STEP'] = truth['STEP'].map(
            {'Level 1': 'L1 - closed', 'Level 2': 'L2 - closed', 'Level 3': 'L3 - closed'}
        )
        # Do this to make sure not to miss L3 alerts in the agg

        truth = truth.groupby(["ALERT_ID"]).agg({
            "STEP": max,
            constants.TRANS_DATE_KEY: max,
            constants.PARTY_KEY: "first",
        }).reset_index(drop=False) \
          .groupby([constants.TRANS_DATE_KEY, constants.PARTY_KEY]).agg({
            "ALERT_ID": "first",
            "STEP": max
        }).reset_index(drop=False)
        # This because we can't support 2 alert ids the same day for one client   
         
    # Open simulated alerts        
    alerts_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts',
        '{}_{}_{}.parquet'.format(model, parameters.BU, parameters.KPIS.ALERTS)
    )
    predicted = open_alerts_file(parameters, alerts_file, model)
    if risk is not None:
        predicted = predicted[predicted['CRDS_CODE'].map(risk_mapping) == risk]
        
    predicted = associate_alert_ids(truth, predicted)
    if not predicted.empty:
        predicted['ALERT_DATE'] = predicted['VALUE_DATETIME']

    baseline = None
    if parameters.KPIS.BASELINE is not None:
        # Open baseline alerts
        alerts_file = os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts',
            '{}_{}_{}.parquet'.format(model, parameters.BU, parameters.KPIS.BASELINE)
        )

        baseline = open_alerts_file(parameters, alerts_file, model)
        if risk is not None:
            baseline = baseline[baseline['CRDS_CODE'].map(risk_mapping) == risk]
        baseline = associate_alert_ids(truth, baseline)
        if not baseline.empty:
            baseline[constants.TRANS_DATE_KEY] = baseline['VALUE_DATETIME']
        
        # Associate baseline alerts that are not in truth alerts
        #   to simulation alerts
        missing_predicted = predicted[~predicted['ALERT_ID'].isin(truth['ALERT_ID'])]
        if not missing_predicted.empty:
            missing_predicted['ALERT_ID'] = associate_alert_ids(
                baseline, missing_predicted, daily_agg=False
            )['ALERT_ID']

            predicted.loc[missing_predicted.index,'ALERT_ID'] = missing_predicted['ALERT_ID']

        if not baseline.empty:
            baseline['ALERT_DATE'] = baseline['VALUE_DATETIME']
    
    # Filter based on global dates
    stats[model]['Min Date'] = '-'
    stats[model]['Max Date'] = '-'
    if "ANALYSIS_DATES" in parameters.KPIS:
        if "FROM" in parameters.KPIS.ANALYSIS_DATES:
            stats[model]['Min Date'] = parameters.KPIS.ANALYSIS_DATES["FROM"]
        if "TO" in parameters.KPIS.ANALYSIS_DATES:
            stats[model]['Max Date'] = parameters.KPIS.ANALYSIS_DATES["TO"]

    # Clean alert labels
    truth = clean_alert_labels(truth)
    
    # Get actimize hits stats
    get_actimize_kpis(stats, truth, model)
    
    # Get generated alerts stats
    get_generated_kpis(stats, truth, predicted, model, baseline)
    
    
def compute_hit_stats(parameters, risk=None):
    ''' Compute hits stats for all models and Business Units
    Returns
    -------
    stats: dict
        Dictionary where the different statistics are stored
    '''
    stats = {}
    for model in parameters.LIST_MODEL + ['ALL']:
        stats[model] = {}
        if model == 'ALL' and not check_all_models(parameters):
            continue
        compare_hits(parameters, stats, model, risk)
            
    return stats


def stats_to_dataframe(parameters, stats):
    ''' Put the different KPIs into a dataframe
    
    Parameters
    ----------
    stats: dict
        Dictionary where the different KPIs statistics are stored
         
    Returns
    -------
    df: pandas dataframe
        Dataframe with the different KPIs statistics
    '''
    list_df = []
    for model in parameters.LIST_MODEL + ['ALL']:
        if model == 'ALL' and not check_all_models(parameters):
            continue
        data = {}
        data['Model'] = model
        data['Business Unit'] = parameters.BU
        data.update(stats[model])
        list_df.append(pd.DataFrame([data]))
    df = pd.concat(list_df)
    df.sort_values(['Model', 'Business Unit'], inplace=True)
    
    return df


def counts_to_dataframe(parameters, counts):
    ''' Assemble the statistics of number of payments, postings, clients
    and accounts per model/BU into a single Dataframe
    
    Parameters
    ----------
    counts: dict
        Dictionary where the different statistics of number of payments,
        postings, clients and accounts are stored
         
    Returns
    -------
    counts_df: pandas dataframe
        Dataframe with the different statistics of number of payments,
        postings, clients and accounts
    '''
    list_df = []
    for model in parameters.LIST_MODEL + ['ALL']:
        if model == 'ALL' and not check_all_models(parameters):
            continue
        data = {}
        data['Model'] = model
        data['Business Unit'] = parameters.BU
        data.update(counts)
        list_df.append(pd.DataFrame([data]))
    counts_df = pd.concat(list_df)
    counts_df.sort_values(['Model', 'Business Unit'], inplace=True)
    counts_df.drop('transac', axis=1, inplace=True)

    counts_df['Monitored payments'] = np.where(counts_df['Model'] == 'TSD', counts_df['payment'], None)
    counts_df['Monitored postings'] = np.where(counts_df['Model'] == 'EFT', counts_df['posting'], None)
    counts_df['Monitored accounts'] = np.where(counts_df['Model'] == 'TSD', counts_df['payment_account'], counts_df['posting_account'])
    counts_df['Monitored clients'] = np.where(counts_df['Model'] == 'TSD', counts_df['payment_client'], counts_df['posting_client'])

    counts_df = counts_df[['Model', 'Business Unit', 'Monitored payments', 'Monitored postings', 'Monitored accounts', 'Monitored clients']]
    
    return counts_df


def export_kpis(parameters, stats, counts, export_file):
    ''' Export the KPIs to csv
    
    Parameters
    ----------
    stats: dict
        Dictionary where the different KPIs statistics are stored
    counts: dict
        Dictionary where the different statistics of number of payments,
        postings, clients and accounts are stored
    export_file: str
        Path to the file where the KPIs are written
    '''
    df = stats_to_dataframe(parameters, stats)
    counts_df = counts_to_dataframe(parameters, counts)
    tmp = df[['Model', 'Business Unit', 'Min Date', 'Max Date']]
    tmp = pd.merge(tmp, counts_df, how='left', on=['Model', 'Business Unit'])
    df = pd.merge(tmp, df, how='left', on=['Model', 'Business Unit', 'Min Date', 'Max Date'])

    out_dir = os.path.join(constants.READ_WRITE_DATA_PATH, parameters.BU, 'kpis')
    os.makedirs(out_dir, exist_ok=True)

    df.to_csv(os.path.join(out_dir, export_file), index=False, sep=";")
    
    
def generate_kpis(parameters):
    for risk in ['0-LOW', '1-MEDIUM', '2-HIGH', None]:
        constants.LOGGER.info(f'Risk filter : {risk}')
        constants.LOGGER.info('Count the number of transactions, clients and accounts')
        counts = get_counts(parameters, risk)
        constants.LOGGER.info('Compute the hits statistics')
        hit_stats = compute_hit_stats(parameters, risk)   

        constants.LOGGER.info('Export hits KPIs to file')
        risk = risk or "ALL" #None -> "ALL"
        kpis_file = (f'hit_kpis_{parameters.EXPERIMENT_KEY}_{risk}') \
            + (f'_{parameters.KPIS.BASELINE}' if parameters.KPIS.BASELINE is not None else '') \
            + ('.csv')

        export_kpis(parameters, hit_stats, counts, kpis_file)

        constants.LOGGER.info('Done!')
