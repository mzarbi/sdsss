import numpy as np
import os
import math
import shutil
import openpyxl
import pandas as pd
import pycountry as pc
from datetime import datetime

from ..utils import constants
from ..utils.utils import get_date_format, update, export_to_xlsx
from ..exports.parameters_file_check import load_parameters_file
from ..utils.serialization import find_xlsx_parameters_file, save_as_pickle


def load_xlsx_sheet(filename, sheet):
    '''Load sheet from a xlsx file

    Parameters
    ----------
    filename: string
        XLSX filename to open
    sheet: string
        name of sheet in XLSX to open

    Returns
    -------
    df: pandas.DataFrame
        dataframe containing data from XLSX sheet.
    '''

    print('open', sheet)
    dataset = pd.read_excel(
        filename,
        sheet_name=sheet,
        na_values=[
            "", "#N/A", "#N/A", "N/A", "#NA", "-1.#IND", "-1.#QNAN",
            "-NaN", "-nan", "1.#IND", "1.#QNAN", "N/A", "NULL",
            "NaN", "n/a", "nan", "null"
        ], keep_default_na=False
    )

    return dataset


def extract_tsd_data(df):
    df['CNTY_AML_RISK'] = -1
    df.loc[df['LIST_CD'].str.contains('L3'), 'CNTY_AML_RISK'] = 3
    df.loc[df['LIST_CD'].str.contains('L4'), 'CNTY_AML_RISK'] = 4
    df.loc[df['LIST_CD'].str.contains('TH-01'), 'CNTY_AML_RISK'] = 5
    # To be confirmed
    df.loc[df['LIST_CD'].str.contains('TH-02'), 'CNTY_AML_RISK'] = 6
    res =  df[df['CNTY_AML_RISK'] > 0][['CNTY_AML_RISK', 'ENTITY_KEY', "EFFECTIVE_DATE", "EXPIRATION_DATE"]] \
               .groupby(['ENTITY_KEY', 'CNTY_AML_RISK']).first()
    group_dict = res.to_dict(orient='index')
    res = {}
    for key, val in group_dict.items():
        a2, risk = key
        try:
            country = pc.countries.get(alpha_2=a2)
        except:
            continue
        if country is None and a2 is not None:
            a3 = a2
        elif country is None and a2 is None:
            continue
        else:
            a3 = country.alpha_3
        new_val = {}
        if val['EXPIRATION_DATE'] is not None:
            new_val['EXPIRATION_DATE'] = pd.to_datetime(
                val['EXPIRATION_DATE'],
                format=get_date_format(val['EXPIRATION_DATE'])
            )
        new_val['EFFECTIVE_DATE'] = pd.to_datetime(
            val['EFFECTIVE_DATE'],
            format=get_date_format(val['EFFECTIVE_DATE'])
        )
        
        if a3 in res:
            res[a3][risk] = new_val
        else:
            res[a3] = {
                risk: new_val
            }

    return res


def extract_data(parameters, df, key_map=None):
    '''Extract models data from dataframe

    Parameters
    ----------
    df: pandas.DataFrame
        dataframe with input parameters data
    key_map: dict
        optional map specifying data to extract

    Returns
    -------
    dict_info: dict
        map with extracted parameters on models.
    '''
    if df.empty:
        return
    
    df["models"] = df.RULE_ID.apply(
        lambda x: [i for i in x.split("-") if i in ["EFT", "TSD", "FTF", "THV"]]
    )
    df = df.explode("models").dropna(subset=["models"])
    dict_info = {}

    for _, row in df.iterrows():
        model, rule = row.models, row.RULE_NAME
        if "THRESHOLD_NAME" in row:
            threshold = row.THRESHOLD_NAME
            if threshold == 'Recurrence Period':
                threshold += ' (days)'
        else:
            threshold = row.SCORE_FACTOR_NAME
        
        rule = rule.strip()
        threshold = threshold.strip()

        bucket = None
        if model == "EFT" and row.RULE_NAME.startswith('Excessive Single Transactions'):
            submodels = row.RULE_NAME.split('-')
            if len(submodels) == 2:
                bucket = submodels[1]
                rule = submodels[0]
                bucket = bucket.strip()
                rule = rule.strip()
                #will be overwritten later

        if model not in dict_info:
            dict_info[model] = {}
        if rule not in dict_info[model]:
            dict_info[model][rule] = {}
        if threshold not in dict_info[model][rule]:
            dict_info[model][rule][threshold] = {}
        if key_map is None:
            if 'ATTRIBUTE_VALUE' in row:
                value = row.ATTRIBUTE_VALUE \
                if math.isfinite(row.ATTRIBUTE_VALUE) else row.DEFAULT_VALUE
            elif 'THRESHOLD_VALUE' in row:
                value = row.THRESHOLD_VALUE
            elif 'SCORE' in row:
                value = row.SCORE
            else:
                value = row.DEFAULT_VALUE

            if bucket is None:
                dict_info[model][rule][threshold] = value
            else:
                dict_info[model][rule][threshold][bucket] =  value

        if key_map is not None:
            for key, val in key_map.items():
                row_key = row[key]
                if key == "POPULATION_GROUP_ID" and row_key.startswith("CLUA"):
                    row_key = str(int(row[key][4:]))
                if bucket is None:
                    if val == "SCORE" and key != "FROM_VALUE":
                        if row_key not in dict_info[model][rule][threshold]:
                            dict_info[model][rule][threshold][row_key] = {}
                        dict_info[model][rule][threshold][row_key][row.FROM_VALUE] = row[val]
                    else:
                        dict_info[model][rule][threshold][row_key] = row[val]
                else:
                    if bucket not in dict_info[model][rule][threshold]:
                        dict_info[model][rule][threshold][bucket] = {}
                    if val == "SCORE" and key != "FROM_VALUE":
                        if row_key not in dict_info[model][rule][threshold][bucket]:
                            dict_info[model][rule][threshold][bucket][row_key] = {}
                        dict_info[model][rule][threshold][bucket][row_key][row.FROM_VALUE] = row[val]
                    else:
                        dict_info[model][rule][threshold][bucket][row_key] = row[val]
                        
    #dynamic bucket mapping
    if 'EFT' in  dict_info and 'Excessive Single Transactions' in dict_info['EFT']:
        old_dic = dict_info['EFT']['Excessive Single Transactions']
        new_dic = {
            key : {b : old_dic[key][b] 
                   if b in ['Cash', 'Check', 'Shared Transactions'] and b in old_dic[key] else old_dic[key]["Shared Transactions"] 
                   for b in parameters.BUCKETS
                  } 
            for key in old_dic
        }
        dict_info['EFT']['Excessive Single Transactions'] = new_dic
    return dict_info


def load_xlsx_parameters(parameters):
    '''Load all input parameters from file

    Parameters
    ----------

    Returns
    -------
    res: dict
        map with extracted parameters on models.
    '''
    
    res = {}
    filename = find_xlsx_parameters_file(parameters)

    wb = openpyxl.load_workbook(filename)
    is_sam3 = "User Thresholds" in wb.sheetnames
    V8_export_dir = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'exports', 'parameters_files'
    )
    os.makedirs(V8_export_dir, exist_ok=True)
    V8_namefile = os.path.join(
        V8_export_dir,
        'CIB ITO FS - SAM8R {} {} Parameters - {}.xlsx'.format(
            parameters.BU,
            parameters.PARAMETERS_SERIALIZATION.PARAMETERS,
            datetime.today().strftime('%y%m%d')
        )
    )

    if is_sam3:
        # Convert PROD V3 to a template V8 then use that template for serialization
        V8_data = convert_V3_to_V8(parameters.BU, filename, parameters)
        export_to_xlsx(
            V8_data, V8_namefile,
            subsheets=constants.PARAMETERS_FILE_SHEETS
        )
        filename = V8_namefile
    else:
        shutil.copyfile(filename, V8_namefile)

    df = pd.read_excel(filename, None, na_values=[
        "", "#N/A", "#N/A", "N/A", "#NA", "-1.#IND", "-1.#QNAN",
        "-NaN", "-nan", "1.#IND", "1.#QNAN", "N/A", "NULL",
        "NaN", "n/a", "nan", "null"
    ], keep_default_na=False)
    
    list_keys = list(df.keys())
    for sheet in list_keys:                
        df[sheet] = df[sheet].dropna(axis=0, how="all")\
                                .dropna(axis=1, how="all")
        if sheet.strip() != sheet:
            df[sheet.strip()] = df[sheet]
            df.pop(sheet, None)

    df_data = {
        "user": {
            "sheet": [
                "Default Thresholds",
                "Tenant Thresholds"
            ]
        },
        "population": {
            "sheet": "Population Thresholds"
        },
        "individual": {
            "sheet": "Individual Thresholds"
        },
        "whitelist": {
            "sheet": "Lists"
        },
            "user_score": {
                "sheet": [
                "Default Scores",
                "Tenant Scores"
            ]
        },
        "population_score": {
            "sheet": "Population Scores"
        },
        "individual_score": {
            "sheet": "Individual Scores"
        },
        "tsd_country": {
            "sheet": "Lists-TSD THV LTH" 
        }
    }

    for _,val in df_data.items():
        if isinstance(val["sheet"], list):
            val["data"] = []
            for sheet in val["sheet"]:
                val["data"] += [df[sheet]]
        else:
            val["data"] = df[val["sheet"]]
            
    # Get whitelist
    list_models = constants.SAM3_MODELS if is_sam3 else constants.SAM8_MODELS
    
    
    if "ENTITY_KEY" in df_data["whitelist"]["data"].columns:
        res["whitelist"] = list(
            set(df_data["whitelist"]["data"][
                df_data["whitelist"]["data"]["LIST_NAME"] == "Account White List"
            ]["ENTITY_KEY"])
        )
        
        res["model_whitelist"] = {}
        for model in list_models:
            res["model_whitelist"][model] = list(
                set(df_data["whitelist"]["data"][
                    df_data["whitelist"]["data"]["LIST_NAME"].str.contains("White List") &
                    df_data["whitelist"]["data"]["LIST_NAME"].str.contains("Model") &
                    df_data["whitelist"]["data"]["LIST_NAME"].str.contains(model)
                ]["ENTITY_KEY"])
            )

    else:
        res["whitelist"] = []
        res["model_whitelist"] = {model: [] for model in list_models}
        
    # Get generic BU thresholds ("user")
    if isinstance(df_data["user"]["data"], list):
        thresholds = {}
        for df_sheet in df_data["user"]["data"]:
            thresholds = update(thresholds, extract_data(parameters, df_sheet))
        res["user"] = thresholds
    else:    
        res["user"] = extract_data(parameters, df_data["user"]["data"])
    
    # Get thresholds per cluster ("cluster")
    res["cluster"] = extract_data(parameters, 
        df_data["population"]["data"],
        {"POPULATION_GROUP_ID": "THRESHOLD_VALUE"}
    )
    
    # Get specific thresholds for accounts ("individual")
    res["individual"] = extract_data(parameters, 
        df_data["individual"]["data"],
        {"ENTITY_KEY": "THRESHOLD_VALUE"}
    )
    
    # Get generic BU scores ("user")
    if isinstance(df_data["user_score"]["data"], list):
        thresholds = {}
        for df_sheet in df_data["user_score"]["data"]:
            thresholds = update(thresholds, extract_data(parameters, df_sheet, {
                "FROM_VALUE": "SCORE"
            }))
        res["user_score"] = thresholds
    else:    
        res["user_score"] = extract_data(parameters, df_data["user_score"]["data"], {
                "FROM_VALUE": "SCORE"
            })
    
    # Get scores per cluster (clusters)
    res["cluster_score"] = extract_data(parameters, 
        df_data["population_score"]["data"],
        {"POPULATION_GROUP_ID": "SCORE"}
    )
    
    # Get specific scores for accounts ("individual")
    res["individual_score"] = extract_data(parameters, 
        df_data["individual_score"]["data"],
        {"ENTITY_KEY": "SCORE"}
    )
    
    # Get TSD country codes
    if "tsd_country" in df_data:
        res["tsd_country"] = \
            extract_tsd_data(df_data["tsd_country"]["data"])
    
    return res


def serialize_parameters(parameters):
    ''' Serialize parameters for list of BUs
    '''
    thresholds_dir = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'thresholds'
    )
    save_as_pickle(
        load_xlsx_parameters(parameters),
        os.path.join(
            thresholds_dir,
            'thresholds_{}_{}.pickle'.format(
                parameters.BU, parameters.EXPERIMENT_KEY
            )
        )
    )


def convert_V3_to_V8(bu, V3_file_path, parameters):
    V8_template = load_parameters_file(os.path.join(
        constants.READ_ONLY_DATA_PATH, 'other_resources', 'parameters_template.xlsx'
    ))

    # Convert amounts with local currency rate
    if parameters.LOCAL_CURRENCY_RATE != 1.0:
        for sheet, target_columns in constants.SHEET_TARGET_COLUMNS_MAPPING.items():
            if sheet not in V8_template:
                constants.LOGGER.info(f"invalid V8 template, sheet {sheet} not found")
                continue
            currency_amount_parameters = V8_template[sheet][
                target_columns[0]
            ].str.contains(
                "Sum|Transaction Amount|transaction value|Transaction Value|Activity Value"
            )
            
            #removing "N/A"
            currency_amount_parameters = currency_amount_parameters.fillna(False)
            V8_template[sheet][target_columns[1]] = V8_template[sheet][target_columns[1]].apply(lambda x : np.nan if x == 'N/A' else float(x))
            
            V8_template[sheet].loc[
                currency_amount_parameters,
                target_columns[1]
            ] *= parameters.LOCAL_CURRENCY_RATE
    
    # Update tenant code with ISO3 BU
    for sheet, tenant_col in constants.SHEET_TENANT_ID_COLUMN.items():
        if sheet not in V8_template:
            constants.LOGGER.info(f"invalid V8 template, sheet {sheet} not found")
            continue
        V8_template[sheet][tenant_col] = bu
        
    # Update region code with ISO3 BU + "_R"
    for sheet, region_col in constants.SHEET_REGION_ID_COLUMN.items():
        if sheet not in V8_template:
            constants.LOGGER.info(f"invalid V8 template, sheet {sheet} not found")
            continue
        V8_template[sheet][region_col] = f"{bu}_R" 
        
    # Add whitelisted accounts and keywords
    df_lists_V8 = []
    for V3_list, changes in constants.V8_LISTS_NAMES.items(): 
        df_V3_list = load_xlsx_sheet(
            V3_file_path,
            V3_list
        )
        
        for column, value in changes.items():
            df_V3_list[column] = value
        for col in ["COMMENTS", "PREDEFINED_COMMENTS_CD"]:
            if col in df_V3_list.columns:
                df_V3_list = df_V3_list.drop(col, axis=1)
        df_lists_V8.append(df_V3_list)
        
    df_lists_V8 = pd.concat(df_lists_V8, axis=0)
    
    # Account White List (remove duplicates)
    df_lists_V8_account_whitelist = df_lists_V8[df_lists_V8['LIST_ID'].str.contains('AML-ACT-EX')]
    df_lists_V8_account_whitelist.drop_duplicates(subset = ['ENTITY_KEY'], inplace=True)
    
    # Keywords White List (lowerkey + remove duplicates)
    df_lists_V8_keywords_whitelist = df_lists_V8[df_lists_V8['LIST_ID'].str.contains('BNP-WRD-EX')]
    df_lists_V8_keywords_whitelist['ENTITY_KEY'] = df_lists_V8_keywords_whitelist['ENTITY_KEY'].str.lower()
    df_lists_V8_keywords_whitelist.drop_duplicates(subset = ['LIST_ID', 'ENTITY_KEY'], inplace=True)    
    
    # Keywords (lowerkey + remove duplicates at global level (keep only most restrictive model CTF > KHI > KLO))
    df_lists_V8_keywords = df_lists_V8[df_lists_V8['LIST_ID'].str.contains('BNP-WRD-KY')]
    df_lists_V8_keywords['ENTITY_KEY'] = df_lists_V8_keywords['ENTITY_KEY'].str.lower()
    df_lists_V8_keywords.sort_values(['LIST_NAME', 'ENTITY_KEY'], inplace=True)
    df_lists_V8_keywords.drop_duplicates(subset = ['ENTITY_KEY'], keep='last', inplace=True)
        
    df_lists_V8 = pd.concat([df_lists_V8_account_whitelist, df_lists_V8_keywords_whitelist, df_lists_V8_keywords], axis=0)
    
    df_lists_V8["TENANT_ID"] = bu
    df_lists_V8["REGION_CD"] = f"{bu}_R"
    df_lists_V8["ENTITY_KEY2"] = "0"
    df_lists_V8["RISK_LEVEL_CD"] = "0"

    V8_template["Lists"] = df_lists_V8
    
    default_thresholds = load_xlsx_sheet(
        V3_file_path,
        "User Thresholds"
    )
    default_thresholds = default_thresholds[
        ~default_thresholds["ATTRIBUTE_VALUE"].isna()
    ]
    for v8_param, v3_param in constants.V8_V3_PARAMETERS_MAPPING.items():
        V8_template["Tenant Thresholds"].loc[
            V8_template["Tenant Thresholds"]["THRESHOLD_NAME"] == v8_param,
            "THRESHOLD_NAME"
        ] = v3_param
    def apply_default_thresholds(x):
        V8_template["Tenant Thresholds"].loc[
            (V8_template["Tenant Thresholds"]["THRESHOLD_NAME"] == x["THRESHOLD_NAME"]) \
            & (V8_template["Tenant Thresholds"]["RULE_NAME"].str.startswith(x["RULE_NAME"])),
            "THRESHOLD_VALUE"
        ] = x["ATTRIBUTE_VALUE"]
    default_thresholds.apply(
        apply_default_thresholds,
        axis=1
    )

    return V8_template
