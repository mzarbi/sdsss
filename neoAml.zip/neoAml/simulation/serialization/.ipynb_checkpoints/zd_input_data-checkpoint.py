import os
import shutil
import gc
import pyarrow
import pyarrow.parquet as pq
import pandas as pd
import numpy as np
from tqdm import tqdm
from copy import deepcopy

from ..utils import constants, utils
from ..utils.serialization import load_parameters
from ..utils.parquet import ParquetStreamer, update_types_to_schema, get_transactions_by_chunk, enforce_non_null_schema
from ..utils.kyc import load_kyc
from ..actimize.ftf import compute_lookback_sums


def load_mappings(parameters):
    ''' Load bucket and cluster mappings for the business
    unit
    
    Parameters
    ----------

    Returns
    -------
    mappings: dict of dict
        map of transaction type code to bucket (mappings)
    '''
    budirname = os.path.join(
        utils.get_DATA_PATH_LAST_YEAR(parameters), parameters.BU, 'Buckets'
    )
    map_filename = os.path.join(budirname, '{}_SAM8_Bucket_Mapping.csv'.format(parameters.BU))
    if not os.path.isfile(map_filename):
        raise Exception('Warning no SAM8 bucket mapping found')

    mappings = {}
    # Load the bucket mappings
    bucket_data = pd.read_csv(map_filename, sep=';')
    for col, other_names in constants.BUCKET_MAPPING_COLUMNS.items():
        if col not in bucket_data.columns:
            for new_col in other_names:
                if new_col in bucket_data.columns:
                    bucket_data = bucket_data.rename(columns={
                        new_col: col
                    })
                    break
    mappings = dict(zip(list(bucket_data['Local Code']), list(bucket_data['New Mapping'])))
    
    unknown_mappings = [x for x in set(mappings.values()) if not x in parameters.BUCKETS]
    assert len(unknown_mappings) == 0, f"Unknown mappings : {unknown_mappings}, known mappings : {list(parameters.BUCKETS)}"
    
    local_codes = list(mappings.keys())
    for local_code in local_codes:
        mappings['D_' + str(local_code)] = mappings[local_code]
        mappings['C_' + str(local_code)] = mappings[local_code]
    
    return mappings
        

def get_type_options(cols_to_load):
    ''' Returns type options for reading csv raw data
    
    Parameters
    ----------
    cols_to_load
        List of column names that will be read from Postings, Payments or Alerts csv

    Returns
    -------
    dtype_options: dict
        map of column names to data types
        Default type is str unless specified in SERIALIZATION_COLUMNS_TYPES mapping
    '''
    return {
        col: constants.SERIALIZATION_COLUMNS_TYPES.get(col, str) \
        for col in cols_to_load
    }


def get_columns_mapping(filename, transaction_type):
    ''' Get columns properties of transaction file
    Parameters
    ----------
    filename: string
    path to the csv file of transactions
    
    transaction_type: string
    type of the transactions, either 'Payments' or 'Postings'
    
    Returns
    -------
    cols_mapping: dict of mapping between column names found and standardized column names
    cols_to_load: list of columns to read
    separator: string separating columns in the csv
    '''
    cols_to_load = []
    with open(filename, encoding='utf-8-sig') as in_file:
        header = in_file.readline()
    separator = utils.sniff_csv_separator(header)
    header = header.replace('"', '')
    list_columns = header.split(separator)

    cols_mapping = {}
    for col in constants.COLUMNS_SAM8_SAM3.keys():
        if col in list_columns:
            cols_to_load += [col]
            cols_mapping[col] = col
        else:
            found = False
            for proposed_col in constants.COLUMNS_SAM8_SAM3[col]:
                if proposed_col in list_columns:
                    cols_to_load += [proposed_col]
                    cols_mapping[proposed_col] = col
                    found = True
                    break

            if (not found) and (\
                col in (constants.MANDATORY_COLUMNS + \
                        constants.MANDATORY_COLUMNS_PER_TRANSACTION[transaction_type] \
                       )):
                raise Exception("Cannot find column for {} in file {}".format(
                        col, filename
                    ))
    return cols_mapping, cols_to_load, separator


def export_payments_to_parquet(names, outname, bu, thresholds):
    ''' Write payments to a new parquet file. Contrary to postings, payments are not
    chunked by account, but with a constant chunk size.
    
    Parameters
    ----------
    name: string
        Name of input csv file or directory
    outname: string
        Name of output parquet file
    bu: string
        Shortcut of business unit to fill in if not found in csv
    mappings: dict of dict, default None
        map of transaction type code to bucket (mappings)
    '''
    list_files = []
    for name in names:
        if os.path.isdir(name):
            list_files += [os.path.join(name, file) for file in os.listdir(name)]
    
    if os.path.exists(constants.TEMP_PARQUET_DIR):
        shutil.rmtree(constants.TEMP_PARQUET_DIR)    
    os.makedirs(constants.TEMP_PARQUET_DIR, exist_ok=True)
    schema = None

    for filename in list_files:
        if not filename.endswith('.csv'):
            continue
        print(filename)
        continue
        constants.LOGGER.info(
            'Export data from {} to parquet'.format(filename)
        )
        cols_mapping, cols_to_load, separator = get_columns_mapping(
            filename, 'Payments'
        )

        for df in tqdm(pd.read_csv(
            filename,
            encoding='utf-8-sig', sep=separator,
            usecols=cols_to_load,
            dtype=get_type_options(list(cols_mapping.values())),
            chunksize=constants.CHUNKSIZE
        )):

            # filter whitelisted accounts
            df = df[~df['ACCOUNT_KEY'].isin(thresholds['whitelist'])]\
                                      .reset_index(drop=True)

            # filter whitelisted accounts for TSD model
            df = df[~df['ACCOUNT_KEY'].isin(thresholds['model_whitelist']['TSD'])]\
                                      .reset_index(drop=True)
            
            # Apply SAM3-SAM8 Mappings
            df = df.rename(columns=cols_mapping)
            if 'BU' not in df.columns:
                df['BU'] = bu
            if 'CRDS_CODE' not in df.columns:
                df['CRDS_CODE'] = df['CLIENTNUM']
            if 'RMPM_CODE' not in df.columns:
                df['RMPM_CODE'] = df['CLIENTNUM']

            df = df[
                (df['CRDS_CODE'].str.len().isin([7, 12])) \
                & (~df['CRDS_CODE'].isna())
            ].reset_index(drop=True)

            if len(df) == 0:
                continue

            df['CNTY_AML_RISK'] = df['CNTY_AML_RISK'].fillna("1").astype(np.int64)

            # Map Client risk levels
            df[constants.RISK_SCORE_KEY] = df[constants.RISK_SCORE_KEY].map(constants.RISK_LEVEL_MAPPING)

            df = df.sort_values('ACCOUNT_KEY').reset_index(drop=True)
            
            if schema is None:
                schema = enforce_non_null_schema(
                    deepcopy(pyarrow.Table.from_pandas(df).schema)
                )
                writer = ParquetStreamer(outname, schema)

            writer.write(df)

    # Close and clean-up        
    if os.path.exists(constants.TEMP_PARQUET_DIR):
        shutil.rmtree(constants.TEMP_PARQUET_DIR)
    writer.writer.close()   


def export_postings_to_parquet(names, outname, bu, thresholds):
    ''' Write postings to a new parquet file

    Parameters
    ----------
    name: string
        Name of input csv file or directory
    outname: string
        Name of output parquet file
    bu: string
        Shortcut of business unit to fill in if not found in csv
    mappings: dict of dict, default None
        map of transaction type code to bucket (mappings)
    '''
    list_files = []
    for name in names:
        if os.path.isdir(name):
            list_files += [os.path.join(name, file) for file in os.listdir(name)]
    
    if os.path.exists(constants.TEMP_PARQUET_DIR):
        shutil.rmtree(constants.TEMP_PARQUET_DIR)    
    os.makedirs(constants.TEMP_PARQUET_DIR, exist_ok=True)
    schema = None
    
    list_codes = {}

    # Sequentially read files in directory and writes data to different parquet files
    # One parquet file per RMPM_CODE
    assert len(list_files) > 0, f"No postings found in {names}"
    for filename in list_files:
        if not filename.endswith('.csv'):
            continue
        print(filename)
        continue
        constants.LOGGER.info(
            'Export data from {} to parquet'.format(filename)
        )
        cols_mapping, cols_to_load, separator = get_columns_mapping(
            filename, 'Postings'
        )

        for df in tqdm(pd.read_csv(
            filename,
            encoding='utf-8-sig', sep=separator,
            usecols=cols_to_load,
            dtype=get_type_options(list(cols_mapping.values())),
            chunksize=constants.CHUNKSIZE
        )):
            # filter whitelisted accounts
            df = df[~df['ACCOUNT_KEY'].isin(thresholds['whitelist'])]\
                                      .reset_index(drop=True)
            
            # filter whitelisted accounts for EFT + FTF + SBP
            whitelist_accounts = set(thresholds['model_whitelist']['EFT']) & set(thresholds['model_whitelist']['FTF'])
            if thresholds['model_whitelist'].get('SBP') is not None:
                whitelist_accounts &= set(thresholds['model_whitelist']['SBP'])
            df = df[~df['ACCOUNT_KEY'].isin(whitelist_accounts)].reset_index(drop=True)

            #De-duplicate mother postings
            df = df.groupby('POS_ID') \
                   .first() \
                   .reset_index(drop=False)
            

            # Apply SAM3-SAM8 Mappings
            df = df.rename(columns=cols_mapping)
            if 'BU' not in df.columns:
                df['BU'] = bu
            if 'CRDS_CODE' not in df.columns:
                df['CRDS_CODE'] = df['CLIENTNUM']
            if 'RMPM_CODE' not in df.columns:
                df['RMPM_CODE'] = df['CLIENTNUM']
            if 'PARTY_NAME' not in df.columns:
                df['PARTY_NAME'] = ""
                
            df = df[
                (df['CRDS_CODE'].str.len().isin([7, 12])) \
                & (~df['CRDS_CODE'].isna())
            ].reset_index(drop=True)
            
            if len(df) == 0:
                continue

            # Map Client risk levels
            df[constants.RISK_SCORE_KEY] = df[constants.RISK_SCORE_KEY].map(constants.RISK_LEVEL_MAPPING)

            if schema is None:
                schema = enforce_non_null_schema(
                    deepcopy(pyarrow.Table.from_pandas(df).schema)
                )
                
            for code, group in df.groupby([constants.CHUNK_GROUPING_KEY]):
                if code not in list_codes:
                    list_codes[code] = pq.ParquetWriter(
                        os.path.join(
                            constants.TEMP_PARQUET_DIR,
                            '{}.parquet'.format(code)
                        ),
                        schema
                    )
                list_codes[code].write_table(pyarrow.Table.from_pandas(
                    group, preserve_index=False, schema=schema
                ))

            #Also export transactions without CRDS_CODE
            if 'NaN' not in list_codes:
                list_codes['NaN'] = pq.ParquetWriter(
                    os.path.join(
                        constants.TEMP_PARQUET_DIR,
                        'NaN.parquet'
                    ),
                    schema
                )
            list_codes['NaN'].write_table(pyarrow.Table.from_pandas(
                df[df[constants.CHUNK_GROUPING_KEY].isnull()],
                preserve_index=False, schema=schema
            ))
            
            del df
            gc.collect()

    writer = ParquetStreamer(outname, schema)
    list_df = []
    nrows = 0
    constants.LOGGER.info('Gathering client parquet files per chunk')
    # Gather all parquet files in one, merging by chunk of size at least CHUNKSIZE
    for i, (code,stream) in tqdm(enumerate(list_codes.items())):
        stream.close()
        df = pq.read_table(
            os.path.join(
                constants.TEMP_PARQUET_DIR,
                '{}.parquet'.format(code)
            )
        ).to_pandas()
        
        #De-duplicate mother postings
        df = df.groupby('POS_ID') \
               .first() \
               .reset_index(drop=False)

        nrows += len(df)
        list_df += [df]
        if nrows > constants.CHUNKSIZE or i == len(list_codes)-1:
            df = pd.concat(list_df)
            writer.write(df)
            list_df = []
            nrows = 0

    # Close and clean-up        
    if os.path.exists(constants.TEMP_PARQUET_DIR):
        shutil.rmtree(constants.TEMP_PARQUET_DIR)
    writer.writer.close()   
    
    
def export_to_parquet(names, outname, transaction_type, bu, thresholds):
    if transaction_type == 'Payments':
        export_payments_to_parquet(names, outname, bu, thresholds)
    elif transaction_type == 'Postings':
        export_postings_to_parquet(names, outname, bu, thresholds)


def patch_alerts_status(alerts, steps, kyc_data, non_eligible):
    if alerts.empty:
        return alerts, non_eligible
    # Work at ALERT_ID level, optimization for multitransactional models
    alerts_extended = alerts.groupby("ALERT_ID").first() \
                            .drop(labels="RISK_LEVEL", axis=1)
    alerts_extended = alerts_extended.merge(steps, how="left", on="ALERT_ID")
    alerts_extended = alerts_extended.merge(kyc_data[[
        "CRDS_CODE", 'HAS_FSI', "RISK_LEVEL"
    ]], how="left", on="CRDS_CODE")
    alerts_extended["STEP"] = np.where(
        alerts_extended["STEP_NAME"].isna(),
        alerts_extended["STEP"],
        alerts_extended["STEP_NAME"]
    )
    alerts_extended["STEP_DATE"] = np.where(
        alerts_extended["STEP_DATE"].isna(),
        utils.lookup(alerts_extended["GENERATION_DATE"]),
        alerts_extended["STEP_DATE"]
    )
    
    escalations = alerts_extended[
        alerts_extended["STEP"].str.contains("L2|L3")
    ]

    # Escalations status expliciting they should have not been escalated
    cond1 = escalations[
        (escalations["STEP"] == constants.NON_RELEVANT_ESCALATION_STATUS)
    ]
    cond1["MESSAGE"] = f"STEP {constants.NON_RELEVANT_ESCALATION_STATUS}"

    # Escalations upon FSI that has been removed
    automatic_escalations = (escalations[
        escalations["STEP_NAME"] == "L1 - compulsory escalation to L2"
    ])
    cpl_escalations = (escalations[
        escalations["NOTE"].str.contains("CPL0287|CPL00287") \
        & escalations["ALERT_ID"].isin(automatic_escalations["ALERT_ID"])
    ])
    escalations_with_notes = escalations[
        ~escalations["NOTE"].isna()
    ]
    cond_escalations_fsi = escalations_with_notes[
        escalations_with_notes["ALERT_ID"].isin(cpl_escalations["ALERT_ID"]) \
        & (escalations_with_notes["ALERT_STATE"] == "Closed") \
        & (escalations_with_notes["HAS_FSI"] == "NO_FSI")
    ]
    cond_escalations_fsi["MESSAGE"] = "AUTOMATIC ESCALATION FOR FSI THAT HAS BEEN REMOVED"

    # SCT escalations on clients that are no longer high risk
    cond_sct = escalations[
        escalations["RISK_LEVEL"].isin(["0-LOW", "1-MEDIUM"]) \
        & (escalations["RULE_ID"] == "BNP-SCT-RSK-ACT-P-D01-EAT")
    ]
    cond_sct["MESSAGE"] = "SCT ESCALATION FOR CLIENT NO LONGER HIGH RISK"
    
    # Concat non eligible escalations
    cols_to_keep = ["ALERT_ID", "RULE_ID", "CRDS_CODE", "GENERATION_DATE", "MESSAGE"]
    loc_non_eligible = pd.concat([
        cond1[cols_to_keep].drop_duplicates(),
        cond_escalations_fsi[cols_to_keep].drop_duplicates(),
        cond_sct[cols_to_keep].drop_duplicates(),        
    ], axis=0).groupby(["ALERT_ID"]).agg({
        "RULE_ID": "first", "CRDS_CODE": "first",
        "GENERATION_DATE": "first", "MESSAGE": list
    }).reset_index(drop=False)
    
    if not loc_non_eligible.empty:
        if non_eligible is None:
            non_eligible = loc_non_eligible
        else:
            non_eligible = pd.concat([non_eligible, loc_non_eligible], axis=0)

    # Apply last step status and patch non eligible escalations 
    idx = alerts_extended.groupby(["ALERT_ID"])["STEP_DATE"].idxmax()
    alerts_extended = alerts_extended.loc[idx][["ALERT_ID", "STEP"]]
    idx = alerts_extended["ALERT_ID"].isin(loc_non_eligible["ALERT_ID"])
    alerts_extended.loc[idx, "STEP"] = "Not eligible escalation to level two"

    alerts = alerts.drop(labels="STEP", axis=1) \
                   .merge(alerts_extended, how="left", on="ALERT_ID")
    return alerts, non_eligible


def load_alerts_steps(inputdirs):
    cols = ["ALERT_ID", "STEP_ID", "STEP_NAME", "STEP_DATE", "ALERT_STATE"]
    list_df = []
    for inputdir in inputdirs:
        subdir = inputdir + "Steps"
        if not os.path.isdir(subdir):
            continue
        for file in os.listdir(subdir):
            if not file.endswith(".csv"):
                continue
            infile = os.path.join(subdir, file)
            df = pd.read_csv(
                infile, encoding='utf-8-sig', sep=";",
                usecols=cols
            )
            df = df[~df["STEP_NAME"].isna()]
            list_df.append(df)
    
    if len(list_df) == 0:
        raise Exception(f'Alerts were not found in these folders : {inputdirs}')
        
    steps = pd.concat(list_df, axis=0)
    steps["STEP_DATE"] = utils.lookup(steps["STEP_DATE"])
    return steps


def load_alerts_notes(inputdirs):
    cols = ["ALERT_ID", "STEP_ID", "NOTE", "NOTE_DATE"]
    list_df = []
    for inputdir in inputdirs:
        subdir = inputdir + "Notes"
        if not os.path.isdir(subdir):
            continue
        for file in os.listdir(subdir):
            if not file.endswith(".csv"):
                continue
            infile = os.path.join(subdir, file)
            df = pd.read_csv(
                infile, encoding='utf-8-sig', sep=";", usecols=cols
            )
            df = df[~df["NOTE"].isna()]
            list_df.append(df)
    notes = pd.concat(list_df, axis=0)
    return notes


def load_alerts_steps_and_notes(inputdirs):
    steps = load_alerts_steps(inputdirs)
    notes = load_alerts_notes(inputdirs)
    steps = steps.merge(notes, on=["ALERT_ID", "STEP_ID"], how="left")
    steps = steps[
        ~steps["NOTE"].isna()
    ]
    return steps


def export_alerts(inputdirs, outdir, bu, file_key, add_notes=True):
    list_df = []
    os.makedirs(outdir, exist_ok=True)
    
    if add_notes:
        steps = load_alerts_steps_and_notes(inputdirs)
    kyc_data = load_kyc(bu)
    non_eligible = None

    for model in set(constants.SAM3_MODELS + constants.SAM8_MODELS):
        thv_writer = None
        writer = None
        first = True
        base_columns = None
        base_types = None
        
        constants.LOGGER.info(f"Serialize alerts for model {model}")

        for inputdir in inputdirs:
            subdir_alerts = os.path.join(inputdir, model)
            if not os.path.isdir(subdir_alerts):
                continue

            for file in os.listdir(subdir_alerts):
                if model + '_' in file and file.endswith('.csv'):
                    infile = os.path.join(subdir_alerts, file)
                    
                    cols = [
                        "ALERT_ID", "ALERT_DATE", "GENERATION_DATE", 
                        "STEP", "BU", "RULE_ID", "SCORE", "ALERT_SCORE",
                        "CLIENT_N0", "TRANS_VALUE_DATE", "TRANSACTION_KEY", "CRDS_CODE",
                        "RMPM_CODE", "RISK_LEVEL", "POPULATION_GROUP_ID", "MAIN_CURRENCY_AMT",
                        "ESCALATION_DATE_TO_L2", "ESCALATION_DATE_TO_L3"
                    ]
                    
                    with open(infile, encoding='utf-8-sig') as in_file:
                        header = in_file.readline()
                    separator = utils.sniff_csv_separator(header)
                    header = header.replace('"', '')
                    list_columns = header.split(separator)
                    if base_columns is None:
                        base_columns = list_columns
                        base_types = get_type_options(base_columns)
                    args = {}
                    if list_columns[0] != base_columns[0]:
                        args = {"names": base_columns}

                    try:
                        df = pd.read_csv(
                            infile, encoding='utf-8-sig', sep=separator,
                            dtype=base_types,
                            **args
                        )
                    except:
                        constants.LOGGER.info(f"Cannot read alert file {infile}")
                        base_columns = None
                        continue

                    cols_mapping = {}
                    if 'ACCOUNT_KEY' not in df.columns:
                        if 'ACC_KEY' in df.columns:
                            cols += ['ACC_KEY']
                            cols_mapping['ACC_KEY'] = 'ACCOUNT_KEY'
                        else:
                            constants.LOGGER.info(f'No Account key found in alert file {infile}')
                            base_columns = None
                            continue
                    else:
                        cols += ['ACCOUNT_KEY']

                    df = df[cols]
                    df["RMPM_CODE"] = np.where(
                        df["RMPM_CODE"].isna(),
                        df["CLIENT_N0"],
                        df["RMPM_CODE"]
                    )

                    # Remove spurious additional header lines
                    df = df.drop_duplicates()
                    if not df.empty:
                        if df['ALERT_ID'].iloc[0] == 'ALERT_ID':
                            df = df.iloc[1:]
                            for col in [
                                'SCORE', 'ALERT_SCORE',
                            ]:
                                df[col] = df[col].astype(float)
                            for col in [
                                'ESCALATION_DATE_TO_L2', 'ESCALATION_DATE_TO_L3'
                            ]:
                                df[col] = df[col].astype(str)

                    df = df.rename(columns=cols_mapping)
                    
                    # It can happen in alert files that amounts are not in float type
#                     if dict(df.dtypes)["MAIN_CURRENCY_AMT"] == np.object_:
#                         df.MAIN_CURRENCY_AMT = df.MAIN_CURRENCY_AMT.astype(str).str.replace(",", ".").astype(float)

                    if add_notes:
                        df, non_eligible = patch_alerts_status(
                            df, steps, kyc_data, non_eligible
                        )    
                    
                    list_df.append(df)

                    if writer is None:
                        schema = enforce_non_null_schema(
                            pyarrow.Table.from_pandas(df).schema
                        )
                        outfile = os.path.join(
                            outdir,
                            '{}_{}_{}.parquet'.format(model, bu, file_key)
                        )
                        writer = ParquetStreamer(outfile, schema)
                        if model == 'TSD':
                            thv_outfile = os.path.join(
                                outdir,
                                '{}_{}_{}.parquet'.format('THV', bu, file_key)
                            )
                            thv_writer = ParquetStreamer(thv_outfile, schema)

                    if model == 'TSD' and 'BNP-TSD-EFT-ALL-A-S01-THV' in df.RULE_ID.unique():
                        df_thv = df[df.RULE_ID.isin(['BNP-TSD-EFT-ALL-A-S01-THV'])]
                        if not df_thv.empty:
                            table = update_types_to_schema(
                                pyarrow.Table.from_pandas(df_thv),
                                schema
                            )
                            thv_writer.write_table(table)

                        df = df[~df.RULE_ID.isin(['BNP-TSD-EFT-ALL-A-S01-THV'])]

                    if df.empty and first:
                        writer = None
                        continue
                    elif df.empty and not first:
                        continue

                    table = update_types_to_schema(
                        pyarrow.Table.from_pandas(df),
                        schema
                    )
                    writer.write_table(table)
                    first = False

        if writer is not None:
            writer.writer.close()
        if thv_writer is not None:
            thv_writer.writer.close()       

    all_df = pd.concat(list_df, axis=0, ignore_index=True)
    schema = pyarrow.Table.from_pandas(all_df).schema
    outfile = os.path.join(
        outdir,
        'ALL_{}_{}.parquet'.format(bu, file_key)
    )
    writer = ParquetStreamer(outfile, schema)

    if not all_df.empty:
        #all_df = update_types_to_schema(all_df, schema)
        writer.write_table(pyarrow.Table.from_pandas(all_df))

    if writer is not None:
        writer.writer.close()
        
    if add_notes:
        non_eligible_path = os.path.join(
            constants.READ_WRITE_DATA_PATH, bu, "exports/audit_trail",
            "non_eligible_escalations.csv"
        )
        os.makedirs(os.path.join(
            constants.READ_WRITE_DATA_PATH, bu, "exports/audit_trail"
        ), exist_ok=True)
 #       non_eligible.to_csv(non_eligible_path, sep=';', index=False)
 #       if non_eligible:
 #           non_eligible.to_csv(non_eligible_path, sep=';', index=False)
    
def add_bucket_mapping_to_postings(parameters, mappings):
    postings_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'processed',
        f'CTP_{parameters.BU}_Postings_RAW.parquet'
    )
    postings = pd.read_parquet(postings_file)
    postings['transaction_type'] = postings['TRANS_TYPE_CD'].map(mappings).fillna('Shared Transactions')

    if parameters.BUCKET_MAPPING_MODE == "ADVANCED": 
        constants.LOGGER.info('Applying advanced bucket mapping')
        payments_file = os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU, 'processed',
            f'CTP_{parameters.BU}_Payments_RAW.parquet'
        )
        payments = pd.read_parquet(payments_file, columns=['POS_ID', 'PAY_ID', 'CNTY_AML_RISK', 'OPP_COUNTRY_CD'])
        payments_per_postings = payments['POS_ID'].value_counts()
        postings['n_payments'] = postings['POS_ID'].map(payments_per_postings).fillna(0).astype(int)

        country_risk_mapping = payments[['PAY_ID', 'CNTY_AML_RISK']].set_index('PAY_ID')['CNTY_AML_RISK'].to_dict()
        country_mapping = payments[['PAY_ID', 'OPP_COUNTRY_CD']].set_index('PAY_ID')['OPP_COUNTRY_CD'].to_dict()

        postings['transaction_type'] = advanced_bucket_mapping(parameters, postings, country_risk_mapping, country_mapping)
        
    #checks
    unknown_mappings = [x for x in set(postings['transaction_type']) if not x in parameters.BUCKETS]
    assert len(unknown_mappings) == 0, f"Unknown mappings : {unknown_mappings}, known mappings : {parameters.BUCKETS}"
    print(postings['transaction_type'].value_counts())
    
    postings.to_parquet(postings_file)

def advanced_bucket_mapping(parameters, postings, country_risk_mapping, country_mapping):
    """
    1-to-0: a posting has no associated payment data (standalone posting)
        Bucket #1: Cash entry codes as in the simple EFT bucket mapping
        Bucket #2: Cheque entry codes as in the simple EFT bucket mapping
        Bucket #3: Other standalone postings 

    1-to-many: a posting is related to multiple payments (mass booking)
        Buckets #4 to #6: Buckets shall be organized according to the number of underlying payments 
        Bucket #4 : up to 102 payments
        Bucket #5 : between 102 and 103 payments
        Bucket #6 : 103 and more payments

    1-to-1: a posting gives rise to exactly 1 payment
        Bucket #7: Domestic credits
        Bucket #8: Domestic debits
        Bucket #9: Cross-border credits from LS and MS countries2
        Bucket #10: Cross-border debits to LS and MS countries2
        Bucket #11: Cross-border payments from/to HS, VHS and THV countries2 (the score of this bucket shall be set to 0 as these payments are already covered by TSD/THV)
    """
    len_df = len(postings) #to check later
    postings['cash_check'] = postings['transaction_type'].isin(['Cash', 'Check'])
    other_postings = postings[~postings['cash_check']]
    
    #1 to 0, we keep the current bucket mapping
    postings_1_to_0 = other_postings[other_postings['n_payments'] == 0]
    
    #1 to many, we bucket based on the number of payments
    postings_1_to_many = other_postings[other_postings['n_payments'] > 1]
    postings_1_to_many['log_n_payments'] = np.log10(postings_1_to_many['n_payments']).astype(int)
    postings_1_to_many['transaction_type'] = "1 to many : log " + postings_1_to_many['log_n_payments'].clip(0, 3).map({
        0 : "1 to many : up to 10^1 payments", 
        1 : "1 to many : between 10^1 and 10^2 payments", 
        2 : "1 to many : between 10^2 and 10^3 payments", 
        3 : "1 to many : 10^3 payments and more", 
    })
    
    #1 to many, we bucket based on Credit/Debit and Cross border risk
    postings_1_to_1 = other_postings[other_postings['n_payments'] == 1]
    postings_1_to_1['credit'] = postings_1_to_1['TRANS_TYPE_CD'].str[0] == "C"
    postings_1_to_1['opp_country'] = postings_1_to_1['PAY_ID'].map(country_mapping)
    postings_1_to_1['domestic'] = postings_1_to_1['opp_country'] == parameters.BU

    postings_1_to_1['transaction_type'] = "1 to 1 : Domestic credit"
    postings_1_to_1.loc[postings_1_to_1['domestic'] & (~postings_1_to_1['credit']), 'transaction_type'] = "1 to 1 : Domestic debit"

    #bucket 10
    postings_1_to_1['country_risk'] = postings_1_to_1['PAY_ID'].map(country_risk_mapping)
    postings_1_to_1['LS/MS'] = ~postings_1_to_1['domestic'] & (postings_1_to_1['country_risk'] <= 2)
    postings_1_to_1.loc[postings_1_to_1['credit'] & postings_1_to_1['LS/MS'], 'transaction_type'] = "1 to 1 : Cross-border credits (LS, MS)"

    #bucket 11
    postings_1_to_1.loc[~postings_1_to_1['credit'] & postings_1_to_1['LS/MS'], 'transaction_type'] = "1 to 1 : Cross-border debit (LS, MS)"
    #bucket 12
    postings_1_to_1['HS/VHS/THV'] = ~postings_1_to_1['domestic'] & (postings_1_to_1['country_risk'] > 2)
    postings_1_to_1.loc[postings_1_to_1['HS/VHS/THV'], 'transaction_type'] = "1 to 1 : Cross-border payment (HS/VHS/THV)"

    all_buckets = pd.concat([postings[postings['cash_check']]['transaction_type'], postings_1_to_1['transaction_type'], postings_1_to_0['transaction_type'], postings_1_to_many['transaction_type']])
    assert len(all_buckets) == len_df, (len(all_buckets), len_df)
    return all_buckets


def serialize_input_data(parameters):
    ''' Convert input csv data to new parquet files per business unit
        and type of transaction
    '''
    thresholds = load_parameters(parameters.BU, 'RAW')

    # export transactions files
    if parameters.DATA_SERIALIZATION.TRANSACTIONS_SERIALISATION:
        version = utils.get_version(parameters)
        for transaction_type in ['Postings', 'Payments']:
            dirnames = []
            for year in utils.get_years(parameters):
                dirnames += [os.path.join(
                    constants.READ_ONLY_DATA_PATH,
                    str(year), version, parameters.BU,
                    transaction_type
                )]
            outdir = os.path.join(
                constants.READ_WRITE_DATA_PATH, parameters.BU,
                'processed'
            )
            os.makedirs(outdir, exist_ok=True)
            outname = os.path.join(
                outdir,
                f"CTP_{parameters.BU}_{transaction_type}_RAW.parquet"
            )
            export_to_parquet(dirnames, outname, transaction_type, parameters.BU, thresholds)
    #import sys
    sys.exit(-1)
    adding bucket mapping
    if parameters.MODEL_VERSION=="SAM8":
        mappings = load_mappings(parameters)
        add_bucket_mapping_to_postings(parameters, mappings)
        
    # export alert files
    if parameters.DATA_SERIALIZATION.ALERTS_SERIALISATION:
        inputdirs = []
        for year in utils.get_years(parameters):
            inputdirs += [
                os.path.join(
                    constants.READ_ONLY_DATA_PATH, str(year),
                    'V3',  parameters.BU, "Alerts"
                )
            ]
        outputdir = os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts'
        )
        export_alerts(inputdirs, outputdir, parameters.BU, 'truth')

    # export AML IT alert files
    if parameters.DATA_SERIALIZATION.AMLIT_ALERTS_SERIALISATION:
        inputdirs = []
        for year in utils.get_years(parameters):
            inputdirs += [os.path.join(
                constants.READ_ONLY_DATA_PATH, str(year),
                'V8', parameters.BU,
                f'Alerts_{parameters.DATA_SERIALIZATION.AMLIT_ALERTS_SERIALISATION}'
            )]
        outputdir = os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts'
        )
        export_alerts(
            inputdirs, outputdir, parameters.BU,
            f'{parameters.DATA_SERIALIZATION.AMLIT_ALERTS_SERIALISATION}_AMLIT',
            add_notes=False
        )
        
    if parameters.DATA_SERIALIZATION.LOOKBACK_SUMS:
        compute_lookback_sums(parameters, thresholds)

    if parameters.DATA_SERIALIZATION.ALERTS_SERIALISATION \
    and parameters.DATA_SERIALIZATION.TRANSACTIONS_SERIALISATION:
        check_missing_transactions_for_escalations(parameters)


def check_missing_transactions_for_escalations(parameters):
    ''' Check for missing transactions in SAM8 scoped data collection
        corresponding to escalations to L2+ in production, during TRAIN
        + TEST period, and output these to a dedicated file
    '''
    
    tr_id = {}
    tr_id["Postings"] = pd.read_parquet(os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'processed', f"CTP_{parameters.BU}_Postings_RAW.parquet"
    ), columns=["POS_ID", "AMOUNT_LOCAL_CURR"]).rename(
        columns={"POS_ID": "TRANSACTION_KEY"}
    )
    tr_id["Payments"] = pd.read_parquet(os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'processed', f"CTP_{parameters.BU}_Payments_RAW.parquet"
    ), columns=["PAY_ID", "AMOUNT_LOCAL_CURR"]).rename(
        columns={"PAY_ID": "TRANSACTION_KEY"}
    )
    
    df_missing = []
    df_diff_amounts = []

    for model in set(constants.SAM3_MODELS):
        constants.LOGGER.info(
            f"Check for missing transactions on escalations of model {model}"
        )
        if model not in constants.TRANSACTION_TYPE_PER_MODEL:
            continue
        inputfile = os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU,
            'alerts', f"{model}_{parameters.BU}_truth.parquet"
        )
        alerts = pd.read_parquet(inputfile)
        alerts = alerts[alerts["STEP"].str.contains("L2|L3")]

        alerts["VALUE_DATETIME"] = utils.lookup(alerts["ALERT_DATE"])
        alerts = alerts[
            ((alerts["VALUE_DATETIME"] >= parameters.ANALYSIS_DATES["TRAIN"]["FROM"]) \
            & (alerts["VALUE_DATETIME"] <= parameters.ANALYSIS_DATES["TRAIN"]["TO"])) \
            | ((alerts["VALUE_DATETIME"] >= parameters.ANALYSIS_DATES["TEST"]["FROM"]) \
            & (alerts["VALUE_DATETIME"] <= parameters.ANALYSIS_DATES["TEST"]["TO"]))
        ]
        alerts = alerts.merge(
            tr_id[constants.TRANSACTION_TYPE_PER_MODEL[model]],
            how='left', on='TRANSACTION_KEY'
        )
                
        missing_transactions = alerts["AMOUNT_LOCAL_CURR"].isna()
        df_missing.append(alerts[missing_transactions])
        alerts = alerts[~missing_transactions]
        df_diff_amounts.append(alerts[
            alerts["AMOUNT_LOCAL_CURR"] != alerts["MAIN_CURRENCY_AMT"]
        ])
        
    missing_file_path = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'exports/audit_trail', 'missing_transactions_on_escalations.csv'
    )
    pd.concat(df_missing, axis=0) \
      .to_csv(missing_file_path, sep=';', index=False)
    
    diff_amounts_file_path = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'exports/audit_trail', 'different_amounts_transactions_on_escalations.csv'
    )
    pd.concat(df_diff_amounts, axis=0) \
      .to_csv(diff_amounts_file_path, sep=';', index=False)
    

def filter_transactions_for_clients(
    input_file, output_file,
    clients, client_key="CLIENTNUM"
):
    if os.path.isfile(output_file):
        os.remove(output_file)
    schema = pq.read_schema(input_file)
    out = ParquetStreamer(output_file, schema)
    for chunk in get_transactions_by_chunk(input_file):
        chunk = chunk[
            chunk[client_key].isin(clients)
        ]
        out.write(chunk)
    out.writer.close()
