import os
import json
import copy
import numpy as np
import pandas as pd
import statistics
from tqdm import tqdm

from ..actimize import FlowThroughFunds
from ..utils import constants

from ..utils.utils import filter_transactions, lookup, get_accounts, get_parties
from ..utils.parquet import get_transactions_by_chunk
from ..utils.serialization import load_parameters
from ..utils.kyc import load_kyc


def load_transactions(df):
    ''' Load postings from files and load clients risk levels from
    party table
    '''
    df['CRDS_CODE'] = np.where(pd.isnull(df['CRDS_CODE']), df['CLIENTNUM'], df['CRDS_CODE'])
    df["CRED_OR_DEB"] = df["TRANS_TYPE_CD"].str[0]
    df.drop_duplicates(inplace=True)
    
    return df


def compute_client_stats(postings):
    ''' Build features based on TSD payments
    
    Parameters
    ----------
    payments: pd.Dataframe
        dataframe with monitored payments
        
    Returns
    -------
    pd.Dataframe of payments filled with TSD features
    '''
    crds_groups = postings[
        ['CRDS_CODE', 'POPULATION_GROUP_ID', constants.MAIN_AMNT_KEY, "CRED_OR_DEB", 'VALUE_DATETIME']
    ].groupby('CRDS_CODE').agg(
        TRANSACTIONS=(constants.MAIN_AMNT_KEY, list),
        CRED_OR_DEB=("CRED_OR_DEB", list),
        LAST_TRANSACTION_DATE=('VALUE_DATETIME', 'max'),
    )
    
    return crds_groups.reset_index(drop=False)


def client_stats_agg(data):
    """
    data is a dataframe with one line most of the time, where TRANSACTIONS and LOG_AMOUNT columns are lists
    """
    #these objects are the aggregated lists for each client
    transactions = np.concatenate(data['TRANSACTIONS'].values)
    is_credit = np.concatenate(data['CRED_OR_DEB'].values)

    #removing nans
    to_keep = ~np.isnan(transactions)
    transactions = transactions[to_keep]
    is_credit = is_credit[to_keep]
    
    #adding features
    log_amount = np.log10(transactions + 1e-1)
    is_credit = is_credit == "C"
    cred_amount = transactions[is_credit]
    
    d = {}
    d['NUMBER_TRANSACTIONS'] = len(transactions)
    d['SUM_TRANSACTIONS'] = np.sum(transactions)
    d['MEAN_TRANSACTIONS'] = np.mean(transactions)
    d['MEDIAN_TRANSACTIONS'] = np.median(transactions)
    
    d['MEAN_LOG_TRANSACTIONS'] = np.mean(log_amount)
    d['MEDIAN_LOG_TRANSACTIONS'] = np.median(log_amount)
    d['STD_LOG_TRANSACTIONS'] = np.std(log_amount)
    d['CRED%'] = np.sum(cred_amount) / d['SUM_TRANSACTIONS']
#     d['NUMBER_CRED_TRANSACTIONS'] = len(cred_amount)
#     d['NUMBER_DEB_TRANSACTIONS'] = len(cred_amount)
#     d['MEDIAN_CRED_LOG_TRANSACTIONS'] = np.median(cred_log_amount)
#     d['MEDIAN_DEB_LOG_TRANSACTIONS'] = np.median(deb_log_amount)
    
    d['LAST_TRANSACTION_DATE'] = data['LAST_TRANSACTION_DATE'].max()
    return pd.Series(d).fillna(-1000)
    

def add_client_stats(parameters, features, dates):
    ''' Add client stats features to the features
    Returns
    -------
    pd.Dataframe of features with TSD counts
    '''
    constants.LOGGER.info("Add Client postings stats to features")
    inputfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'processed/CTP_{}_{}_{}.parquet'.format(
            parameters.BU,
            'Postings',
            parameters.CLUSTERING_FEATURES.TRANSACTIONS
        )
    )
    
    client_stats = []
    pop_groups = []
    for chunk in tqdm(get_transactions_by_chunk(inputfile)):
        chunk = filter_transactions(chunk, dates)
        chunk = load_transactions(chunk)
        pop_groups.append(chunk[['CRDS_CODE', 'POPULATION_GROUP_ID', 'CLIENT_FINAL_RISK_SCORE']].drop_duplicates())
        client_stats += [compute_client_stats(chunk)]
    
    pop_groups = pd.concat(pop_groups, axis=0).drop_duplicates().reset_index(drop=True)
    client_stats = pd.concat(client_stats, axis=0)
    client_stats = client_stats.groupby('CRDS_CODE')\
                               .apply(client_stats_agg)\
                               .reset_index(drop=False)\
                               .merge(pop_groups, how='left', on='CRDS_CODE')
    client_stats['MEDIAN_TRANSACTIONS'] = client_stats['MEDIAN_TRANSACTIONS'].astype(int)

    features = features.merge(client_stats, how='left', on='CRDS_CODE')
    features["HAS_TRANSACTIONAL_PROFILE"] = np.where(
        features["CRDS_CODE"].isin(client_stats["CRDS_CODE"]),
        1, 0
    )
    features['LAST_TRANSACTION_BEFORE_PROCESS_DATE'] = np.where(
        features['LAST_TRANSACTION_DATE'] <= features['PROCESS_STATUS_DATE'],
        1, 0
    )
    fill_missing_kyc_segment(features)
    fill_missing_risk_level(features)
    return features


def fill_missing_risk_level(features):
    isna = (features['RISK_LEVEL'].isnull()) & (~features['CLIENT_FINAL_RISK_SCORE'].isna())
    features.loc[isna, 'RISK_LEVEL'] = features[isna]['CLIENT_FINAL_RISK_SCORE']

    
def fill_missing_kyc_segment(features):
    isna = (features['KYC_SEGMENT'].isnull()) & (~features['POPULATION_GROUP_ID'].isna())
    features.loc[isna, 'KYC_SEGMENT'] = features[isna].apply(
        lambda x: 'Commercial Corporates' if x['POPULATION_GROUP_ID'].startswith('C8') \
                else 'Other FI',
        axis=1
    )


def add_kyc(features, kyc_data):
    ''' Inject KYC data
    Parameters
    ----------
    postings: pd.Dataframe
    transactions

    kyc: pd.Dataframe
    dataframe of KYC data
    
    Returns
    -------
    pd.Dataframe of crds codes in transactions with kyc data
    '''
    # Merge KYC data based on CRDS code
    features = pd.merge(features, kyc_data, how='left', on='CRDS_CODE') \
                 .groupby(['CRDS_CODE']).first().reset_index(drop=False)
    
    # Fill missing KYC data
    features['HAS_FSI'] = features['HAS_FSI'].fillna('MISSING_FSI')
    features['ADVERSE_INFO'] = features['ADVERSE_INFO'].fillna('MISSING_ADVERSE_INFO')
    features['COUNTRY_INCORPORATION'] = features['COUNTRY_INCORPORATION'].fillna('MISSING_COUNTRY_INCORPORATION')

    features['RISK_LEVEL'] = np.where(
        features['RISK_LEVEL'].isna(),
        features['RISK_LEVEL_PARTIES'],
        features['RISK_LEVEL']
    )
    features['BNPP_ENTITY'] = np.where(
        features['BNPP_ENTITY'].isna(),
        features['BNPP_ENTITY_PARTIES'],
        features['BNPP_ENTITY']
    )
    
    features['HAS_KYC'] = np.where(
        (features["CRDS_CODE"].isin(kyc_data["CRDS_CODE"])),
        1, 0
    )

    print("BO_Territory", features["BO_TERRITORY"].value_counts())
    print("From reliance", features["FROM_RELIANCE"].value_counts())
    print("Status per type of reliance",
          features.groupby(['FROM_RELIANCE', 'LIFECYCLE_STATUS']).agg({'LIFECYCLE_STATUS': 'count'}))

    return features


def filter_missing_kyc(parameters, features):
    # Filter missing KYC clients which are not BNPP entities
    print("Clients with missing KYC that are BNPP entities", len(features[
       (features["HAS_KYC"] == 0) \
        & (features["BNPP_ENTITY"] == "Y")
    ]))
    print(features[
        features["HAS_TRANSACTIONAL_PROFILE"] == 1
    ][['CRDS_CODE', 'HAS_KYC', 'BNPP_ENTITY', 'HAS_TRANSACTIONAL_PROFILE']])
    print("Clients with missing KYC that are not BNPP entities and have transactions", len(features[
       (features["HAS_KYC"] == 0) \
        & (features["BNPP_ENTITY"] != "Y") \
        & (features['HAS_TRANSACTIONAL_PROFILE'] == 1)
    ]))
    print("CRDS_CODE of clients with missing KYC that are not BNPP entities and have transactions", features[
       (features["HAS_KYC"] == 0) \
        & (features["BNPP_ENTITY"] != "Y") \
        & (features['HAS_TRANSACTIONAL_PROFILE'] == 1)
    ].CRDS_CODE.unique().tolist())
    print("Clients with missing KYC that are not BNPP entities and have L2+ alerts", len(features[
        (features["HAS_KYC"] == 0) \
        & (features["BNPP_ENTITY"] != "Y") \
        & (features['NB_L2+_ALERTS'] != 0)
    ]))
    nbefore = len(features)
    features = features[
        (features["HAS_KYC"] == 1) \
        | (features["BNPP_ENTITY"] == "Y") \
        | (features['NB_L2+_ALERTS'] != 0) \
        | (features['HAS_TRANSACTIONAL_PROFILE'] == 1)
    ]
    print(
        "Remove ", nbefore - len(features),
        " clients with missing KYC that are not BNPP entities, remains",
        len(features)
    )
    parameters.parties_info[constants.FILTER_1][constants.FILTER_2][constants.FILTER_3] = {
        'Remove': nbefore - len(features),
        'Total remaining': len(features),
        'No KYC': {
            'Total remaining': len(features[(features["HAS_KYC"] == 0)]),
            'BNPP entity': {
                'Total remaining': len(features[
                    (features["HAS_KYC"] == 0) \
                    & (features["BNPP_ENTITY"] == "Y")
                ]),
                'Has transactions': len(features[
                    (features["HAS_KYC"] == 0) \
                    & (features["BNPP_ENTITY"] == "Y") \
                    & (features['HAS_TRANSACTIONAL_PROFILE'] == 1)
                ]),
                'No transactions': len(features[
                    (features["HAS_KYC"] == 0) \
                    & (features["BNPP_ENTITY"] == "Y") \
                    & (features['HAS_TRANSACTIONAL_PROFILE'] == 0)
                ])
            },
            'Not BNPP entity': {
                'Total remaining': len(features[
                    (features["HAS_KYC"] == 0) \
                    & (features["BNPP_ENTITY"] != "Y") \
                    & (features['HAS_TRANSACTIONAL_PROFILE'] == 1)
                ]),
                'CRDS codes': features[
                    (features["HAS_KYC"] == 0) \
                    & (features["BNPP_ENTITY"] != "Y") \
                    & (features['HAS_TRANSACTIONAL_PROFILE'] == 1)
                ].CRDS_CODE.tolist()
            }
        }
    }
   
    # Filter terminated or closed clients
    print("Clients with Closed status that have transactions", len(features[
       (features["LIFECYCLE_STATUS"] == "Closed") \
        & (features['HAS_TRANSACTIONAL_PROFILE'] == 1)
    ]['CRDS_CODE']))
    print("Clients with Closed status that have L2+ alerts", len(features[
        (features["LIFECYCLE_STATUS"] == "Closed") \
        & (features['NB_L2+_ALERTS'] != 0)
    ]))
    
    parameters.parties_info[constants.FILTER_1][constants.FILTER_2][constants.FILTER_3]['Has KYC'] = {
        'Total remaining': len(features[(features["HAS_KYC"] == 1)]),
        'From reliance': len(features[
            (features["HAS_KYC"] == 1) \
            & (features['FROM_RELIANCE'] == 1)
        ]),
        'Live': {
            'Total remaining': len(features[
                (features["HAS_KYC"] == 1) \
                & (features["LIFECYCLE_STATUS"] != "Closed")
            ]),
            'Has transactions': len(features[
                (features["HAS_KYC"] == 1) \
                & (features["LIFECYCLE_STATUS"] != "Closed") \
                & (features['HAS_TRANSACTIONAL_PROFILE'] == 1)
            ]),
            'No transactions': len(features[
                (features["HAS_KYC"] == 1) \
                & (features["LIFECYCLE_STATUS"] != "Closed") \
                & (features['HAS_TRANSACTIONAL_PROFILE'] != 1)
            ])
        },
        'Closed': {
            'Total remaining': len(features[
                (features["HAS_KYC"] == 1) \
                & (features["LIFECYCLE_STATUS"] == "Closed")
            ]),
            'No transactions': len(features[
                (features["HAS_KYC"] == 1) \
                & (features["LIFECYCLE_STATUS"] == "Closed") \
                & (features['HAS_TRANSACTIONAL_PROFILE'] != 1)
            ]),
            'Has transactions': {
                'Total remaining': len(features[
                (features["HAS_KYC"] == 1) \
                & (features["LIFECYCLE_STATUS"] == "Closed") \
                & (features['HAS_TRANSACTIONAL_PROFILE'] == 1)
            ]),
                'Has L2+': len(features[
                (features["HAS_KYC"] == 1) \
                & (features["LIFECYCLE_STATUS"] == "Closed") \
                & (features['HAS_TRANSACTIONAL_PROFILE'] == 1) \
                & (features['NB_L2+_ALERTS'] != 0)
            ]),
                'Before closed': {
                    'Total remaining': len(features[
                        (features["HAS_KYC"] == 1) \
                        & (features["LIFECYCLE_STATUS"] == "Closed") \
                        & (features['HAS_TRANSACTIONAL_PROFILE'] == 1) \
                        & (features['LAST_TRANSACTION_BEFORE_PROCESS_DATE'] == 1)
                    ]),
                    'CRDS codes': features[
                        (features["HAS_KYC"] == 1) \
                        & (features["LIFECYCLE_STATUS"] == "Closed") \
                        & (features['HAS_TRANSACTIONAL_PROFILE'] == 1) \
                        & (features['LAST_TRANSACTION_BEFORE_PROCESS_DATE'] == 1)
                    ].CRDS_CODE.tolist()
                },
                'After closed': {
                    'Total remaining': len(features[
                        (features["HAS_KYC"] == 1) \
                        & (features["LIFECYCLE_STATUS"] == "Closed") \
                        & (features['HAS_TRANSACTIONAL_PROFILE'] == 1) \
                        & (features['LAST_TRANSACTION_BEFORE_PROCESS_DATE'] != 1)
                    ]),
                    'CRDS codes': features[
                        (features["HAS_KYC"] == 1) \
                        & (features["LIFECYCLE_STATUS"] == "Closed") \
                        & (features['HAS_TRANSACTIONAL_PROFILE'] == 1) \
                        & (features['LAST_TRANSACTION_BEFORE_PROCESS_DATE'] != 1)
                    ].CRDS_CODE.tolist()
                }
            }
        }
    }
    
    nbefore = len(features)
    features = features[
        (features["LIFECYCLE_STATUS"] != "Closed") \
        | (features['NB_L2+_ALERTS'] != 0)
    ]
    print(
        "Remove ", nbefore - len(features),
        " clients with closed status that don't have L2+ alerts, remains",
        len(features)
    )
   
    return features
                
                
def count_high_risk_country_payments(payments):
    ''' Build features based on TSD payments
    
    Parameters
    ----------
    payments: pd.Dataframe
        dataframe with monitored payments
        
    Returns
    -------
    pd.Dataframe of payments filled with TSD features
    '''
    risked_payments = payments[payments[constants.TSD_COUNTRY_KEY] >= 3]     
    risked_payments = risked_payments[
        ['CRDS_CODE', constants.MAIN_AMNT_KEY]
    ].groupby('CRDS_CODE').agg(  
        NUMBER_TRANSACTIONS_HIGH_RISK=(constants.MAIN_AMNT_KEY, 'count'),
        SUM_TRANSACTIONS_HIGH_RISK=(constants.MAIN_AMNT_KEY, 'sum'),
        MEAN_TRANSACTIONS_HIGH_RISK=(constants.MAIN_AMNT_KEY, 'mean'),
        MEDIAN_TRANSACTIONS_HIGH_RISK=(constants.MAIN_AMNT_KEY, list)
    ).reset_index(drop=False)

    grouped_payments = payments[['CRDS_CODE', constants.MAIN_AMNT_KEY]].groupby('CRDS_CODE').agg(
        NUMBER_PAYMENTS=(constants.MAIN_AMNT_KEY, 'count')
    ).reset_index(drop=False)
    
    grouped_payments = grouped_payments.merge(risked_payments, on='CRDS_CODE', how='left')
    
    for col in [
        'NUMBER_TRANSACTIONS_HIGH_RISK', 'SUM_TRANSACTIONS_HIGH_RISK',
        'MEAN_TRANSACTIONS_HIGH_RISK'
    ]:
        grouped_payments[col] = grouped_payments[col].fillna(0)
    
    grouped_payments['MEDIAN_TRANSACTIONS_HIGH_RISK'] = \
        grouped_payments['MEDIAN_TRANSACTIONS_HIGH_RISK'].fillna("").apply(list)

    return grouped_payments


def tsd_chunk_agg(data):
    d = {}
    d['NUMBER_TRANSACTIONS_HIGH_RISK'] = data['NUMBER_TRANSACTIONS_HIGH_RISK'].sum()
    d['SUM_TRANSACTIONS_HIGH_RISK'] = data['SUM_TRANSACTIONS_HIGH_RISK'].sum()
    d['MEAN_TRANSACTIONS_HIGH_RISK'] = 0 \
        if d['NUMBER_TRANSACTIONS_HIGH_RISK'] == 0 \
        else  np.average(
            data['MEAN_TRANSACTIONS_HIGH_RISK'],
            weights=data['NUMBER_TRANSACTIONS_HIGH_RISK']
        )
    total_list = sum(list(data['MEDIAN_TRANSACTIONS_HIGH_RISK']), [])
    d['MEDIAN_TRANSACTIONS_HIGH_RISK'] = statistics.median(
        total_list
    ) if len(total_list) > 0 \
      else 0
    return pd.Series(d)
    

def load_tsd_counts(parameters, dates):
    '''Load TSD counts from raw payments in business unit
    
    Parameters
    ----------
    parameters object
    
    Return
    ------
    pd.Dataframe with TSD counts per crds codes
    
    '''
    constants.LOGGER.info("Compute TSD counts for features")
    inputfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'processed',
        'CTP_{}_{}_{}.parquet'.format(
            parameters.BU,
            'Payments',
            parameters.CLUSTERING_FEATURES.TRANSACTIONS
        )
    )

    tsd_features = []
    for chunk in tqdm(get_transactions_by_chunk(inputfile)):
        chunk = filter_transactions(chunk, dates)
        tsd_features += [count_high_risk_country_payments(chunk)]
        
    tsd_features = pd.concat(tsd_features, axis=0)
    tsd_features = tsd_features.groupby('CRDS_CODE').apply(tsd_chunk_agg)
    return tsd_features


def add_tsd_counts(features, tsd_counts):
    ''' Add TSD counts to the features
    Parameters
    ----------
    features: pd.Dataframe
    features to which the TSD counts are added
    
    tsd_counts: pd.Dataframe
    all TSD counts per CRDS codes
    
    Returns
    -------
    pd.Dataframe of features with TSD counts
    '''
    constants.LOGGER.info("Add TSD counts to features")
    features = pd.merge(features, tsd_counts, how='left', on='CRDS_CODE')
    for col in [
        'NUMBER_TRANSACTIONS_HIGH_RISK', 'SUM_TRANSACTIONS_HIGH_RISK',
        'MEAN_TRANSACTIONS_HIGH_RISK', 'MEDIAN_TRANSACTIONS_HIGH_RISK'
    ]:
        features[col] = features[col].fillna(0)
        features[col] = features[col].astype(int)
    return features


def load_ftf_counts(parameters, dates):
    ''' Compute all FTF counts from RAW data in the business unit
    Parameters
    ----------
    
    Returns
    -------
    pd.Dataframe of FTF counts for all CRDS codes found in RAW data
    '''
    constants.LOGGER.info("Compute FTF counts for features")

    empty_thresholds = {
        "whitelist": [],
        "user": {},
        "cluster": {},
        "individual": {}
    }

    ftf_model = FlowThroughFunds(
        threshold_mapping=empty_thresholds,
        version=parameters.MODEL_VERSION
    )
    ftf_model.default_np_parameters = np.array([
        0, 1, 1, 90, 110, 0
    ])
    if parameters.CLUSTERING_FEATURES.LOOKBACK_SUMS is not None:
        inputfile = os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU,
            'processed/FTF_lookback_sums_{}_{}.parquet'.format(
                parameters.BU,
                parameters.CLUSTERING_FEATURES.LOOKBACK_SUMS
            )
        )
        lookback_sums = pd.read_parquet(inputfile)
        lookback_sums['POS_ID'] = lookback_sums['POS_ID'].apply(list)
        ftf_model.lookback_sums = lookback_sums

    inputfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'processed/CTP_{}_{}_{}.parquet'.format(
            parameters.BU,
            'Postings',
            parameters.CLUSTERING_FEATURES.TRANSACTIONS
        )
    )

    ftf_counts = []
    for chunk in tqdm(get_transactions_by_chunk(inputfile)):

        chunk = filter_transactions(chunk, dates)
        chunk = chunk.groupby("POS_ID")\
               .first()\
               .reset_index(drop=False)

        ftf_hits = ftf_model(parameters, chunk)
        if ftf_hits.empty:
            continue

        ftf_counts += [
            ftf_hits.groupby(['CRDS_CODE']) \
                    .agg({"FTF_Hit": "count"}) \
                    .reset_index(drop=False)
        ]

    return pd.concat(ftf_counts, axis=0) \
             .groupby(['CRDS_CODE']) \
             .agg(FTF_HITS=("FTF_Hit", sum)) \
             .reset_index(drop=False)


def add_ftf_counts(features, ftf_counts):
    ''' Add FTF counts to the features
    Parameters
    ----------
    features: pd.Dataframe
    features to which the FTF counts are added
    
    ftf_counts: pd.Dataframe
    all FTF counts per CRDS codes
    
    Returns
    -------
    pd.Dataframe of features with FTF counts
    '''
    constants.LOGGER.info("Add FTF counts to features")
    features = pd.merge(features, ftf_counts, how='left', on='CRDS_CODE')
    features['FTF_HITS'] = features['FTF_HITS'].fillna(0)
    features['FTF_HITS'] = features['FTF_HITS'].astype(int)
    return features


def load_alerts(parameters, dates):
    '''Load alerts features from raw alerts in business unit
    
    Return
    ------
    pd.Dataframe with alerts features per crds codes
    '''
    constants.LOGGER.info("Load alerts data for features")
    # Load L2+/L3 alerts statistics
    alerts = []
    for model in parameters.LIST_MODEL:
        alerts += [pd.read_parquet(
            os.path.join(
                constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts', f'{model}_{parameters.BU}_truth.parquet'
            ),
            engine='pyarrow',
            columns=['ALERT_ID', 'CRDS_CODE', 'STEP', 'RULE_ID', 'MAIN_CURRENCY_AMT', 'ALERT_DATE']
        )]
        
    alerts = pd.concat(alerts, axis=0)
    
    alerts['VALUE_DATETIME'] = lookup(alerts['ALERT_DATE'])
    alerts = filter_transactions(alerts, dates)
    
    alerts['RULE_ID'] = alerts['RULE_ID'].map(constants.RULES_MODEL_MAPPING)
    if alerts["MAIN_CURRENCY_AMT"].dtype != 'float64':
        alerts["MAIN_CURRENCY_AMT"] = alerts["MAIN_CURRENCY_AMT"].str.replace(',', '.')
        alerts["MAIN_CURRENCY_AMT"] = alerts["MAIN_CURRENCY_AMT"].astype(float)

    is_escalated = alerts['STEP'].str.contains(
        'L2 - clos|L3 - clos|to Level 2|to Level 3|to L2|to L3'
    )
    alerts2 = alerts[is_escalated]
    alerts1 = alerts[~is_escalated]
    alerts3 = alerts[alerts['STEP'].str.contains('L3 - clos|to Level 3|to L3')]
    list_models2 = list(alerts2['RULE_ID'].unique())
    list_models3 = list(alerts3['RULE_ID'].unique())
    list_models1 = list(alerts1['RULE_ID'].unique())

    alerts2['NB_L2+_HITS'] = alerts2.groupby('CRDS_CODE')['CRDS_CODE'].transform(np.size)
    alerts2['MIN_L2+_AMT'] = alerts2.groupby('CRDS_CODE')["MAIN_CURRENCY_AMT"].transform('min')

    for model in list_models2:
        alerts2[f'NB_{model}_L2+_HITS'] = np.where(alerts2['RULE_ID'] == model, 1, 0)
        alerts2[f'NB_{model}_L2+_HITS'] = alerts2.groupby('CRDS_CODE')[f'NB_{model}_L2+_HITS'].transform('sum')
        alerts2[f'MIN_{model}_L2+_AMT'] = np.where(alerts2['RULE_ID'] == model, alerts2["MAIN_CURRENCY_AMT"], 0)
        alerts2[f'MIN_{model}_L2+_AMT'] = alerts2.groupby(['CRDS_CODE', 'RULE_ID'])[f'MIN_{model}_L2+_AMT'].transform('min')
        alerts2[f'MIN_{model}_L2+_AMT'] = alerts2.groupby('CRDS_CODE')[f'MIN_{model}_L2+_AMT'].transform('max')
        
    alerts2.drop(["MAIN_CURRENCY_AMT"], axis=1, inplace=True)
    alerts2.drop_duplicates(inplace=True)

    alerts2['NB_L2+_ALERTS'] = alerts2.groupby('CRDS_CODE')['CRDS_CODE'].transform(np.size)
    for model in list_models2:
        alerts2[f'NB_{model}_L2+_ALERTS'] = np.where(alerts2['RULE_ID'] == model, 1, 0)
        alerts2[f'NB_{model}_L2+_ALERTS'] = alerts2.groupby('CRDS_CODE')[f'NB_{model}_L2+_ALERTS'].transform('sum')
    alerts2.drop(['STEP', 'ALERT_ID', 'RULE_ID', 'ALERT_DATE', 'VALUE_DATETIME'], axis=1, inplace=True)
    alerts2.drop_duplicates(inplace=True)
    
    if alerts3.shape[0] == 0:
        alerts = alerts2
        alerts['NB_L3_HITS'] = 0
        alerts['NB_L3_ALERTS'] = 0
        alerts['MIN_L3_AMT'] = 0
    else:   
        alerts3['NB_L3_HITS'] = alerts3.groupby('CRDS_CODE')['CRDS_CODE'].transform(np.size)
        alerts3['MIN_L3_AMT'] = alerts3.groupby('CRDS_CODE')["MAIN_CURRENCY_AMT"].transform('min')
        for model in list_models3:
            alerts3[f'NB_{model}_L3_HITS'] = np.where(alerts3['RULE_ID'] == model, 1, 0)
            alerts3[f'NB_{model}_L3_HITS'] = alerts3.groupby('CRDS_CODE')[f'NB_{model}_L3_HITS'].transform('sum')
            alerts3[f'MIN_{model}_L3_AMT'] = np.where(alerts3['RULE_ID'] == model, alerts3['MAIN_CURRENCY_AMT'], 0)
            alerts3[f'MIN_{model}_L3_AMT'] = alerts3.groupby(['CRDS_CODE', 'RULE_ID'])[f'MIN_{model}_L3_AMT'].transform('min')
            alerts3[f'MIN_{model}_L3_AMT'] = alerts3.groupby('CRDS_CODE')[f'MIN_{model}_L3_AMT'].transform('max')
            alerts3[f'MIN_{model}_L3_AMT'] = alerts3[f'MIN_{model}_L3_AMT'].astype(int)

        alerts3.drop(["MAIN_CURRENCY_AMT"], axis=1, inplace=True)
        alerts3.drop_duplicates(inplace=True)
        alerts3['NB_L3_ALERTS'] = alerts3.groupby('CRDS_CODE')['CRDS_CODE'].transform(np.size)
        for model in list_models3:
            alerts3[f'NB_{model}_L3_ALERTS'] = np.where(alerts3['RULE_ID'] == model, 1, 0)
            alerts3[f'NB_{model}_L3_ALERTS'] = alerts3.groupby('CRDS_CODE')[f'NB_{model}_L3_ALERTS'].transform('sum')
        alerts3.drop(['STEP', 'ALERT_ID', 'RULE_ID', 'ALERT_DATE', 'VALUE_DATETIME'], axis=1, inplace=True)
        alerts3.drop_duplicates(inplace=True)

        alerts = pd.merge(alerts2, alerts3, how='left', on='CRDS_CODE')   
    
    for col in ['NB_L2+_HITS', 'NB_L3_HITS', 'MIN_L2+_AMT', 'MIN_L3_AMT', 'NB_L2+_ALERTS', 'NB_L3_ALERTS']:
        alerts[col] = alerts[col].fillna(0)
        alerts[col] = alerts[col].astype(int)
    for model in list_models2:
        for col in [
            f'NB_{model}_L2+_HITS', f'MIN_{model}_L2+_AMT', f'NB_{model}_L2+_ALERTS'
        ]:
            alerts[col] = alerts[col].fillna(0)
            alerts[col] = alerts[col].astype(int)
    for model in list_models3:
        for col in [
            f'NB_{model}_L3_HITS', f'MIN_{model}_L3_AMT', f'NB_{model}_L3_ALERTS'
        ]:
            alerts[col] = alerts[col].fillna(0)
            alerts[col] = alerts[col].astype(int)
     
    return alerts

def filter_whitelisted_crds(parameters, parties):
    if parameters.CLUSTERING_FEATURES.PARAMETERS is None:
        print('No whitelist defined')
        parameters.parties_info[constants.FILTER_1][constants.FILTER_2] = {
            'Remove': 0,
            'Total remaining': len(parties)
        }
        return parties

    accounts = get_accounts(parameters)
    
    thresholds = load_parameters(parameters.BU, parameters.CLUSTERING_FEATURES.PARAMETERS)

    ## Get all the accounts for the CRDS that have whitelisted accounts
    whitelisted_accounts = accounts[
        accounts['ACCOUNT_KEY'].isin(thresholds['whitelist'])
    ]
    accounts_for_whitelisted_crds = accounts[
        accounts['CRDS_CODE'].isin(whitelisted_accounts['CRDS_CODE'].unique())
    ]
    
    ## Get the accounts that are not whitelisted and belong to CRDS that have whitelisted accounts
    not_whitelisted_accounts = accounts_for_whitelisted_crds[
        ~accounts_for_whitelisted_crds['ACCOUNT_KEY'].isin(whitelisted_accounts['ACCOUNT_KEY'])
    ]
    
    ## Finally get the list of CRDS codes that have only whitelisted accounts
    final_whitelisted_crds = whitelisted_accounts[
        ~whitelisted_accounts['CRDS_CODE'].isin(not_whitelisted_accounts['CRDS_CODE'])
    ]['CRDS_CODE'].unique()
    
    nbefore = len(parties)
    parties = parties[
        ~parties['CRDS_CODE'].isin(final_whitelisted_crds)
    ]
    print('Remove ', nbefore - len(parties), ' fully whitelisted crds codes, remains', len(parties))
    parameters.parties_info[constants.FILTER_1][constants.FILTER_2] = {
        'Remove': nbefore - len(parties),
        'Total remaining': len(parties)
    }
    return parties


def load_valid_crds(parameters):
    parties = get_parties(parameters)

    print('Initial number of parties is', len(parties))
    parameters.parties_info['Initial number of parties is'] = len(parties)
    
    nbefore = len(parties)
    parties = parties[
        ~parties['CLI_LIBELLE_CATEGORIE_CLIENTEL'].isin([
            'PRIVATE PERSON', 'BANK STAFF'
        ]) \
        & (parties['CRDS_CODE'].str.len().isin([7, 12])) \
        & (~parties['CRDS_CODE'].isna())
    ].groupby('CRDS_CODE').first().reset_index(drop=False)

    print(
        'Remove ', nbefore - len(parties),
        ' invalid CRDS codes, private persons and bank staff, remains', len(parties)
    )
    parameters.parties_info[constants.FILTER_1] = {
        'Remove': nbefore - len(parties),
        'Total remaining': len(parties)
    }
    parties['RISK_LEVEL_PARTIES'] = parties['RISK_LEVEL'].map({0: '0-LOW', 1: '1-MEDIUM', 2: '2-HIGH'})
    parties = parties.drop('RISK_LEVEL', axis=1).rename(columns={"BNPP_ENTITY": "BNPP_ENTITY_PARTIES"})

    parties = filter_whitelisted_crds(parameters, parties)
    return parties

def add_alerts(parameters, features, alerts):
    ''' Add client stats features to the features
    Parameters
    ----------
    features: pd.Dataframe
    features to which the alerts counts are added
    alerts: pd.Dataframe
    alerts features per CRDS codes

    Returns
    -------
    pd.Dataframe of features with alerts counts
    '''
    constants.LOGGER.info("Add alerts data to features")
    features = pd.merge(features, alerts, how='left', on='CRDS_CODE')
    for col in ['NB_L2+_HITS', 'NB_L3_HITS', 'MIN_L2+_AMT', 'MIN_L3_AMT', 'NB_L2+_ALERTS', 'NB_L3_ALERTS']:
        features[col] = features[col].fillna(0)
        features[col] = features[col].astype(int)
    list_model = copy.deepcopy(parameters.LIST_MODEL)
    if 'TSD' in list_model:
        list_model += ['TSD3', 'TSD4', 'THV']
    for model in list_model:
        for col in [
            f'NB_{model}_L2+_HITS', f'MIN_{model}_L2+_AMT', f'NB_{model}_L2+_ALERTS',
            f'NB_{model}_L3_HITS', f'MIN_{model}_L3_AMT', f'NB_{model}_L3_ALERTS'
        ]:
            if col in features.columns:
                features[col] = features[col].fillna(0)
                features[col] = features[col].astype(int)
    return features


def compute_features(parameters, features, dates):
    alerts = load_alerts(parameters, dates)
    tsd_counts = load_tsd_counts(parameters, dates)
    ftf_counts = load_ftf_counts(parameters, dates)
    
    features = add_client_stats(parameters, features, dates)
    features = add_alerts(parameters, features, alerts)
    features = add_ftf_counts(features, ftf_counts)
    features = add_tsd_counts(features, tsd_counts)
    features = filter_missing_kyc(parameters, features)
    
    return features


def model_features(parameters):
    ''' Build features file'''
    parameters.parties_info = {}
    os.makedirs(os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'features'
    ), exist_ok=True)
    
    os.makedirs(os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'clusters_files'
    ), exist_ok=True)
    
    kyc_data = load_kyc(parameters.BU)
    base_features = load_valid_crds(parameters)
    base_features = add_kyc(base_features, kyc_data)    
    
    # Build features during train period
    features = compute_features(parameters, base_features, parameters.ANALYSIS_DATES['CLUSTERING_TRAIN'])
    outputfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'features',
        f'{parameters.BU}_clustering_features_train_{parameters.EXPERIMENT_KEY}.csv'
    )
    features.to_csv(outputfile, index=False, sep=';')
    
    parties_info_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'clusters_files',
        'parties_info.txt'
    )
    with open(parties_info_file, 'w') as f:
            f.write(json.dumps(parameters.parties_info, indent=4))
    
    # Build features during test period
    features = compute_features(parameters, base_features, parameters.ANALYSIS_DATES['CLUSTERING_TEST'])
    outputfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'features',
        f'{parameters.BU}_clustering_features_test_{parameters.EXPERIMENT_KEY}.csv'
    )
    features.to_csv(outputfile, index=False, sep=';')
