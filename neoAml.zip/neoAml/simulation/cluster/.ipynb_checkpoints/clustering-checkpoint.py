import os
import json
import pandas as pd
import numpy as np
import gower

from scipy.spatial.distance import pdist
from sklearn.cluster import AgglomerativeClustering
from sklearn.mixture import GaussianMixture

from ..utils import constants
from ..utils.utils import get_parties, filter_transactions

SEED = 42


def impute_missing_cat(df):
    df['BNPP_ENTITY'] = df['BNPP_ENTITY'].fillna('N')
    df['BNPP_ENTITY'] = df['BNPP_ENTITY'].map({'N': 'NOT_BNPP_ENTITY', 'Y': 'BNPP_ENTITY'})
    df['KYC_SEGMENT'] = np.where(
        df['KYC_SEGMENT'] == 'MISSING_KYC_SEGMENT',
        'Commercial Corporates', df['KYC_SEGMENT']
    )
    df['ADVERSE_INFO'] = np.where(
        df['ADVERSE_INFO'] == 'MISSING_ADVERSE_INFO',
        'No', df['ADVERSE_INFO']
    )
    df['COUNTRY_INCORPORATION'] = np.where(
        df['COUNTRY_INCORPORATION'] == 'MISSING_COUNTRY_INCORPORATION',
        'LS', df['COUNTRY_INCORPORATION']
    )
    df['RISK_SCORE'] = df['RISK_SCORE'].fillna(df['RISK_SCORE'].median())
    
    return df


def convert_categorical_features(df):
    risk_country_mapping = {'LS': 0, 'MS': 1, 'HS': 2, 'VHS': 4, 'THV': 4}
    adverse_info_mapping = {'No': 0, 'Immaterial': 0, 'Material': 4}
    df['COUNTRY_INCORPORATION'] = df['COUNTRY_INCORPORATION'].map(risk_country_mapping)
    df['ADVERSE_INFO'] = df['ADVERSE_INFO'].map(adverse_info_mapping)
    
    #df['RISK_SCORE'] = df['RISK_SCORE'] + df['COUNTRY_INCORPORATION'] + df['ADVERSE_INFO']
    # df['RISK_SCORE'] = df['RISK_SCORE'] + df['COUNTRY_INCORPORATION']
    
    #df.drop(['COUNTRY_INCORPORATION', 'ADVERSE_INFO'], axis=1, inplace=True)

    return df

    
def group_kyc_segments(df):
    df['KYC_SEGMENT'] = np.where(
        df['KYC_SEGMENT'] == 'Commercial Corporates',
        'COMMERCIAL_CORP',
        df['KYC_SEGMENT']
    )
    df['KYC_SEGMENT'] = np.where(
        df['KYC_SEGMENT'].isin(
            ['Other FI', 'Banks', 'Insurance companies', 'Funds and management companies']
        ), 'FINANCIAL_INST', df['KYC_SEGMENT']
    )
    df['KYC_SEGMENT'] = np.where(
        df['KYC_SEGMENT'].isin(
            ['COMMERCIAL_CORP', 'FINANCIAL_INST', 'MISSING_KYC_SEGMENT']
        ), df['KYC_SEGMENT'], 'OTHER'
    )
    
    return df


def add_log_features(df):
    df['LOG_NUMBER_TRANSACTIONS'] = np.log10(df['NUMBER_TRANSACTIONS'] + 1e-1)
    df['LOG_NUMBER_TRANSACTIONS_HIGH_RISK'] = np.log10(df['NUMBER_TRANSACTIONS_HIGH_RISK'] + 1e-1)
    df['LOG_MEAN_TRANSACTIONS_HIGH_RISK'] = np.log10(df['MEAN_TRANSACTIONS_HIGH_RISK'] + 1e-1)
    df['LOG_MEDIAN_TRANSACTIONS_HIGH_RISK'] = np.log10(df['MEDIAN_TRANSACTIONS_HIGH_RISK'] + 1e-1)
    df['LOG_FTF_HITS'] = np.log10(df['FTF_HITS'] + 1e-1)
    #df['LOG_FTF_MEAN_AMOUNT'] = np.log10(df['FTF_MEAN_AMOUNT'] + 1e-1)
    df['LOG_RISK_SCORE'] = np.log10(df['RISK_SCORE'] + 1e-1).fillna(0.0)

    return df


def filter_missing_kyc(parameters, features, key):
    no_kyc = (features['ADVERSE_INFO'] == 'MISSING_ADVERSE_INFO') \
        & (features['COUNTRY_INCORPORATION'] == 'MISSING_COUNTRY_INCORPORATION') \
        & (features['RISK_SCORE'].isna())
    
    terminated_kyc = (features['KYC_STATUS'] == 'Terminated')
    
    features[no_kyc].to_csv(os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
            'features', f'{parameters.BU}_missing_kyc_{key}_{parameters.CLUSTERING.FEATURES}.csv'
        ), sep=';', index=False
    )
    
    features[terminated_kyc].to_csv(os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
            'features', f'{parameters.BU}_terminated_kyc_{key}_{parameters.CLUSTERING.FEATURES}.csv'
        ), sep=';', index=False
    )

    return features #[~no_kyc]


def prepare_clustering_features(parameters, key):
    df = pd.read_csv(
        os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU,
            'features', f'{parameters.BU}_clustering_features_{key}_{parameters.CLUSTERING.FEATURES}.csv'
        ), sep=';'
    )
    if "CLIENT_NAME" in df.columns:
        df.drop('CLIENT_NAME', axis=1, inplace=True)
    df['RISK_SCORE'] = df['RISK_SCORE'].astype(float)
    df = filter_missing_kyc(parameters, df, key)
    df = impute_missing_cat(df)
    df = convert_categorical_features(df)
    df = group_kyc_segments(df)
    df = add_log_features(df)

    return df

    
def find_split_cluster_id(val, cluster, sep, idx_begin):
    for sep_val in sep:
        if val < sep_val:
            return idx_begin
        idx_begin += 1
    return idx_begin
    
    
def divide_cluster(df, cluster, sep, col='MEDIAN_LOG_TRANSACTIONS'):    
    to_increment = df[df['CLUSTER'] > cluster]
    to_increment['CLUSTER'] = to_increment['CLUSTER'] + len(sep)
    df.loc[df['CLUSTER'] > cluster, 'CLUSTER'] = to_increment['CLUSTER']
    
    new_cluster = df[df['CLUSTER'] == cluster].apply(
        lambda x: find_split_cluster_id(
            x[col],
            x['CLUSTER'],
            sep,
            cluster
        ), axis=1
    )
    df.loc[df['CLUSTER'] == cluster, 'CLUSTER'] = new_cluster    

    
def affect_to_cluster(cluster_dict, client_features):
    min_linkage = None
    for label, cluster in cluster_dict.items():
        cluster[-1] = client_features
        tmp_linkage = np.max(pdist(cluster))
        if min_linkage is None or tmp_linkage < min_linkage:
            min_linkage = tmp_linkage
            arg_label = label
    return arg_label


def build_clustering_dict(clustering, X_train):
    cluster_dict = {}
    for label in np.unique(clustering.labels_):
        idx = (clustering.labels_ == label)
        cluster_dict[label] = np.zeros((idx.sum() + 1, X_train.shape[1]))
        cluster_dict[label][:idx.sum()] = X_train[idx]
    return cluster_dict


def apply_clustering(df_train, df_test, nb_clusters, compute_gower=True, linkage='ward'):
    if compute_gower:
        for col in df_train.columns:
            df_train[col] = df_train[col].fillna(0)
            df_test[col] = df_test[col].fillna(0)
        X_train = gower.gower_matrix(df_train)
        if df_test is not None:
            X_test = gower.gower_matrix(df_test)
    else:
        X_train = np.array(df_train)
        if df_test is not None:
            X_test = np.array(df_test)

    X_train[np.isnan(X_train)] = 0
    clustering = AgglomerativeClustering(
        linkage=linkage, n_clusters=nb_clusters, compute_distances=True
    ).fit(X_train)          
           
    clustering = AgglomerativeClustering(
        linkage=linkage, n_clusters=nb_clusters, compute_distances=True
    ).fit(X_train)
    
    test_labels = None
    if df_test is not None:
        cluster_dict = build_clustering_dict(clustering, X_train)
    
        test_labels = np.zeros(X_test.shape[0])
        for i in range(X_test.shape[0]):
            test_labels[i] = affect_to_cluster(cluster_dict, X_test[i])
    
    return clustering, test_labels


def create_cluster_mapping(df):
    dt = df[['CRDS_CODE', 'CLUSTER']]
    dt.drop_duplicates(inplace=True)
    cluster_mapping = dict(zip(dt['CRDS_CODE'], dt['CLUSTER']))
    return cluster_mapping


def agg_kyc_status(x):
    #TODO can be optimized with (x.values != "Terminated").index(False)
    l = list(x)
    if 'Terminated' in l:
        for status in l:
            if status != "Terminated":
                return status
    return l[0]


def upload_clusters(parameters, df, key):
    cluster_mapping = create_cluster_mapping(df)
    clusters = get_parties(parameters)
    clusters = clusters[~clusters['CRDS_CODE'].isna()]
    clusters['CLUSTER_ID'] = clusters['CRDS_CODE'].map(cluster_mapping)
    clusters = clusters[~clusters['CLUSTER_ID'].isna()]
    clusters['CLUSTER_ID'] = clusters['CLUSTER_ID'].astype(int)
    
    # Update risk level from parties with risk level in features (kyc based)
    # which are more up to date
    clusters = clusters.rename(columns={
        constants.FEATURES_RISK_KEY: "RISK_LEVEL_PARTY"
    })
    clusters = clusters.merge(
        df[["CRDS_CODE", constants.FEATURES_RISK_KEY]],
        on=["CRDS_CODE"], how="left"
    )
    clusters[constants.FEATURES_RISK_KEY] = np.where(
        clusters[constants.FEATURES_RISK_KEY].isna(),
        clusters["RISK_LEVEL_PARTY"],
        clusters[constants.FEATURES_RISK_KEY].map(
            constants.INVERT_RISK_LEVEL_MAPPING
        )
    )

    os.makedirs(
        os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU, 'Clusters'
        ),
        exist_ok=True
    )
    clusters.to_csv(
        os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU, 'Clusters',
            f'{parameters.BU}_SAM8_Cluster_Mapping_{key}.csv'
        ),
        sep=';', index=False
    )


def load_transactions(parameters, transaction_type, columns):
    ''' Load postings from files and load clients risk levels from
    party table
    '''
    file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'processed',
        f'CTP_{parameters.BU}_{transaction_type}_RAW.parquet'
    )

    if constants.TRANS_DATE_KEY not in columns:
        columns = columns + [constants.TRANS_DATE_KEY]

    df = pd.read_parquet(file, columns=columns)

    if ('CRDS_CODE' in columns) and ('CLIENTNUM' in columns):
        df['CRDS_CODE'] = np.where(
            pd.isnull(df['CRDS_CODE']), df['CLIENTNUM'], df['CRDS_CODE']
        )
    df = filter_transactions(df, parameters.ANALYSIS_DATES["CLUSTERING_TRAIN"])

    if constants.MAIN_AMNT_KEY in columns:
        df['LOG_AMOUNT'] = np.log10(df[constants.MAIN_AMNT_KEY] + 1e-1)
        
    df.drop_duplicates(inplace=True)
    
    return df


def load_clusters(BU, run):
    input_cluster = os.path.join(
        constants.READ_WRITE_DATA_PATH, BU, 'Clusters',
        f'{BU}_SAM8_Cluster_Mapping_{run}.csv'
    )
    try:
        clusters = pd.read_csv(input_cluster, sep=';')
    except UnicodeDecodeError:
        clusters = pd.read_csv(input_cluster, sep=';', encoding='latin-1')
    
    return clusters


def load_outliers(parameters):
    if parameters.CLUSTERING.OUTLIERS is None:
        return None
    clusters = load_clusters(parameters.BU, parameters.CLUSTERING.OUTLIERS)
    outliers = clusters[clusters['CLUSTER_ID'] == 0]
    
    postings_columns = ['CRDS_CODE', 'CLIENTNUM']
    postings = load_transactions(parameters, 'Postings', postings_columns)
    postings['CRDS_CODE'] = np.where(pd.isnull(postings['CRDS_CODE']), postings['CLIENTNUM'], postings['CRDS_CODE'])
    postings.drop_duplicates(inplace=True)
    crds_mapping = dict(zip(postings['CLIENTNUM'], postings['CRDS_CODE']))
    
    outliers['CRDS_CODE'] = outliers['CLIENT_KEY'].map(crds_mapping)
    
    return list(outliers['CRDS_CODE'].unique())


def get_outliers_in_features(outliers, features):
    is_outlier = features['CRDS_CODE'].isin(outliers)
    df_outliers = features[is_outlier]
    df_outliers['CLUSTER'] = 0
    features = features[~is_outlier]
    return df_outliers, features


def get_bnpp_entities_in_features(features):
    is_bnpp_entity = (features['BNPP_ENTITY'] == 'BNPP_ENTITY')
    return features[is_bnpp_entity], features[~is_bnpp_entity]


def get_non_corporates_in_features(features):
    is_non_corporate = (features['KYC_SEGMENT'] == 'OTHER') \
        | (features['KYC_SEGMENT'] == 'FINANCIAL_INST')
    return features[is_non_corporate], features[~is_non_corporate]


def get_segment_high_risk(features, icluster):
    df_segment_high = features[
        features[constants.FEATURES_RISK_KEY] == '2-HIGH'
    ]
    if not df_segment_high.empty:
        df_segment_high['CLUSTER'] = icluster
    return df_segment_high


def get_segment_low_medium_risk(features, icluster):
    df_segment_low = features[
        features[constants.FEATURES_RISK_KEY] != '2-HIGH'
    ]
    if not df_segment_low.empty:
        df_segment_low['CLUSTER'] = icluster
    return df_segment_low


def isolate_inactive_clients(features_train, features_test):
    train_has_trans_profile = (features_train['HAS_TRANSACTIONAL_PROFILE'] == 1)
    test_has_trans_profile = (features_test['HAS_TRANSACTIONAL_PROFILE'] == 1)
    df_out = features_train[~train_has_trans_profile]
    features_train = features_train[train_has_trans_profile]
    features_test = features_test[test_has_trans_profile]
    df_out = df_out[
        ~df_out['CRDS_CODE'].isin(features_test["CRDS_CODE"])
    ]
    df_out['CLUSTER'] = 0
    return df_out, features_train, features_test


def cluster(parameters):
    features_train = prepare_clustering_features(parameters, 'train')
    features_test = prepare_clustering_features(parameters, 'test')
    
    outliers = load_outliers(parameters)        
    if outliers is None:
        constants.LOGGER.info("No outliers defined for clustering")
        df_outliers_train, features_train, features_test = isolate_inactive_clients(
            features_train, features_test
        )
        # Never active clients are not to be put in cluster 0
        df_outliers_test = pd.DataFrame({})
    else:
        df_outliers_train, features_train = get_outliers_in_features(outliers, features_train)
        df_outliers_test, features_test = get_outliers_in_features(outliers, features_test)

    features_test = features_test[
        (~features_test['CRDS_CODE'].isin(features_train['CRDS_CODE'])) \
    ]
    print("Cluster 0 / For fine-tuning / to addfrom test:", len(df_outliers_train), len(features_train), len(features_test))
    
    parties_info_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'clusters_files',
        'parties_info.txt'
    )
    with open(parties_info_file) as f:
        parties_info = json.load(f)
    parties_info[constants.FILTER_1][constants.FILTER_2][constants.FILTER_3]['Used for clustering'] = {
        'Total remaining': len(df_outliers_train) + len(features_train) + len(features_test),
        'Cluster 0': len(df_outliers_train),
        'Clusters 4+': {
            'Total remaining': len(features_train) + len(features_test),
            'From fine-tuning': len(features_train),
            'From test': len(features_test)
        }
    }
    with open(parties_info_file, 'w') as f:
            f.write(json.dumps(parties_info, indent=4))

    icluster = 4

    # Clusters for BNPP entities
    df_bnpp_entities_train, features_train = get_bnpp_entities_in_features(features_train)
    df_bnpp_entities_test, features_test = get_bnpp_entities_in_features(features_test)
    
    df_bnpp_entities_high_train = get_segment_high_risk(df_bnpp_entities_train, icluster)
    df_bnpp_entities_high_test = get_segment_high_risk(df_bnpp_entities_test, icluster)
    if len(df_bnpp_entities_high_train) > 0 or len(df_bnpp_entities_high_test) > 0:
        icluster += 1
        
    df_bnpp_entities_low_train = get_segment_low_medium_risk(df_bnpp_entities_train, icluster)
    df_bnpp_entities_low_test = get_segment_low_medium_risk(df_bnpp_entities_test, icluster)
    if len(df_bnpp_entities_low_train) > 0 or len(df_bnpp_entities_low_test) > 0:
        icluster += 1

    # Clusters for others and FI, high and lower risks
    df_other_train, features_train = get_non_corporates_in_features(features_train)
    df_other_test, features_test = get_non_corporates_in_features(features_test)
    
    df_other_high_train = get_segment_high_risk(df_other_train, icluster)
    df_other_high_test = get_segment_high_risk(df_other_test, icluster)
    if len(df_other_high_train) > 0 or len(df_other_high_test) > 0:
        icluster += 1
        
    df_other_low_train = get_segment_low_medium_risk(df_other_train, icluster)
    df_other_low_test = get_segment_low_medium_risk(df_other_test, icluster)
    if len(df_other_low_train) > 0 or len(df_other_low_test) > 0:
        icluster += 1

    tab_df_train = [
        df_bnpp_entities_high_train, df_bnpp_entities_low_train,
        df_other_high_train, df_other_low_train, df_outliers_train
    ]
    tab_df_test = [
        df_bnpp_entities_high_test, df_bnpp_entities_low_test,
        df_other_high_test, df_other_low_test, df_outliers_test
    ]

    # Clusters for corporates
    risk_df_train = {}
    risk_df_test = {}
    feature_cols = ["MEDIAN_LOG_TRANSACTIONS"]
    for risk in ['0-LOW', '1-MEDIUM', '2-HIGH']:
        risk_df_train[risk] = features_train[
            features_train[constants.FEATURES_RISK_KEY] == risk
        ]
    
        gmm = GaussianMixture(
            parameters.GMM_COMPONENTS_RISK_LEVEL[risk], random_state=SEED
        )
        risk_df_train[risk]['sub_cluster'] = gmm.fit_predict(
            risk_df_train[risk][feature_cols]
        )
        risk_df_test[risk] = features_test[
            features_test[constants.FEATURES_RISK_KEY] == risk
        ]
        if len(risk_df_test[risk]) > 0:
            risk_df_test[risk]['sub_cluster'] = gmm.predict(
                risk_df_test[risk][feature_cols]
            )
            
        for i in risk_df_train[risk]['sub_cluster'].unique():
            sub_risk_df_train = risk_df_train[risk][
                risk_df_train[risk]['sub_cluster'] == i
            ]
            
            sub_risk_df_test_columns = None
            sub_risk_df_test = None
            if len(risk_df_test[risk]) > 0:
                sub_risk_df_test = risk_df_test[risk][
                    risk_df_test[risk]['sub_cluster'] == i
                ]
                sub_risk_df_test_columns = sub_risk_df_test[constants.CLUSTERING_COLUMNS]
            
            nclusters = min(parameters.CLUSTERS_NUMBER_RISK_LEVEL[risk], len(sub_risk_df_train))
            if nclusters == 1:
                sub_risk_df_train['CLUSTER'] = 0
                if sub_risk_df_test is not None:
                    sub_risk_df_test['CLUSTER'] = 0
            else:
                clustering, test_labels = apply_clustering(
                    sub_risk_df_train[constants.CLUSTERING_COLUMNS],
                    sub_risk_df_test_columns,
                    nb_clusters=nclusters,
                    compute_gower=False,
                    linkage='complete'
                )
                sub_risk_df_train['CLUSTER'] = list(clustering.labels_)
                if sub_risk_df_test is not None:
                    sub_risk_df_test['CLUSTER'] = list(test_labels)
            
            sub_risk_df_train['CLUSTER'] += icluster
            if sub_risk_df_test is not None:
                sub_risk_df_test['CLUSTER'] += icluster

            icluster += nclusters
            tab_df_train += [sub_risk_df_train]
            if sub_risk_df_test is not None:
                tab_df_test += [sub_risk_df_test]
            
    upload_clusters(
        parameters, 
        pd.concat(tab_df_train + tab_df_test, axis=0), parameters.EXPERIMENT_KEY
    )


    
