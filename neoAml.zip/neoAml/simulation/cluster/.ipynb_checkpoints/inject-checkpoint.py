import os
import numpy as np
import pandas as pd
import pyarrow
import pyarrow.parquet as pq
from tqdm import tqdm

from ..utils import constants
from ..utils.utils import get_kyc_risk_mapping
from ..utils.parquet import get_transactions_by_chunk, ParquetStreamer, get_cluster_mapping
from ..utils.serialization import load_parameters

                
def inject_clustering(parameters):
    cluster_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'Clusters',
        '{}_SAM8_Cluster_Mapping_{}.csv'.format(parameters.BU, parameters.CLUSTERING.CLUSTERS)
    )
    cluster_mapping = get_cluster_mapping(cluster_file)
    risk_mapping = get_kyc_risk_mapping(parameters)
    thresholds = load_parameters(parameters.BU, "RAW")
    
    to_inject = ['Postings', 'Payments']
    if parameters.CLUSTERING.LOOKBACK_SUMS is not None:
        to_inject += ['FTF_lookback_sums']
    
    for transaction_type in to_inject:
        indir = os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU, 'processed'
        )
        if transaction_type == 'FTF_lookback_sums':
            inname = os.path.join(
                indir,
                f'{transaction_type}_{parameters.BU}_{parameters.CLUSTERING.LOOKBACK_SUMS}.parquet'
            )
            outname = os.path.join(
                indir,
                f'{transaction_type}_{parameters.BU}_{parameters.EXPERIMENT_KEY}.parquet'
            )
        else:
            inname = os.path.join(
                indir,
                'CTP_{}_{}_{}.parquet'.format(
                    parameters.BU, transaction_type, parameters.CLUSTERING.TRANSACTIONS
                )
            )
            outname = os.path.join(
                indir,
                'CTP_{}_{}_{}.parquet'.format(
                    parameters.BU, transaction_type, parameters.EXPERIMENT_KEY
                )
            )

        schema = pq.read_schema(inname)
        if constants.CLUSTER_KEY not in schema.names:
            schema = schema.append(pyarrow.field(constants.CLUSTER_KEY, pyarrow.string()))
        
        constants.LOGGER.info('Inject clusters from {} to {}'.format(
            cluster_file,
            inname
        ))       

        if os.path.isfile(outname):
            os.remove(outname)
        outstream = ParquetStreamer(outname, schema)
        
        for chunk in tqdm(get_transactions_by_chunk(inname)):
            # filter whitelist accounts for EFT model
            if transaction_type == 'Postings':
                chunk = chunk[~chunk['ACCOUNT_KEY'].isin(thresholds['model_whitelist']['EFT'])]\
                .reset_index(drop=True)
                
            chunk[constants.RISK_SCORE_KEY] = \
            chunk["CLIENTNUM"].map(risk_mapping)\
                              .fillna(chunk[constants.RISK_SCORE_KEY])
                
            chunk[constants.CLUSTER_KEY] = chunk['CLIENTNUM'].map(cluster_mapping)
            chunk[constants.CLUSTER_KEY] = np.where(
                (pd.isnull(chunk[constants.CLUSTER_KEY])) \
                    & (chunk[constants.RISK_SCORE_KEY] == '0-LOW'),
                1, chunk[constants.CLUSTER_KEY]
            )
            chunk[constants.CLUSTER_KEY] = np.where(
                (pd.isnull(chunk[constants.CLUSTER_KEY])) \
                    & (chunk[constants.RISK_SCORE_KEY] == '1-MEDIUM'),
                2, chunk[constants.CLUSTER_KEY]
            )
            chunk[constants.CLUSTER_KEY] = np.where(
                (pd.isnull(chunk[constants.CLUSTER_KEY])) \
                    & (chunk[constants.RISK_SCORE_KEY] == '2-HIGH'),
                3, chunk[constants.CLUSTER_KEY]
            )
            chunk[constants.CLUSTER_KEY] = chunk[constants.CLUSTER_KEY].astype(int).astype(str)
        
            outstream.write(chunk)
            
        outstream.writer.close()
