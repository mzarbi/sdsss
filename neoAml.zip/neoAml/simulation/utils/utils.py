import os
import pandas as pd
import shutil
from collections.abc import Mapping

from ..utils import constants


def get_years(parameters):
    if "DATA" in parameters.ANALYSIS_DATES:
        if "FROM" in parameters.ANALYSIS_DATES['DATA'] \
            and "TO" in parameters.ANALYSIS_DATES['DATA']:
            return range(
                int(parameters.ANALYSIS_DATES['DATA']['FROM'][:4]),
                1 + int(parameters.ANALYSIS_DATES['DATA']['TO'][:4])
            )
    constants.LOGGER.info('No dates specified for "DATA" keyword')
    return []


def get_DATA_PATH_LAST_YEAR(parameters):
    LAST_YEAR = get_years(parameters)[-1]
    return os.path.join(
        constants.READ_ONLY_DATA_PATH, str(LAST_YEAR), 'V8'
    )

def get_version(parameters):
    if parameters.MODEL_VERSION == 'SAM8':
        return "V8"
    else:
        return "V3"

def sniff_csv_separator(line):
    max = 0
    argmax = ''
    for sep in [',', ';']:
        n = len(line.split(sep))
        if n > max:
            max = n
            argmax = sep
    return argmax


def update(d, u):
    ''' Utility function to update a dictionary with items from a second one
    
    Parameters
    ----------
    d: dict
        Base dictionary to update
    u: dict
        Dictionary whose values are used to update
        
    Returns
    -------
    dict updated
    '''
    if d is None:
        return u
    for k, v in u.items():
        if isinstance(v, Mapping):
            d[k] = update(d.get(k, {}), v)
        else:
            d[k] = v
    return d


def update_min(d, u):
    if d is None:
        return u
    for k, v in u.items():
        if isinstance(v, Mapping):
            d[k] = update_min(d.get(k, {}), v)
        else:
            d[k] = min(v, d.get(k, v))
    return d


def build_column_mapping(col_mapping, list_cols):
    rename = {}
    for target_col, cols in col_mapping.items():
        if target_col in list_cols:
            continue
        for col in cols:
            if col in list_cols:
                rename[col] = target_col
    return rename


def get_date_format(date_example):
    if len(date_example) == 8 and (date_example[:3] == '202' or date_example[:3] == '201'):
        date_format = '%Y%m%d'
    elif len(date_example) == 9 and date_example.count('-') == 2:
            if date_example[:3] == '202':
                date_format = '%Y-%m-%d'
            else:
                date_format = '%d-%b-%y'
    elif len(date_example) == 10 and date_example.count('/') == 2:
        date_format = '%d/%m/%Y'
    elif len(date_example) == 17:
        date_format = "%Y%m%d %H:%M:%S"
    elif len(date_example) == 19 \
         and (date_example.startswith('202') or date_example.startswith('201')):
        date_format = '%Y-%m-%d %H:%M:%S'
    elif len(date_example) > 19:
        date_format = '%d-%b-%y %H.%M.%S.%f %p'
    else:
        raise Exception(f'No correct date format guessed for {date_example}')
    return date_format


def lookup(s, date_format=None):
    ''' This is an extremely fast approach to datetime parsing.
    For large data, the same dates are often repeated. Rather than
    re-parse these, we store all unique dates, parse them, and
    use a lookup to convert all dates.
    
    Parameters
    ----------
    s: pandas series of str
        Dates data to parse into datetime type
    date_format: str
        Input format of the dates data (e.g. '20200101' has the format
        '%Y%m%d' or '01-JAN-2020' has the format '%d-%b-%y')
        
    Returns
    -------
    dates: pandas series of datetimes
        Dates parsed into datetimes
    '''
    if len(s) == 0:
        return s
    if date_format == None:
        date_example = str(s.values[0])
        date_format = get_date_format(date_example)

    convert_to_dates = {date: pd.to_datetime(date, format=date_format)
                        for date in s.unique()}
    dates = s.map(convert_to_dates)

    return dates

                
def filter_transactions(transactions, dates):
    ''' Filter transactions on value date based on dates specified in
    ANALYSIS_DATES global variable
    
    Parameters
    ----------
    transactions: pd.DataFrame
        Data of transactions with "TRANS_VALUE_DATE" column
    param_key: str
        Name of pipeline step to look for begin and end dates in parameterization
        
    Returns
    -------
    pd.DataFrame: transactions between begin and end dates
    
    '''
    assert isinstance(dates, dict) and "FROM" in dates and "TO" in dates
    if transactions.empty:
        return transactions
    if 'VALUE_DATETIME' not in transactions.columns:
        transactions["VALUE_DATETIME"] = lookup(
            transactions[constants.TRANS_DATE_KEY]
        )

    if "FROM" in dates:
        date_from = pd.to_datetime(dates["FROM"], format='%Y-%m-%d')
        transactions = transactions[transactions["VALUE_DATETIME"] >= date_from]


        
    if "TO" in dates:
        date_to = pd.to_datetime(dates["TO"], format='%Y-%m-%d')
        transactions = transactions[transactions["VALUE_DATETIME"] <= date_to]

        print(date_to)
        import sys
        # sys.exit(-1)

    return transactions.reset_index(drop=True)


def get_data(parameters, data_type):
    parties_dir = os.path.join(
        get_DATA_PATH_LAST_YEAR(parameters), parameters.BU, data_type
    )
    if os.path.isdir(parties_dir):
        list_files = os.listdir(parties_dir)
    else:
        constants.LOGGER.info(f"Cannot find directory with data for  {data_type} at {parties_dir}")
        return None

    parties_file = ""
    for file in list_files:
        if parameters.BU in file and file.endswith('.csv'):
            parties_file = file
    if parties_file == "":
        constants.LOGGER.info(
            f"Cannot find parties file to serialize for BU {parameters.BU} / {parties_dir}"
        )
        return None
    return pd.read_csv(
        os.path.join(parties_dir, parties_file),
        sep=';'
    )

def get_parties(parameters):
    parties = get_data(parameters, 'Parties')
    rename = build_column_mapping(
        constants.PARTIES_COLUMN_MAPPING,
        parties.columns
    )
    parties = parties.rename(columns=rename)
    return parties


def get_accounts(parameters):
    accounts = get_data(parameters, 'Accounts')
    rename = build_column_mapping(
        constants.ACCOUNTS_COLUMN_MAPPING,
        accounts.columns
    )
    accounts = accounts.rename(columns=rename)
    return accounts


def export_to_xlsx(data, file, subsheets=None):    
    writer = pd.ExcelWriter('data.xlsx', engine='xlsxwriter')
    if subsheets == None:
        for sheet, df in data.items():
            df.to_excel(writer, sheet_name=sheet, index=False)
    else:
        for sheet in subsheets:
            if sheet in data:
                data[sheet].to_excel(writer, sheet_name=sheet, index=False)
            else:
                constants.LOGGER.info("Cannot export sheet ", sheet, "to", file)
    writer.save()
    shutil.copyfile('data.xlsx',file)


def get_kyc_risk_mapping(parameters):
    
    features = pd.concat([
        pd.read_csv(
            os.path.join(
                constants.READ_WRITE_DATA_PATH, parameters.BU,
                'features',
                f'{parameters.BU}_clustering_features_train_{parameters.THRESHOLDS.FEATURES}.csv'
            ), sep=';', usecols=['CRDS_CODE', constants.FEATURES_RISK_KEY]
        ),
        pd.read_csv(
            os.path.join(
                constants.READ_WRITE_DATA_PATH, parameters.BU,
                'features', 
                f'{parameters.BU}_clustering_features_test_{parameters.THRESHOLDS.FEATURES}.csv'
            ), sep=';', usecols=['CRDS_CODE', constants.FEATURES_RISK_KEY]
        )
    ], axis=0).drop_duplicates()

    parties = get_parties(parameters)
    parties = parties[['CRDS_CODE', 'PARTY_KEY']].drop_duplicates()
    parties = pd.merge(parties, features, how='left', on='CRDS_CODE')
    parties = parties[pd.notnull(parties[constants.FEATURES_RISK_KEY])]
  
    return dict(zip(parties.PARTY_KEY, parties[constants.FEATURES_RISK_KEY]))

