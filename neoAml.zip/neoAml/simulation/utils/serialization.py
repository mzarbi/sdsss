import os
import pickle

from ..utils import constants
from ..utils.utils import get_DATA_PATH_LAST_YEAR

def find_xlsx_parameters_file(parameters):
    param_dir = os.path.join(
        get_DATA_PATH_LAST_YEAR(parameters),
        f"{parameters.BU}/Parameters"
    )
    if os.path.isdir(param_dir):
        list_files = os.listdir(param_dir)
    else:
        return ""


    param_file = ""
    for file in list_files:
        if parameters.BU in file and file.endswith('.xlsx'):
            param_file = file
            if ("PARAMETERS_SERIALIZATION" in parameters and parameters.PARAMETERS_SERIALIZATION.PARAMETERS in file) or \
            ("FILES_EXPORT" in parameters and parameters.FILES_EXPORT.PARAMETERS in file):
                break
    if param_file == "":
        return ""
    filename = os.path.join(param_dir, param_file)
    return filename


        
def save_as_pickle(obj, filename):
    '''Saves obj as pickle'''
    assert filename.endswith('.pkl') or filename.endswith('.pickle'), "filename is not a pickle"
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'wb') as f:
        pickle.dump(obj, f)
        

def load_pickle_file(filename):
    '''Load any pickle file'''
    assert filename.endswith('.pkl') or filename.endswith('.pickle'), "filename is not a pickle"
    with open(filename, 'rb') as f:
        return pickle.load(f) 


def load_parameters(iso3_bu, key):
    assert len(iso3_bu) == 3, iso3_bu
    return load_pickle_file(
        os.path.join(
            constants.READ_WRITE_DATA_PATH, iso3_bu, 'thresholds',
            f'thresholds_{iso3_bu}_{key}.pickle'
        )        
    )
    