import os
import pyarrow
import pyarrow.parquet as pq
import pandas as pd
import numpy as np

from ..utils import constants

PYARROW_NUMPY_TYPES = {
    pyarrow.string(): np.dtype(str),
    pyarrow.int64(): np.int64,
    pyarrow.float64(): np.double
}

class ParquetStreamer:
    '''Utility class for streaming data to and from parquet files
    '''
    def __init__(self, filename, schema=None):
        '''Class constructor
            Args:
                filename: string
                    name of parquet file from/to which the stream is opened
                schema: pyarrow.Schema
                    for writing streamers, specify input schema

            A writer is opened if a schema is specified.
        '''
        self.filename = filename
        self.schema = schema
        self.parquet_file = None
        self.writer = None
        if os.path.isfile(filename):
            try:
                self.parquet_file = pq.ParquetFile(filename)
            except:
                constants.LOGGER.info('Invalid file {}'.format(filename))
        if schema is not None:
            self.writer = pq.ParquetWriter(filename, schema)

    def write(self, df):

        self.writer.write_table(
            pyarrow.Table.from_pandas(df, schema=self.schema)
        )

    def write_table(self, table):
        self.writer.write_table(table)

    def read(self, cols=None):
        for group in range(self.parquet_file.num_row_groups):
            yield self.parquet_file.read_row_group(group, cols).to_pandas()


def update_field_name(schema, oldname, newname):
    idx = schema.get_field_index(oldname)
    schema = schema.insert(idx, pyarrow.field(
        newname, schema.field(idx).type
    )).remove(idx+1)
    return schema


def update_field_type(schema, name, pqtype):
    idx = schema.get_field_index(name)
    schema = schema.insert(idx, pyarrow.field(
        name, pqtype
    )).remove(idx+1)
    return schema


def update_types_to_schema(table, schema):
    return table.cast(schema)

def enforce_non_null_schema(schema):
    to_update = []
    for name in schema.names:
        if schema.field_by_name(name).type == pyarrow.null():
            to_update += [name]
    for name in to_update:
        schema = update_field_type(schema, name, pyarrow.string())
    return schema

def get_cluster_mapping(filename):
    cluster_data = pd.read_csv(filename, sep=';')
    return dict(zip(list(cluster_data['CLIENT_KEY']), list(cluster_data['CLUSTER_ID'])))

def get_transactions_by_chunk(filename, cols=None):
    ''' Read data by chunks
    
    Parameters
    ----------
    filename: string
        Name of parquet file to read by row group

    Returns
    -------
    chunk: iterator on pandas dataframe
        Dataframe containing one chunk of payments or postings
    '''    

    reader = ParquetStreamer(filename)
    if reader.parquet_file is None:
        raise Exception("File {} not found".format(filename))
    return reader.read(cols)