import os
import logging
import logging.config
import yaml
import pycountry as pc


READ_ONLY_DATA_PATH = os.environ.get('READ_ONLY_DATA_PATH', r"C:\Users\medzi\Desktop\bnp\amltm_playground\INPUT")
KYC_DATA_PATH = os.environ.get('KYC_DATA_PATH', os.path.join(READ_ONLY_DATA_PATH, 'kyc'))
READ_WRITE_DATA_PATH = os.environ.get('READ_WRITE_DATA_PATH', r"C:\Users\medzi\Desktop\bnp\amltm_playground\OUTPUT")


os.makedirs(READ_WRITE_DATA_PATH, exist_ok=True)
for path in [READ_ONLY_DATA_PATH, KYC_DATA_PATH]:
    assert os.path.exists(path), f"{path} doesn't exist"

       
LOGGING_CONFIG = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    'logging.yml'
)


def setup_logging():
    ''' Setups logging with configuration file or with basic defaults if it's
    not available
    '''
    if os.path.exists(LOGGING_CONFIG):
        with open(LOGGING_CONFIG, 'rt') as fil:
            config = yaml.safe_load(fil.read())
        logging.config.dictConfig(config)
        logging.warning("Loaded logging configuration from %s", LOGGING_CONFIG)
    else:
        logging.basicConfig(level=logging.INFO)
        logging.warning("Couldn't find logging configuration file %s",
                        LOGGING_CONFIG)
        
    
LOGGER = logging.getLogger(__name__) 
setup_logging()

COLUMNS_SAM8_SAM3 = {
    "AMOUNT_LOCAL_CURR": ["MAIN_CURRENCY_AMT", "CONVERTED_AMT"],
    "OPERATION_TYPE": ["OPERATION_TYPE"],
    "TRANSACTION_KEY": ["TRANSACTION_KEY"],
    "CLIENTNUM": ["CLIENT_NUM", "CLIENT_NUMBER"],
    "CLIENT_FINAL_RISK_SCORE": ["RISK_LEVEL"],
    "ACCOUNT_KEY": ["ACCOUNT_KEY"],
    "POPULATION_GROUP_ID": ["ACCOUNT_POPULATION_GROUP"],
    "CLIENT_CLUSTER_ID": ["CLIENT_CLUSTER_ID"],
    "TRANS_TYPE_CD": ["TRANSACTION_TYPE_CODE"],
    "POS_ENTRY_CODE": ["POS_ENTRY_CODE"],
    "TRANS_TYPE_DESC": ["TRANSACTION_TYPE_DESCRIPTION", "TRANSACTION_TYPE_DESC"],
    "TRANS_INSERT_DATE": ["TRANSACTION_INSERTION_DATE"],
    "TRANS_VALUE_DATE": ["TRANSACTION_VALUE_DATE"],
    "POSTING_DIRECTION": ["TRANSACTION_DIRECTION"],
    "PAY_ID": ["PAY_ID"],
    "POS_ID": ["POS_ID"],
    "BU": ["BU"],
    "CRDS_CODE": ["CRDS_CODE"],
    "RMPM_CODE": ["RMPM_CODE"],
    "OPP_COUNTRY_CD": ["OPP_COUNTRY_CD"],
    "PARTY_NAME": ["PARTY_NAME"],
    "CNTY_AML_RISK": ["TSD_COUNTRY_SENSITIVITY"],
    "PAY_INSTR_CD_LINE1": ["PAY_INSTR_CD_LINE1"], #Mandatory for RBA
    "PAY_APP_SOURCE": ["PAY_APP_SOURCE"], #Mandatory for RBA
    "DIRECTION": ["DIRECTION"], #Mandatory for RBA 
    "PAY_MSG_TYPE": ["PAY_MSG_TYPE"] #Mandatory for RBA
}
SERIALIZATION_COLUMNS_TYPES = {
    "AMOUNT_LOCAL_CURR": float,
    "SCORE": float,
    "ALERT_SCORE": float,
    "MAIN_CURRENCY_AMT": float,
}

BUCKET_MAPPING_COLUMNS = {
    "Local Code": ["LOCAL_CODE"],
    "New Mapping": ["EFT_BUCKET_DESC", "BUCKET_CODE_DESC"]
}
PARTIES_COLUMN_MAPPING = {
    "RISK_LEVEL": ["CLIENT_FINAL_RISK_LEVEL"],
    "PARTY_KEY": ["CLIENT_NUMBER"]
}
ACCOUNTS_COLUMN_MAPPING = {
    "ACCOUNT_KEY": ["ACCOUNT_NUMBER"],
    "CLIENTNUM": ["CLIENT_NUMBER", "CLIENT_NUM"]
}
MANDATORY_COLUMNS = [
    "AMOUNT_LOCAL_CURR", "TRANSACTION_KEY", "CLIENTNUM", "CLIENT_FINAL_RISK_SCORE",
    "ACCOUNT_KEY", "POPULATION_GROUP_ID", "TRANS_TYPE_CD", "TRANS_TYPE_DESC", "TRANS_INSERT_DATE",
    "TRANS_VALUE_DATE"
]
MANDATORY_COLUMNS_PER_TRANSACTION = {
    "Postings": ["POSTING_DIRECTION"],
    "Payments": ["OPP_COUNTRY_CD", "CNTY_AML_RISK", "PAY_MSG_TYPE", "DIRECTION", "PAY_APP_SOURCE", "PAY_INSTR_CD_LINE1", "OPP_COUNTRY_CD"]
}

CHUNKSIZE = 1_000_000
CHUNK_GROUPING_KEY = 'ACCOUNT_KEY'
MAIN_AMNT_KEY = 'AMOUNT_LOCAL_CURR'
RISK_SCORE_KEY = 'CLIENT_FINAL_RISK_SCORE'
CLUSTER_KEY = 'CLUSTER_ID'
TSD_COUNTRY_KEY = 'CNTY_AML_RISK'
PARTY_KEY = 'CLIENT_N0'
TRANS_DATE_KEY = 'TRANS_INSERT_DATE'
TEMP_PARQUET_DIR = '/tmp/parquet/'
KPIS_BASE = 'ALERTS'
FEATURES_RISK_KEY = 'RISK_LEVEL'
NON_RELEVANT_ESCALATION_STATUS = "L2 - Closure of alert that should not have been escalated by L1"
RECURRENCE_PERIOD_NAME = 'Recurrence Period (days)'
NUMBER_OCCURRENCES_NAME = 'No. of Occurrences'
MODEL_TRANSACTION_KEY = {
    'FTF': 'POS_ID',
    'EFT': 'POS_ID',
    'TSD': 'PAY_ID',
    'THV': 'PAY_ID'
}
MODEL_FULL_NAMES = {
    'FTF': 'Flow Through of Funds (Credits / Debits)',
    'EFT': 'Excessive Single Transactions',
    'TSD': 'Transfer to/from High-Risk Countries (Level 3)'
}
SUBMODEL_MODEL_MAP = {
    'Flow Through of Funds (Credits / Debits)': 'FTF',
    'Excessive Single Transactions': 'EFT',
    'Transfer to/from High-Risk Countries (Level 3)': 'TSD',
    'Transfer to/from Very High-Risk Countries (Level 4)': 'TSD',
    'Transfer to/from Tax Haven Countries': 'THV',
    'Transfer to/from Local Tax Haven Countries': 'THV'
}
MODEL_THRESHOLD_NAME = {
    'EFT': 'Minimal Transaction Amount',
    'FTF': 'Sum Lower Bound',
    'TSD': 'Minimal Transaction Value',
    'THV': 'Minimal Transaction Value',
    'STP': 'Transaction Amount: Maximum'
}
MODEL_SCORE_NAME = {
    'EFT': 'Activity Value',
    'FTF': 'Sum Score',
    'TSD': 'Activity Value',
    'THV': 'Activity Value'
}
SCORE_FACTOR_MAPPING = {
    'Flow Through of Funds (Credits / Debits)': 'Sum Score'
}
THRESHOLD_UPPER_LIMIT = {
    "TSD3": 1_000_000,
    "TSD4": 150_000
}
TSD_CODE_MODEL_MAPPING = {
    3: 'Transfer to/from High-Risk Countries (Level 3)',
    4: 'Transfer to/from Very High-Risk Countries (Level 4)',
    5: 'Transfer to/from Tax Haven Countries',
    6: 'Transfer to/from Local Tax Haven Countries'
}
TSD_CODE_RULE_MAPPING = {
    3: 'BNP-TSD-EFT-ALL-A-S01-HRC',
    4: 'BNP-TSD-EFT-ALL-A-S01-VRC',
    5: 'BNP-THV-EFT-ALL-A-S01-THV',
    6: 'BNP-THV-EFT-ALL-A-S01-LTH'
}

TAX_HAVENS_FILE = os.path.join(
    READ_ONLY_DATA_PATH,
    "inputs/Tax_Havens_Countries.csv"
)

RBA_CLIENT_NUMBER = {
    'DE': {
            'FORTIS_SDD': [
                'DE4009108220073',
                'DE4009108220183',
                'DE4009108010592',
                'DE4009108323400',
            ], 
            'GEVA': [
                'DE4009108422427',
            ]
    },
    'ES': {
            'FORTIS_SDD': [
                'ES0100201300010',
                'ES0100101302143',
                'ES0100101302610',
                'ES0100101302607',
                'ES0100101060149',
                'ES0100101301804',
                'ES0100101010129',
            ]
    },
    'NL': {
            'FORTIS_SDD': [
                'NL0100010103022',
                'NL0100010013075',
                'NL0100010100492',
            ]
    },
}

RISK_LEVEL_MAPPING = {
    0: '0-LOW', '0-LOW': '0-LOW',
    1: '1-MEDIUM', '1-MEDIUM': '1-MEDIUM',
    2: '2-HIGH', '2-HIGH': '2-HIGH',
    '0': '0-LOW', '1': '1-MEDIUM', '2': '2-HIGH'
}
INVERT_RISK_LEVEL_MAPPING = {
    '0-LOW': 0,
    '1-MEDIUM': 1,
    '2-HIGH': 2,
}
ISO2_ISO3_MAPPING = {country.alpha_2 : country.alpha_3 for country in pc.countries}
ISO3_ISO2_MAPPING = {v: k for k, v in ISO2_ISO3_MAPPING.items()}
COUNTRY_ISO2_MAPPING = {country.name: country.alpha_2 for country in pc.countries}
# Specific names for country list
custom_mapping = {
    'United States of America': 'United States',
    'Czech Republic': 'Czechia',
    'Russia': 'Russian Federation',
    'Slovak Republic': 'Slovakia',
    'South Korea': 'Korea, Republic of'
}
for k, v in custom_mapping.items():
    if v in list(COUNTRY_ISO2_MAPPING.keys()):
        COUNTRY_ISO2_MAPPING[k] = COUNTRY_ISO2_MAPPING[v]
        COUNTRY_ISO2_MAPPING.pop(v, None)
ISO2_COUNTRY_MAPPING = {v: k for k, v in COUNTRY_ISO2_MAPPING.items()}
ISO3_COUNTRY_MAPPING = {ISO2_ISO3_MAPPING[k]: v for k, v in ISO2_COUNTRY_MAPPING.items()}
COUNTRY_HOLIDAY_PARAMETERS = {k: {} for k in ISO2_ISO3_MAPPING.values()}
COUNTRY_HOLIDAY_PARAMETERS["GBR"] = {"state": "England"}

NEW_CLIENTS_CLUSTER_RISK_MAPPING = {
    '0-LOW': '1',
    '1-MEDIUM': '2',
    '2-HIGH': '3'
}
RULES_MODEL_MAPPING = {
    'BNP-TSD-EFT-ALL-A-S01-VRC': 'TSD4', 'BNP-TSD-EFT-ALL-A-S01-HRC': 'TSD3',
    'BNP-THV-EFT-ALL-A-S01-LTH': 'LTH', 'BNP-TSD-EFT-ALL-A-S01-THV': 'THV',
    'BNP-EFT-TRN-ALL-A-S01-EST': 'EFT', 'BNP-FTF-TRN-ALL-A-B02-FTR': 'FTF',
    'BNP-EFT-SHT-ALL-A-S01-EST': 'EFT', 'BNP-EFT-CSH-ALL-A-S01-EST': 'EFT',
    'BNP-EFT-CFT-ALL-A-S01-EST': 'EFT', 'BNP-EFT-CHK-ALL-A-S01-EST': 'EFT',
}
THRESHOLDS_SCORING_NAME = {
    'Minimal Transaction Amount': 'Activity Value',
    'Sum Lower Bound': 'Sum Score',
    'Minimal Transaction Value': 'Activity Value'
}
SUBMODEL_SCORE_THRESHOLDS = {
    'Flow Through of Funds (Credits / Debits)': 40,
    'Excessive Single Transactions': 40,
    'Transfer to/from High-Risk Countries (Level 3)':  45,
    'Transfer to/from Very High-Risk Countries (Level 4)': 50,
    'Transfer to/from Tax Haven Countries': 45,
    'Transfer to/from Local Tax Haven Countries': 45
}
TSD_COUNTRY_CODE_MAPPING = {
    'MAR': 3
}

CURRENCIES_MAPPING = {
    'SG': 'SGD',
    'IN': 'INR'
}

SAM3_MODELS = ["3PP", "ADR", "EPC", "HBC", "KEY", "LOW", "NBI", "SCT", "STP", "EFT", "FTF", "TSD"]
SAM8_MODELS = ["ADR", "CTF", "EPC", "KHI", "KLO", "LTH", "NBI", "SBP", "STP", "THV", "EFT", "FTF", "TSD"]

DEFAULT_VALUES = {
    'EFT': 1_000_000,
    'TSD3': 50_000,
    'TSD4': 100,
    'THV': 1,
    'LTH': 1,
    'FTF': 1_000_000
}

CLUSTERING_COLUMNS = [
    'LOG_RISK_SCORE', 'ADVERSE_INFO', 'COUNTRY_INCORPORATION',
    'LOG_NUMBER_TRANSACTIONS','LOG_NUMBER_TRANSACTIONS_HIGH_RISK',
    'LOG_MEDIAN_TRANSACTIONS_HIGH_RISK', 'LOG_FTF_HITS'
]

POPULATION_THRESHOLDS_COLUMNS = [
    'RULE_ID', 'RULE_NAME', 'THRESHOLD_NAME', 'PARAM_ID', 'ROLE_ID', 'TENANT_ID', 'REGION_CD', 'POPULATION_GROUP_ID', 'THRESHOLD_VALUE'
]
POPULATION_SCORES_COLUMNS = [
    'RULE_ID', 'RULE_NAME', 'SCORE_FACTOR_NAME', 'PARAM_ID', 'TENANT_ID', 'REGION_CD', 'POPULATION_GROUP_ID', 'FROM_VALUE', 'SCORE'
]
INDIVIDUAL_THRESHOLDS_COLUMNS = [
    'RULE_ID', 'RULE_NAME', 'THRESHOLD_NAME', 'PARAM_ID', 'ROLE_ID', 'TENANT_ID', 'ENTITY_KEY', 'THRESHOLD_VALUE'
]
INDIVIDUAL_SCORES_COLUMNS = [
    'RULE_ID', 'RULE_NAME', 'SCORE_FACTOR_NAME', 'PARAM_ID', 'TENANT_ID', 'ENTITY_KEY', 'FROM_VALUE', 'SCORE'
]


DEFAULT_THRESHOLDS = {
    'EFT': 1_000_000,
    'STP': 10_000
}

DEFAULT_SCORES = {
    'EFT': 40
}
ROLE_ID_MAPPING = {
    'Structuring of Payments : Incoming': 2,
    'Structuring of Payments : Outgoing': 2,
    'Flow Through of Funds (Credits / Debits)': 3
}
PARAMETERS_FILE_SHEETS = [
    'Default Thresholds', 'Tenant Thresholds', 'Population Thresholds', 'Individual Thresholds',
    'Default Scores', 'Tenant Scores', 'Population Scores', 'Individual Scores',
    'Lists', 'Lists-TSD THV LTH', 'SBP - SB Thresholds', 'SBP - Event Thresholds',
    'SBP - Event Weights', 'SBP - Multiplier for Volume', 'SBP - Party Risk Level',
    'SBP - Transaction Risk Level'
]
CLUSTERS_FILE_SHEETS = ['aml_cb_CLIENT_cluster', 'aml_cb_clusters']

CLUSTERS_HEATMAP_COLUMNS = [
    'LOG_RISK_SCORE', 'COUNTRY_INCORPORATION', 'ADVERSE_INFO',
    'NUMBER_TRANSACTIONS', 'MEAN_TRANSACTIONS',
    'MEDIAN_LOG_TRANSACTIONS', 'STD_LOG_TRANSACTIONS',
    'NUMBER_TRANSACTIONS_HIGH_RISK', 'LOG_MEDIAN_TRANSACTIONS_HIGH_RISK', 'FTF_HITS',
    'NB_EFT_L2+_ALERTS', 'NB_FTF_L2+_ALERTS',
    'NB_TSD3_L2+_ALERTS', 'NB_TSD4_L2+_ALERTS'
]

FILTER_1 = 'Filter private parties/staff'
FILTER_2 = 'Filter whitelist accounts'
FILTER_3 = 'Has KYC OR is BNPP entity OR has transactions'

SAM3_SAM8_RULES_MAPPING = {
    'BNP-HBC-TRN-INN-A-M01-HBN': 'AML-SBP-ALL-ALL-PG-M01-SBP',
    'BNP-HBC-TRN-OUT-A-M01-HBN': 'AML-SBP-ALL-ALL-PG-M01-SBP',
    'BNP-HBC-TRN-INN-A-M01-HBS': 'AML-SBP-ALL-ALL-PG-M01-SBP',
    'BNP-HBC-TRN-OUT-A-M01-HBS': 'AML-SBP-ALL-ALL-PG-M01-SBP',
    'BNP-SPI-EFT-MSG-A-S01-LOW': 'BNP-SPI-EFT-MSG-A-S01-KEY',
    'BNP-SPI-EFT-MSG-A-S01-3PP': 'BNP-SPI-EFT-MSG-A-S01-CTF',
    'BNP-SPI-EFT-MSG-A-S01-KEY': 'BNP-SPI-EFT-MSG-A-S01-OBO',
    'BNP-ADR-TRN-ALL-A-M07-AIN': 'BNP-ADR-TRN-ALL-A-M07-AIN',
    'BNP-EPC-TRN-INN-D01-A-EPB': 'BNP-EPC-TRN-INN-D01-A-EPB',
    'BNP-EPC-TRN-OUT-D01-A-EPB': 'BNP-EPC-TRN-OUT-D01-A-EPB',
    'BNP-FTF-TRN-ALL-A-B02-FTR': 'BNP-FTF-TRN-ALL-A-B02-FTR',
    'BNP-NBI-TRN-ALL-A-D31-NBI': 'BNP-NBI-TRN-ALL-A-DXX-NBI',
    'BNP-STP-EFT-ALL-A-D02-AVB': 'BNP-STP-EFT-ALL-A-DXX-TRD',
    'BNP-STP-EFT-INN-A-DXX-SCT': 'BNP-STP-EFT-INN-A-DXX-SCT',
    'BNP-STP-EFT-INN-A-DXX-TRD': 'BNP-STP-EFT-INN-A-DXX-TRD',
    'BNP-STP-EFT-OUT-A-DXX-SCT': 'BNP-STP-EFT-OUT-A-DXX-SCT',
    'BNP-STP-EFT-OUT-A-DXX-TRD': 'BNP-STP-EFT-OUT-A-DXX-TRD',
    'BNP-TSD-EFT-ALL-A-S01-THV': 'BNP-TSD-EFT-ALL-A-S01-THV',
    'BNP-TSD-EFT-ALL-A-S01-HRC': 'BNP-TSD-EFT-ALL-A-S01-HRC',
    'BNP-TSD-EFT-ALL-A-S01-VRC': 'BNP-TSD-EFT-ALL-A-S01-VRC'
}
SAM8_SAM3_RULES_MAPPING = {
    'BNP-EFT-SHT-ALL-A-S01-EST': 'BNP-EFT-TRN-ALL-A-S01-EST',
    'BNP-EFT-CFT-ALL-A-S01-EST': 'BNP-EFT-TRN-ALL-A-S01-EST',
    'BNP-EFT-CSH-ALL-A-S01-EST': 'BNP-EFT-TRN-ALL-A-S01-EST',
    'BNP-EFT-CHK-ALL-A-S01-EST': 'BNP-EFT-TRN-ALL-A-S01-EST',
    'BNP-EFT-DFT-ALL-A-S01-EST': 'BNP-EFT-TRN-ALL-A-S01-EST'
}
SAM3_KEYWORD_MODEL_MAPPING = {
    'BNP-SPI-EFT-MSG-A-S01-LOW': '05 - KLO',
    'BNP-SPI-EFT-MSG-A-S01-KEY': '06 - KHI',
    'BNP-SPI-EFT-MSG-A-S01-3PP': '07 - 3PP'
}
SAM8_KEYWORD_MODEL_MAPPING = {
    'BNP-SPI-EFT-MSG-A-S01-KEY': '05 - KLO',
    'BNP-SPI-EFT-MSG-A-S01-OBO': '06 - KHI',
    'BNP-SPI-EFT-MSG-A-S01-CTF': '07 - CTF',
}

BASE_PARAMETERS_SHEET_NAMES = {
    'Default Thresholds': ['RULE_ID', 'RULE_NAME', 'THRESHOLD_NAME'],
    'Default Scores': ['RULE_ID', 'RULE_NAME', 'SCORE_FACTOR_NAME', 'FROM_VALUE'],
    'Tenant Thresholds': ['RULE_ID', 'RULE_NAME', 'ATTRIBUTE_NAME','THRESHOLD_NAME'],
    'Tenant Scores': ['RULE_ID', 'RULE_NAME', 'SCORE_FACTOR_NAME', 'FROM_VALUE'],
    'Population Thresholds': ['RULE_ID', 'RULE_NAME', 'THRESHOLD_NAME'],
    'Population Scores': ['RULE_ID', 'RULE_NAME', 'SCORE_FACTOR_NAME','FROM_VALUE']
}
TO_VALIDATE_PARAMETERS_SHEET_NAMES = {
    'Default Thresholds': ['DEFAULT_VALUE', 'PARAM_ID', 'ROLE_ID'],
    'Default Scores': ['PARAM_ID', 'SCORE'],
    'Tenant Thresholds': ['THRESHOLD_VALUE', 'PARAM_ID', 'ROLE_ID'],
    'Tenant Scores': ['PARAM_ID', 'SCORE'],
    'Population Thresholds': ['THRESHOLD_VALUE', 'PARAM_ID', 'ROLE_ID'],
    'Population Scores': ['SCORE', 'PARAM_ID']
}

TRANSACTION_TYPE_PER_MODEL = {
    'EFT': 'Postings',
    'FTF': 'Postings',
    'TSD': 'Payments',
    'THV': 'Payments',
    'ADR': 'Postings',
    'EPC': 'Postings',
    'NBI': 'Postings',
    'STP': 'Payments',
    'SCT': 'Postings',
    '3PP': 'Payments',
    'KEY': 'Payments',
    'LOW': 'Payments'
}

SHEET_TARGET_COLUMNS_MAPPING = {
    "Default Thresholds": ["THRESHOLD_NAME", "DEFAULT_VALUE"],
    "Tenant Thresholds": ["THRESHOLD_NAME", "THRESHOLD_VALUE"],
    "Population Thresholds": ["THRESHOLD_NAME", "THRESHOLD_VALUE"],
    "Individual Thresholds": ["THRESHOLD_NAME", "THRESHOLD_VALUE"],
    "Default Scores": ["SCORE_FACTOR_NAME", "FROM_VALUE"],
    "Tenant Scores": ["SCORE_FACTOR_NAME", "FROM_VALUE"],
    "Population Scores": ["SCORE_FACTOR_NAME", "FROM_VALUE"],
    "Individual Scores": ["SCORE_FACTOR_NAME", "FROM_VALUE"]
}
SHEET_TENANT_ID_COLUMN = {
    "Tenant Thresholds": "TENANT_ID",
    "Population Thresholds": "TENANT_ID",
    "Individual Thresholds": "TENANT_ID",
    "Tenant Scores": "TENANT_ID",
    "Population Scores": "TENANT_ID",
    "Individual Scores": "TENANT_ID",
    "Lists-TSD THV LTH": "TENANT_CD",
    "SBP - SB Thresholds": "TENANT_CD",
    "SBP - Event Thresholds": "TENANT_CD",
    "SBP - Event Weights": "Tenant Code",
    "SBP - Multiplier for Volume": "Tenant Code",
    "SBP - Party Risk Level": "Tenant Code",
    "SBP - Transaction Risk Level": "Tenant Code"
}
SHEET_REGION_ID_COLUMN = {
    "Tenant Thresholds": "REGION_CD",
    "Population Thresholds": "REGION_CD",
    "Tenant Scores": "REGION_CD",
    "Population Scores": "REGION_CD",
    "Lists-TSD THV LTH": "REGION_CD",
    "SBP - SB Thresholds": "REGION_CD",
    "SBP - Event Thresholds": "REGION_CD",
    "SBP - Event Weights": "Region Code",
    "SBP - Multiplier for Volume": "Region Code",
    "SBP - Party Risk Level": "Region Code",
    "SBP - Transaction Risk Level": "Region Code"
}
V8_LISTS_NAMES = {
    "Whitelisted Accounts": {},
    "BNP-SPI-LOW Excluded Keywords": {
        "LIST_ID": "BNP-WRD-EX-01",
        "LIST_NAME": "Model#10 BNP-KLO : Keywords In Payments - White List (KeyWords)"
    },
    "BNP-SPI Excluded Keywords": {
        "LIST_ID": "BNP-WRD-EX-02",
        "LIST_NAME": "Model#11 BNP-KHI : On Behalf Of - White List (KeyWords)"
    },
    "BNP-SPI-3PP Excluded Keywords": {
        "LIST_ID": "BNP-WRD-EX-03",
        "LIST_NAME": "Model#14 BNP-CTF : Non Transparent Payment - White List (KeyWords)"
    },
    "BNP-SPI-LOW Keywords": {
        "LIST_ID": "BNP-WRD-KY-01",
        "LIST_NAME": 'Model#10 BNP-KLO : BNPP Low Signal Keyword List'
    },
    "BNP-SPI Keywords": {
        "LIST_ID": "BNP-WRD-KY-02",
        "LIST_NAME": "Model#11 BNP-KHI : BNPP Strong Signal Keyword List"
    },
    "BNP-SPI-3PP Keywords": {
        "LIST_ID": "BNP-WRD-KY-03",
        "LIST_NAME": "Model#14 BNP-CTF : Non Transparent Payment - Keyword List"
    }
}
V8_V3_PARAMETERS_MAPPING = {
    "Recurrence Period": "Recurrence Period (days)"
}