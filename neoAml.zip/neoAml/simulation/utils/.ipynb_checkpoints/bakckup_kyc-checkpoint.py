import os
import numpy as np
import pandas as pd

from ..utils import constants
from ..utils.utils import lookup


def agg_kyc_data(x):
    #TODO : optimize to remove iloc -> why squeeze instead of [0] ?
    if len(x) == 1:
        return x.squeeze()
    non_closed = x[x['LIFECYCLE_STATUS'] != "Closed"]
    if len(non_closed) == 1:
        return non_closed.squeeze()
    elif len(non_closed) == 0:
        return x.iloc[0].squeeze()
    non_terminated = non_closed[non_closed['KYC_STATUS'] != "Terminated"]
    if len(non_terminated) == 1:
        return non_terminated.squeeze()
    elif len(non_terminated) == 0:
        return non_closed.iloc[0].squeeze()
    non_reliant = non_terminated[non_terminated['FROM_RELIANCE'] == 0]
    if len(non_reliant) == 1:
        return non_reliant.squeeze()
    elif len(non_reliant) == 0:
        return non_terminated.iloc[0].squeeze()
    return non_reliant.iloc[0].squeeze()


def load_kyc(business_unit):
    ''' Get KYC data for a business unit
    
    Parameters
    ----------
    business_unit: string
    shortcut for the business unit
    
    Return
    ------
    pd.Dataframe with KYC data for clients in the business unit
    
    '''
    
     # Read the KYC report
    kyc_columns = ['Concatenated CRDS Code', 'KYC Record Id', '@_BNPP Segment', 'BNPPRG Risk Score',
                  '@_Final risk score', '@_Previous final risk score', 'Financial security incident (rating)',
                   'Adverse Info/Rep Issue', 'Country Of Incorporation', 'Client Name',
                  'Record Status', 'Client Lifecycle Status', 'BO-Territory', 'Process Status Date']
    df = pd.read_csv(os.path.join(
        constants.KYC_DATA_PATH, 'gcars_report.csv'
    ), usecols=kyc_columns, sep=';')
    df['@_Final risk score'] = np.where(pd.isnull(df['@_Final risk score']), df['@_Previous final risk score'], df['@_Final risk score'])
    df['@_Final risk score'] = df['@_Final risk score'].fillna('MISSING_RISK_LEVEL')
    
#     df['BNPPRG Risk Score'] = df['BNPPRG Risk Score'].map({
#         "LOW": 0,
#         "MEDIUM": 1,
#         "HIGH": 2
#     })
    
    for col in df.columns:
        if pd.api.types.is_string_dtype(df[col]):
            df[col] = df[col].str.strip()
            df[col] = df[col].str.rstrip()
    
    group_medians = df.groupby('@_Final risk score').transform(
        lambda x: x.fillna(x.mode())
    )
    for col in group_medians.columns:
        df[col] = group_medians[col]

    df.rename(columns={
        'Concatenated CRDS Code': 'CRDS_CODE', 'KYC Record Id': 'KYC_ID',
        '@_BNPP Segment': 'KYC_SEGMENT', 'BNPPRG Risk Score': 'RISK_SCORE',
        '@_Final risk score': 'RISK_LEVEL', 'Adverse Info/Rep Issue': 'ADVERSE_INFO',
        'Country Of Incorporation': 'COUNTRY_INCORPORATION',
        'Client Name': 'CLIENT_NAME',
        'Record Status': 'KYC_STATUS',
        'Client Lifecycle Status': 'LIFECYCLE_STATUS',
        'BO-Territory': 'BO_TERRITORY',
        'Process Status Date': 'PROCESS_STATUS_DATE'
    }, inplace=True)

    master_crds = set(df[~df['KYC_ID'].astype(str).str.contains('-')]['CRDS_CODE'].unique())
    extension_crds = set(df[df['KYC_ID'].astype(str).str.contains('-')]['CRDS_CODE'].unique())
    extension_crds = extension_crds - master_crds
    df = pd.concat([df[df['CRDS_CODE'].isin(master_crds)], df[df['CRDS_CODE'].isin(extension_crds)]], ignore_index=True)
    df['PROCESS_STATUS_DATE'] = lookup(df['PROCESS_STATUS_DATE'])
    #df = df.groupby('CRDS_CODE').first().reset_index()
    df['FROM_RELIANCE'] = 0

    # Add KYC from reliance
    reliance_columns = [
        'Concatenated CRDS Code', 'Client Name', 'Reliance Sensitivity', 'Country of Incorporation',
        "Reliance Reference Code", 'Client Lifecycle Status', 'BNPP Entity', 'BO-Territory', 'Record Status'
    ]
    df_reliance = pd.read_csv(os.path.join(
        constants.READ_ONLY_DATA_PATH, 'kyc', 'kyc_reliance_worldwide.csv'
    ), usecols=reliance_columns, sep=';', encoding='unicode_escape').rename(columns={
        "Concatenated CRDS Code": "CRDS_CODE",
        "Client Name": "CLIENT_NAME",
        "Reliance Sensitivity": "RISK_LEVEL",
        "Country of Incorporation": "COUNTRY_INCORPORATION",
        "Reliance Reference Code": "KYC_ID",
        "Client Lifecycle Status": "LIFECYCLE_STATUS",
        "BO-Territory": "BO_TERRITORY",
        "Record Status": "KYC_STATUS",
        "BNPP Entity": "BNPP_ENTITY"
    })
    df_reliance["FROM_RELIANCE"] = 1
    df = pd.concat([df, df_reliance], axis=0)
    
    df['RISK_LEVEL'] = df['RISK_LEVEL'].map({'LOW': '0-LOW', 'MEDIUM': '1-MEDIUM', 'HIGH': '2-HIGH'})
    df = df[pd.notnull(df['CRDS_CODE'])]

    df['HAS_FSI'] = np.where(df['Financial security incident (rating)'] <= 0, 'NO_FSI', 'MISSING_FSI')
    df['HAS_FSI'] = np.where(df['Financial security incident (rating)'] >= 100, 'HAS_FSI', df['HAS_FSI'])
    df.drop(['Financial security incident (rating)', '@_Previous final risk score'], axis=1, inplace=True)

    adverse_mapping = {'Previously Vetted': 'Immaterial', 'Material': 'Material',
                      'Potential Hit': 'Immaterial', 'Immaterial': 'Immaterial', 'Yes': 'Material',
                      'No': 'No', 'No Result': 'No', 'Check not done': 'No', 'Out of Scope': 'No'}
    df['ADVERSE_INFO'] = df['ADVERSE_INFO'].map(adverse_mapping).fillna('MISSING_ADVERSE_INFO')
    df = df[df['BO_TERRITORY'] == constants.ISO3_COUNTRY_MAPPING[business_unit]]

    pd.set_option("max_columns", None)
    
    df = (
        df.groupby('CRDS_CODE')
        .apply(agg_kyc_data)
        .reset_index(drop=True)
    )
    df.drop('KYC_ID', axis=1, inplace=True)

    # Add country ratings
    ratings = pd.read_csv(os.path.join(
        constants.KYC_DATA_PATH, 'country_risk.csv'
    ), sep=';')
    ratings['Rating Letter'] = np.where(ratings['French list of tax havens'] == 'X', 'THV', ratings['Rating Letter'])
    country_ratings = dict(zip(ratings['Country'], ratings['Rating Letter']))
    df['COUNTRY_INCORPORATION'] = df['COUNTRY_INCORPORATION'].map(country_ratings)

    return df
