import os
import numpy as np
import pandas as pd

from ..utils import constants
from ..utils.utils import lookup


def agg_kyc_data(x):
    #TODO : optimize to remove iloc -> why squeeze instead of [0] ?
    if len(x) == 1:
        return x.squeeze()
    non_closed = x[x['LIFECYCLE_STATUS'] != "Closed"]
    if len(non_closed) == 1:
        return non_closed.squeeze()
    elif len(non_closed) == 0:
        return x.iloc[0].squeeze()
    non_terminated = non_closed[non_closed['KYC_STATUS'] != "Terminated"]
    if len(non_terminated) == 1:
        return non_terminated.squeeze()
    elif len(non_terminated) == 0:
        return non_closed.iloc[0].squeeze()
    non_reliant = non_terminated[non_terminated['FROM_RELIANCE'] == 0]
    if len(non_reliant) == 1:
        return non_reliant.squeeze()
    elif len(non_reliant) == 0:
        return non_terminated.iloc[0].squeeze()
    return non_reliant.iloc[0].squeeze()


def load_kyc(business_unit):
    ''' Get KYC data for a business unit
    
    Parameters
    ----------
    business_unit: string
    shortcut for the business unit
    
    Return
    ------
    pd.Dataframe with KYC data for clients in the business unit
    
    '''
    
     # Read the KYC report
    kyc_columns = ['CONCATENATED_CRDS_CODE', 'KYC_RECORD_ID', 'SEGMENT_NAME', 'RISK_SCORE',
                  'FINAL_RISK_SCORE_LEVEL', 'PRV_FINAL_RISK_SCORE_LEVEL', 'FINANCIAL_SECURITY_INCIDENTS_RATING',
                   'ADVERSE_INFO_REP_ISSUE', 'COUNTRY_OF_INCORPORATION', 'CLIENT_NAME',
                  'RECORD_STATUS', 'CLIENT_LIFECYCLE_STATUS', 'BO_TERRITORY', 'STATUS_DATE']
    df = pd.read_csv(os.path.join(
        constants.KYC_DATA_PATH, 'gcars_report.csv'
    ), usecols=kyc_columns, sep=';')
    
    df['FINAL_RISK_SCORE_LEVEL'] = np.where(pd.isnull(df['FINAL_RISK_SCORE_LEVEL']), df['PRV_FINAL_RISK_SCORE_LEVEL'], df['FINAL_RISK_SCORE_LEVEL'])
    df['FINAL_RISK_SCORE_LEVEL'] = df['FINAL_RISK_SCORE_LEVEL'].fillna('MISSING_RISK_LEVEL')

    group_medians = df.groupby('FINAL_RISK_SCORE_LEVEL').transform(
        lambda x: x.fillna(round(x.median()))
    )
    for col in group_medians.columns:
        df[col] = group_medians[col]

    df.rename(columns={
        'CONCATENATED_CRDS_CODE': 'CRDS_CODE', 'KYC_RECORD_ID': 'KYC_ID',
        'SEGMENT_NAME': 'KYC_SEGMENT',
        'FINAL_RISK_SCORE_LEVEL': 'RISK_LEVEL',
        'ADVERSE_INFO_REP_ISSUE': 'ADVERSE_INFO',
        'COUNTRY_OF_INCORPORATION': 'COUNTRY_INCORPORATION',
        'RECORD_STATUS': 'KYC_STATUS',
        'CLIENT_LIFECYCLE_STATUS': 'LIFECYCLE_STATUS',
        'BO_TERRITORY': 'BO_TERRITORY',
        'STATUS_DATE': 'PROCESS_STATUS_DATE'
    }, inplace=True)

    master_crds = set(df[~df['KYC_ID'].astype(str).str.contains('-')]['CRDS_CODE'].unique())
    extension_crds = set(df[df['KYC_ID'].astype(str).str.contains('-')]['CRDS_CODE'].unique())
    extension_crds = extension_crds - master_crds
    df = pd.concat([df[df['CRDS_CODE'].isin(master_crds)], df[df['CRDS_CODE'].isin(extension_crds)]], ignore_index=True)
    df['PROCESS_STATUS_DATE'] = lookup(df['PROCESS_STATUS_DATE'])
    #df = df.groupby('CRDS_CODE').first().reset_index()
    df['FROM_RELIANCE'] = 0

    # Add KYC from reliance
    reliance_columns = [
        'CONCATENATED_CRDS_CODE', 'CLIENT_NAME', 'RELIANCE_SENSITIVITY', 'COUNTRY_OF_INCORPORATION',
        "RELIANCE_REFERENCE_CODE", 'CLIENT_LIFECYCLE_STATUS', 'BNPP_ENTITY', 'BO_TERRITORY', 'RECORD_STATUS'
    ]
    df_reliance = pd.read_csv(os.path.join(
        constants.READ_ONLY_DATA_PATH, 'kyc', 'kyc_reliance_worldwide.csv'
    ), usecols=reliance_columns, sep=';', encoding='unicode_escape').rename(columns={
        "CONCATENATED_CRDS_CODE": "CRDS_CODE",
        "RELIANCE_SENSITIVITY": "RISK_LEVEL",
        "COUNTRY_OF_INCORPORATION": "COUNTRY_INCORPORATION",
        "RELIANCE_REFERENCE_CODE": "KYC_ID",
        "CLIENT_LIFECYCLE_STATUS": "LIFECYCLE_STATUS",
    })
    df_reliance["FROM_RELIANCE"] = 1
    df = pd.concat([df, df_reliance], axis=0)

    df['RISK_LEVEL'] = df['RISK_LEVEL'].map({'LOW': '0-LOW', 'MEDIUM': '1-MEDIUM', 'HIGH': '2-HIGH'})
    df = df[pd.notnull(df['CRDS_CODE'])]

    df['HAS_FSI'] = np.where(df['FINANCIAL_SECURITY_INCIDENTS_RATING'] <= 0, 'NO_FSI', 'MISSING_FSI')
    df['HAS_FSI'] = np.where(df['FINANCIAL_SECURITY_INCIDENTS_RATING'] >= 100, 'HAS_FSI', df['HAS_FSI'])
    df.drop(['FINANCIAL_SECURITY_INCIDENTS_RATING', 'PRV_FINAL_RISK_SCORE_LEVEL'], axis=1, inplace=True)

    adverse_mapping = {'Previously Vetted': 'Immaterial', 'Material': 'Material',
                      'Potential Hit': 'Immaterial', 'Immaterial': 'Immaterial', 'Yes': 'Material',
                      'No': 'No', 'No Result': 'No', 'Check not done': 'No', 'Out of Scope': 'No'}
    df['ADVERSE_INFO'] = df['ADVERSE_INFO'].map(adverse_mapping).fillna('MISSING_ADVERSE_INFO')
    df = df[df['BO_TERRITORY'] == constants.ISO3_COUNTRY_MAPPING[business_unit]]

    df = (
        df.groupby('CRDS_CODE')
        .apply(agg_kyc_data)
        .reset_index(drop=True)
    )
    df.drop('KYC_ID', axis=1, inplace=True)

    # Add country ratings
    ratings = pd.read_csv(os.path.join(
        constants.KYC_DATA_PATH, 'country_risk.csv'
    ), sep=';')
    ratings['Rating'] = np.where(ratings['French list of tax havens'] == 'X', 'THV', ratings['Rating'])
    country_ratings = dict(zip(ratings['Country'], ratings['Rating']))
    df['COUNTRY_INCORPORATION'] = df['COUNTRY_INCORPORATION'].map(country_ratings)

    return df
