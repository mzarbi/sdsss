import json

from aml_transaction_monitoring.utils import constants

class PipelineArgs:
    def __init__(self, dic):
        self.__dict__ = dic
        
    def __iter__(self):
        """So that we can use the "in" method"""
        return iter(self.__dict__)
    
    def __repr__(self):
        return str(self.__dict__)
        

class Parameters:
    def __init__(self, global_parameters, experiment_parameters):
        """
        global_parameters : dic with keys ["MODEL_VERSION", "LIST_MODEL", "LIST_BU", "LOCAL_CURRENCY_RATE", "TRACKING", "ANALYSIS_DATES", "STANDARD_PERCENTILE", "PERCENT_ESCALATION_SIGNIFICANTLY_BELOW", "HITS_ACCOUNT_SIGNIFICANTLY_ABOVE"]
        experiment_parameters : dic with keys ["EXPERIMENT_KEY", "PIPELINE_STEPS"]
        """
        dic = {**global_parameters, **experiment_parameters}
        self._check_format(dic)
        self.dic = dic
        
        self.mandatory_attributes = [
            'EXPERIMENT_KEY',
            'MODEL_VERSION',
            'LIST_MODEL',
            'BU',
            'LOCAL_CURRENCY_RATE',
            'TRACKING',
            'ANALYSIS_DATES',
            'PIPELINE_STEPS',
            'STANDARD_PERCENTILE',
            'PERCENT_ESCALATION_SIGNIFICANTLY_BELOW',
            'HITS_ACCOUNT_SIGNIFICANTLY_ABOVE',
            'LOOKBACK_PERIOD',
            "BUCKET_MAPPING_MODE",
        ]
        
        for attr in self.mandatory_attributes:
            if attr in self.dic:
                self.__setattr__(attr, self.dic[attr])
            else:
                raise Exception(f'Missing {attr} in Parameters argument')
        
        self.optional_attributes = [
            "GMM_COMPONENTS_RISK_LEVEL",
            "CLUSTERS_NUMBER_RISK_LEVEL",
            "EFT_CONSTANT_THRESHOLDS"
        ]
        for attr in self.optional_attributes:
            if attr in self.dic:
                self.__setattr__(attr, self.dic[attr])
                
        #replacing "KEY" with the experiment key
        for step, dic in self.PIPELINE_STEPS.items():
            for key, value in dic.items():
                if value == 'KEY':
                    self.PIPELINE_STEPS[step][key] = self.EXPERIMENT_KEY
                    
        assert len(self.BU) == 3, "Please provide the BU in ISO3 format"
        self.ISO3_BU = self.BU
        self.ISO2_BU = constants.ISO3_ISO2_MAPPING[self.ISO3_BU]

        #default values
        if 'CLUSTERING' in self.PIPELINE_STEPS:
            self.PIPELINE_STEPS['CLUSTERING']['OUTLIERS'] = self.PIPELINE_STEPS['CLUSTERING'].get('OUTLIERS') #None by default

        #putting PIPELINE_STEPS as attributes
        for step in self.PIPELINE_STEPS:
            self.__setattr__(step, PipelineArgs(self.PIPELINE_STEPS[step]))
        self.PIPELINE_STEPS = list(self.PIPELINE_STEPS) #only keeping keys    

        #setting dates with TRAIN or TEST dates
        self.ANALYSIS_DATES['CLUSTERING_TRAIN'] = self.ANALYSIS_DATES['TRAIN']
        self.ANALYSIS_DATES['CLUSTERING_TEST']  = self.ANALYSIS_DATES['TEST']
        self.ANALYSIS_DATES['THRESHOLDS_TRAIN'] = self.ANALYSIS_DATES['TRAIN']
        self.ANALYSIS_DATES['THRESHOLDS_TEST']  = self.ANALYSIS_DATES['TEST']
        
        for key in ['KPIS', 'ALERTING']:
            if key in self.PIPELINE_STEPS and not hasattr(self.__getattribute__(key), 'ANALYSIS_DATES'):
                print(f'\n\nWARNING "ANALYSIS_DATES" IS NOT SET UP for {key} !!')

        if 'KPIS' in self.PIPELINE_STEPS and hasattr(self.KPIS, "ANALYSIS_DATES"):
            assert self.KPIS.ANALYSIS_DATES in ['TRAIN', 'TEST']
            self.KPIS.ANALYSIS_DATES = self.ANALYSIS_DATES[self.KPIS.ANALYSIS_DATES]

        if 'ALERTING' in self.PIPELINE_STEPS and hasattr(self.ALERTING, "ANALYSIS_DATES"):
            assert self.ALERTING.ANALYSIS_DATES in ['TRAIN', 'TEST']
            self.ALERTING.ANALYSIS_DATES = self.ANALYSIS_DATES[self.ALERTING.ANALYSIS_DATES]
        
        self.setup_bucket_mapping()
        
    def _check_format(self, dic):
        #TODO : better validation of the dic inputs with a schema
        assert isinstance(dic['LOCAL_CURRENCY_RATE'], float)
        assert isinstance(dic['TRACKING'], bool)
        if 'DATA_SERIALIZATION' in dic['PIPELINE_STEPS']:
            assert isinstance(dic['PIPELINE_STEPS']['DATA_SERIALIZATION']['ALERTS_SERIALISATION'], bool)
            assert isinstance(dic['PIPELINE_STEPS']['DATA_SERIALIZATION']['TRANSACTIONS_SERIALISATION'], bool)
            assert isinstance(dic['PIPELINE_STEPS']['DATA_SERIALIZATION']['LOOKBACK_SUMS'], bool)
        
        if 'THRESHOLDS' in dic['PIPELINE_STEPS']:
            assert isinstance(dic['PIPELINE_STEPS']['THRESHOLDS']['L2_RECALL_TRAIN'], float)
            assert isinstance(dic['PIPELINE_STEPS']['THRESHOLDS']['L2_RECALL_TEST'], float)
        
    def setup_bucket_mapping(self):
        if self.BUCKET_MAPPING_MODE == "SIMPLE":
            self.BUCKETS = {
                "Cash": 'BNP-EFT-CSH-ALL-A-S01-EST',
                "Check": 'BNP-EFT-CHK-ALL-A-S01-EST',
                "Shared Transactions": 'BNP-EFT-SHT-ALL-A-S01-EST',
                "Domestic Transfer": 'BNP-EFT-DFT-ALL-A-S01-EST',
                "Cross Border": 'BNP-EFT-CFT-ALL-A-S01-EST',
            }

        elif self.BUCKET_MAPPING_MODE in 'ADVANCED':
            self.BUCKETS = {
                "Cash": 'BNP-EFT-CSH-ALL-A-S01-EST',
                "Check": 'BNP-EFT-SCH-ALL-A-S01-EST',
                "Shared Transactions": 'BNP-EFT-SHT-ALL-A-S01-EST',
                "Domestic Transfer": 'BNP-EFT-DFT-ALL-A-S01-EST',
                "Cross Border": 'BNP-EFT-CFT-ALL-A-S01-EST',
                "1 to 1 : Domestic credit": 'BNP-EFT-ODC-ALL-A-S01-EST',
                "1 to 1 : Domestic debit": 'BNP-EFT-ODD-ALL-A-S01-EST',
                "1 to 1 : Cross-border credits (LS, MS)": 'BNP-EFT-OCC-ALL-A-S01-EST',
                "1 to 1 : Cross-border debit (LS, MS)": 'BNP-EFT-OCD-ALL-A-S01-EST',
                "1 to 1 : Cross-border payment (HS/VHS/THV)": 'BNP-EFT-OCT-ALL-A-S01-EST',
                "1 to many : log 1 to many : up to 10^1 payments": 'BNP-EFT-A01-ALL-A-S01-EST',
                "1 to many : log 1 to many : between 10^1 and 10^2 payments": 'BNP-EFT-A12-ALL-A-S01-EST',
                "1 to many : log 1 to many : between 10^2 and 10^3 payments": 'BNP-EFT-A23-ALL-A-S01-EST',
                "1 to many : log 1 to many : 10^3 payments and more": 'BNP-EFT-A34-ALL-A-S01-EST',
            }
            
        else:
            raise Exception('BUCKET_MAPPING_MODE must be SIMPLE or ADVANCED')
        assert all(x in self.BUCKETS for x in ('Cash', 'Check', 'Shared Transactions')), "Buckets must include 'Cash', 'Check', 'Shared Transactions'"
        
        #constants
        for rule in self.BUCKETS:
            self.STANDARD_PERCENTILE[f'Excessive Single Transactions - {rule}']\
                = self.STANDARD_PERCENTILE["Excessive Single Transactions"]
            self.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW[f'Excessive Single Transactions - {rule}']\
                = self.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW["Excessive Single Transactions"]
            self.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE[f'Excessive Single Transactions - {rule}']\
                = self.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE["Excessive Single Transactions"]
            
        self.EFT_BUCKET_MIN_VALUE = {
            key: 1_000_000 for key in self.BUCKETS
        }
        self.EFT_BUCKET_MIN_VALUE['Cash'] = None
        self.EFT_BUCKET_MIN_VALUE['Check'] = None
            
        self.ALL_MODEL_FULL_NAMES = {
            'TSD': ['Transfer to/from High-Risk Countries (Level 3)', 'Transfer to/from Very High-Risk Countries (Level 4)'],
            'FTF': ['Flow Through of Funds (Credits / Debits)'],
            'STP': ['Structuring of Payments : Incoming', 'Structuring of Payments : Outgoing']
        }
        self.ALL_MODEL_FULL_NAMES['EFT'] = [
            'Excessive Single Transactions - ' + bucket for bucket in self.BUCKETS
        ]
        
        self.DEPLOYMENT_STATS_MODEL_MAPPING = {
            'BNP-TSD-EFT-ALL-A-S01-HRC': '01 - TSD3',
            'BNP-TSD-EFT-ALL-A-S01-VRC': '01 - TSD4',
            'BNP-TSD-EFT-ALL-A-S01-THV': '02 - THV',
            'BNP-THV-EFT-ALL-A-S01-THV': '02 - THV',
            'BNP-SCT-RSK-ACT-P-D01-EAT': '03 - SCT',
            'BNP-EFT-TRN-ALL-A-S01-EST': '04 - EFT',
            'BNP-NBI-TRN-ALL-A-DXX-NBI': '05 - NBI',
            'BNP-HBC-TRN-INN-A-M01-HBN': '09 - HBC',
            'BNP-HBC-TRN-OUT-A-M01-HBN': '09 - HBC',
            'BNP-HBC-TRN-INN-A-M01-HBS': '09 - HBC',
            'BNP-HBC-TRN-OUT-A-M01-HBS': '09 - HBC',
            'AML-SBP-ALL-ALL-PG-M01-SBP': '09 - SBP',
            'BNP-FTF-TRN-ALL-A-B02-FTR': '10 - FTF',
            'BNP-STP-EFT-INN-A-DXX-TRD': '11 - STP / STP',
            'BNP-STP-EFT-OUT-A-DXX-TRD': '11 - STP / STP',
            'BNP-STP-EFT-INN-A-DXX-SCT': '11 - STP / SCT',
            'BNP-STP-EFT-OUT-A-DXX-SCT': '11 - STP / SCT',
            'BNP-ADR-TRN-ALL-A-M07-AIN': '12 - ADR / Account',
            'BNP-ADR-TRN-ALL-P-M07-AIN': '12 - ADR / Party',
            'BNP-EPC-TRN-INN-D01-A-EPB': '13 - EPC',
            'BNP-EPC-TRN-OUT-D01-A-EPB': '13 - EPC',   
        }
        for bucket, rule in self.BUCKETS.items():
            self.DEPLOYMENT_STATS_MODEL_MAPPING[rule] = f'04 - EFT - {bucket}'
            
            
        self.RULE_ID_SUBMODEL_MAP = {
            'BNP-TSD-EFT-ALL-A-S01-HRC': 'Transfer to/from High-Risk Countries (Level 3)',
            'BNP-TSD-EFT-ALL-A-S01-VRC': 'Transfer to/from Very High-Risk Countries (Level 4)',
            'BNP-THV-EFT-ALL-A-S01-THV': 'Transfer to/from Tax Haven Countries',
            'BNP-THV-EFT-ALL-A-S01-LTH': 'Transfer to/from Local Tax Haven Countries',
            'BNP-FTF-TRN-ALL-A-B02-FTR': 'Flow Through of Funds (Credits / Debits)',
            'BNP-STP-EFT-INN-A-DXX-TRD': 'Structuring of Payments : Incoming',
            'BNP-STP-EFT-OUT-A-DXX-TRD': 'Structuring of Payments : Outgoing',
            'BNP-EFT-TRN-ALL-A-S01-EST': 'Excessive Single Transactions',
            'BNP-SCT-RSK-ACT-P-D01-EAT': 'Excessive Single Transactions'
        }
        for bucket, rule in self.BUCKETS.items():
            self.RULE_ID_SUBMODEL_MAP[rule] = 'Excessive Single Transactions - ' + bucket
        self.SUBMODEL_RULE_ID_MAP = {v: k for k, v in self.RULE_ID_SUBMODEL_MAP.items()}
        

    @classmethod
    def from_file(cls, path, experiment_parameters):
        with open(path) as f:
            global_parameters = json.load(f)
        return cls(global_parameters, experiment_parameters)

    def __repr__(self):
        return str(self.PIPELINE_STEPS)
    
    def __iter__(self):
        """So that we can use the "in" method"""
        return iter(self.PIPELINE_STEPS)