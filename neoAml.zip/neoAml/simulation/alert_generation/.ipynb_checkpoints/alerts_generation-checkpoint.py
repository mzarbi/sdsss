import os
import numpy as np
import pandas as pd
from tqdm import tqdm
import pyarrow
import pyarrow.parquet as pq
import pycountry as pc

from ..actimize import SUBMODEL_MAP, ExcessiveFundsTransfers, TransfersSensitiveDestinations, FlowThroughFunds
from ..utils import constants

from ..utils.serialization import load_parameters, load_pickle_file
from ..utils.utils import lookup, filter_transactions
from ..utils.parquet import ParquetStreamer, update_field_name, update_field_type, get_transactions_by_chunk

tqdm.pandas()

def update_thresholds(parameters, thresholds, model):
    ''' Add specific computed thresholds to base thresholds if defined in input key
    
    Parameters
    ----------
    thresholds: dict
        Values of base thresholds
    model: str
        Name of model for which specified thresholds are to be loaded
    
    Returns
    -------
    dict updated with computed thresholds
    '''
    if parameters.ALERTING.THRESHOLDS is None:
        return thresholds

    reviewed_thresholds_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'thresholds',
        '{}_{}_{}.pickle'.format(
            model, parameters.BU, 
            parameters.ALERTING.THRESHOLDS
        )
    )

    if not os.path.isfile(reviewed_thresholds_file):
        constants.LOGGER.info('Cannot find reviewed thresholds file {}, default parameters used'.format(
            reviewed_thresholds_file
        ))

    reviewed_thresholds = load_pickle_file(
        reviewed_thresholds_file
    )

    for key in ['cluster', 'individual', 'cluster_score', 'individual_score']:
        if key in reviewed_thresholds:
            if key not in thresholds \
               or thresholds[key] is None:
                thresholds[key] = {}
            if model in reviewed_thresholds[key]:
                thresholds[key][model] = \
                    reviewed_thresholds[key][model]
        else:
            thresholds[key] = {}

    return thresholds

                
def compute_EFT_hits(parameters, postings):
    ''' Generate the hits for the EFT model based on postings data and threshold mapping
    
    Parameters
    ----------
    postings: pandas dataframe
        Postings data
        
    Returns
    -------
    EFT_hits: pandas dataframe
        Hits for the EFT model
    '''
    thresholds = load_parameters(parameters.BU, parameters.ALERTING.PARAMETERS)
    thresholds = update_thresholds(parameters, thresholds, 'EFT')
        
    postings = postings.groupby("POS_ID")\
                       .first()\
                       .reset_index(drop=False)
    
    eft_model = ExcessiveFundsTransfers(
        threshold_mapping=thresholds,
        version=parameters.MODEL_VERSION
    )
    EFT_hits = eft_model(parameters, postings)
    return EFT_hits


def custom_country_code(payments, thresholds, iso3_bu, risks):
    # FOR LTH: can add to other lists
    if 'tsd_country' not in thresholds or payments.empty:
        return
    
    def get_country_risk(country, date, thresholds, iso3_bu, risks):
        if country not in thresholds or country == iso3_bu:
            return 1
        for risk, dates in thresholds[country].items():
            if 'EXPIRATION_DATE' in dates:
                if date < dates['EXPIRATION_DATE'] and date >= dates['EFFECTIVE_DATE'] and risk in risks:
                    return risk
                continue
            if date >= dates['EFFECTIVE_DATE'] and risk in risks:
                return risk
        return 1

    assert len(iso3_bu) == 3, "we need ISO3 formats"
    col = payments.apply(
        lambda x: get_country_risk(
            x.OPP_COUNTRY_CD,
            x.VALUE_DATETIME,
            thresholds['tsd_country'],
            iso3_bu,
            risks
        ), axis=1
    )

    payments[constants.TSD_COUNTRY_KEY] = col


def compute_TSD_hits(parameters, payments):
    ''' Generate the hits for the TSD model based on payments data
    
    Parameters
    ----------
    payments: pandas dataframe
        Payments data
        
    Returns
    -------
    TSD_hits: pandas dataframe
        Hits for the TSD model
    '''
    thresholds = load_parameters(parameters.BU, parameters.ALERTING.PARAMETERS)
    thresholds = update_thresholds(parameters, thresholds, 'TSD')

    tsd_model = TransfersSensitiveDestinations(
        threshold_mapping=thresholds,
        version=parameters.MODEL_VERSION
    )

    tsd_risks = [3, 4]

    #custom_country_code(payments, thresholds, business_unit, tsd_risks)
    tsd_payments = payments[payments[constants.TSD_COUNTRY_KEY].isin(tsd_risks)]

    TSD_hits = tsd_model(parameters, tsd_payments)
    return TSD_hits


def compute_THV_hits(parameters, payments):
    ''' Generate the hits for the THV model based on payments data
    
    Parameters
    ----------
    payments: pandas dataframe
        Payments data
        
    Returns
    -------
    THV_hits: pandas dataframe
        Hits for the THV model
    '''
    thresholds = load_pickle_file(
        os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU,
            'thresholds/thresholds_{}_{}.pickle'.format(
                parameters.BU, parameters.ALERTING.PARAMETERS
            )
        )
    )

    thv_model = TransfersSensitiveDestinations(
        threshold_mapping=thresholds,
        version=parameters.MODEL_VERSION,
        model='THV'
    )

    max_thv_alert_id = -1
    thv_risks = [5]
    #custom_country_code(payments, thresholds['SAM3'][business_unit], business_unit, thv_risks)
    thv_payments = payments[payments[constants.TSD_COUNTRY_KEY].isin(thv_risks)]
    THV_hits_thv = thv_model(parameters, thv_payments)
    if not THV_hits_thv.empty:
        max_thv_alert_id = max(THV_hits_thv.ALERT_ID)

    lth_risks = [6]
    #custom_country_code(payments, thresholds['SAM3'][business_unit], business_unit, lth_risks)
    lth_payments = payments[payments[constants.TSD_COUNTRY_KEY].isin(lth_risks)]
    THV_hits_lth = thv_model(parameters, lth_payments)
    if not THV_hits_lth.empty:
        THV_hits_lth.ALERT_ID = THV_hits_lth.ALERT_ID + max_thv_alert_id + 1
    
    return pd.concat([THV_hits_thv, THV_hits_lth], axis=0, ignore_index=True)


def compute_FTF_hits(parameters, postings):
    ''' Generate the hits for the FTF model based on payments data
    
    Parameters
    ----------
    postings: pandas dataframe
        Payments data
        
    Returns
    -------
    FTF_hits: pandas dataframe
        Hits for the TSD model
    '''
    postings = postings.groupby("POS_ID")\
                       .first()\
                       .reset_index(drop=False)
    thresholds = load_parameters(parameters.BU, parameters.ALERTING.PARAMETERS)
    thresholds = update_thresholds(parameters, thresholds, 'FTF')
    ftf_model = FlowThroughFunds(
        threshold_mapping=thresholds,
        version=parameters.MODEL_VERSION,
        lookback_sums=parameters.LOOKBACK_SUMS
    )
    FTF_hits = ftf_model(parameters, postings)
    return FTF_hits


def get_alert_score(account_num, amount, cluster, model, submodel, params, transaction_type=None):
    ''' Get score for one hit from score parameters
    Parameters
    ----------
    account_num: str
    account number
    
    amount: float
    amount of the transaction(s)
    
    cluster: str
    cluster id
    
    model: str
    model id
    
    submodel: str
    submodel, eg 'Excessive Single Transactions'
    
    params: dict
    score parameters
    
    transactions_type: str
    id of transaction_type for EFT bucket; eg: Cross Border, Shared ...
    
    Returns
    -------
    int: score associated to the hit
    '''
    score_name = constants.MODEL_SCORE_NAME[model]
    if params['individual_score'] is not None and model in params['individual_score']:
        if submodel in params['individual_score'][model]:
            if score_name in params['individual_score'][model][submodel]:
                if transaction_type in params['individual_score'][model][submodel][score_name]:
                    if account_num in params['individual_score'][model][submodel][score_name][transaction_type]:
                        return get_score_from_scale(
                            amount,
                            params['individual_score'][model][submodel][score_name][transaction_type][account_num]
                        )
                if account_num in params['individual_score'][model][submodel][score_name]:
                    return get_score_from_scale(
                        amount,
                        params['individual_score'][model][submodel][score_name][account_num]
                    )

    if model in params['cluster_score']:
        if submodel in params['cluster_score'][model]:
            if score_name in params['cluster_score'][model][submodel]:
                if model == "EFT":
                    if transaction_type in params['cluster_score'][model][submodel][score_name]:
                        if cluster in params['cluster_score'][model][submodel][score_name][transaction_type]:
                            return get_score_from_scale(
                                amount,
                                params['cluster_score'][model][submodel][score_name][transaction_type][cluster]
                            )
                    if cluster in params['cluster_score'][model][submodel][score_name]:
                        return get_score_from_scale(
                            amount,
                            params['cluster_score'][model][submodel][score_name][cluster]
                        )
                if cluster in params['cluster_score'][model][submodel][score_name]:
                    return get_score_from_scale(
                        amount,
                        params['cluster_score'][model][submodel][score_name][cluster]
                    )
    
    if model in params['user_score']:
        if score_name in params['user_score'][model][submodel]:
            if isinstance(params['user_score'][model][submodel][score_name], dict):
                if transaction_type in params['user_score'][model][submodel][score_name]:
                    return get_score_from_scale(
                        amount,
                        params['user_score'][model][submodel][score_name][transaction_type]
                    )
            return get_score_from_scale(
                amount,
                params['user_score'][model][submodel][score_name]
            )

def get_score_from_scale(value, scale):
    '''
    Get score for some observable based on an actimize scale
    Scale is given by a (potentially non-ordered) dict
    
    Parameters
    ----------
    value: double
    observable compared to the scale
    
    scale: dict
    actimize scale of scores
    
    Returns
    -------
    int: score associated to the observable
    '''
    res = 0
    for threshold, score in scale.items():
        if value >= threshold  and res < score:
            res = score
    return res
        

def recurrence_scale_score(params, submodel, transaction_type, count):
    '''
    Get score from recurrence scale
    
    Parameters
    ----------
    params: dict
    Score parameters
    
    submodels: str
    Name of submodels as string in the consolidated alert
    
    transaction_types: list
    transaction type as string in the consolidated alert
    
    Return score from recurrence scale
    '''
    model = constants.SUBMODEL_MODEL_MAP[submodel]
    if "Recurrence" not in params['user_score'][model][submodel]:
        return 0
    
    if model == "EFT" and transaction_type in params['user_score'][model][submodel]['Recurrence']:
        return get_score_from_scale(
                count,
                params['user_score'][model][submodel]['Recurrence'][transaction_type]
            )
    else:
        return  get_score_from_scale(
            count,
            params['user_score'][model][submodel]['Recurrence']
        )

    
def agg_truth_alerts(parameters):
    all_alerts = []
    all_agged_alerts = []
    if not hasattr(parameters.ALERTING, 'PROD_ALERTS'):
        return None
    
    for model in parameters.ALERTING.PROD_ALERTS:
        alerts = pd.read_parquet(
            os.path.join(
                constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts',
                '{}_{}_{}.parquet'.format(model, parameters.BU, parameters.ALERTING.PROD_ALERTS_KEY)
            )
        )

        if alerts.empty:
            continue

        alerts['VALUE_DATETIME'] = lookup(alerts['ALERT_DATE'], '%Y%m%d')
        if constants.TRANS_DATE_KEY not in alerts.columns:
            alerts.rename(columns={'ALERT_DATE': constants.TRANS_DATE_KEY}, inplace=True)
        alerts['ALERT_ID'] = 'TRUTH_' + alerts['ALERT_ID']
        all_alerts += [alerts]

        alerts = filter_transactions(alerts, parameters.ALERTING.ANALYSIS_DATES)

        alerts = alerts.groupby(['RULE_ID', 'ALERT_ID']) \
                       .agg({
            constants.PARTY_KEY: 'first',
            'SCORE': 'first',
            'VALUE_DATETIME': 'max'
        }).reset_index(drop=False)
        
        alerts['ALERT_ID'] = alerts['ALERT_ID'].values[:, None].tolist()
        alerts['MODEL'] = model
        alerts['SUBMODEL'] = alerts['RULE_ID']
        #alerts['transaction_type'] = ''

        all_agged_alerts += [alerts]

    return pd.concat(all_agged_alerts, axis=0), pd.concat(all_alerts, axis=0, ignore_index=True)


def agg_model_score(grouped_alerts, thresholds):
    # Take max score of hits agg'ed by submodel and account
    grouped_alerts = grouped_alerts.groupby(['ACCOUNT_KEY', 'RULE_ID', "VALUE_DATETIME"]) \
                                   .agg({
        "SCORE": max,
        "transaction_type": "first",
        "SUBMODEL": "first",
        "ALERT_ID": list,
        "SUM_OCCURRENCES": "first",
        "MODEL": "first",
        constants.PARTY_KEY: "first"
    }).reset_index(drop=False)

    # Sum recurrence score to hits agg'ed by submodel and account
    grouped_alerts["SCORE"] += grouped_alerts.apply(
        lambda x: recurrence_scale_score(
            thresholds,
            x["SUBMODEL"],
            x["transaction_type"],
            x["SUM_OCCURRENCES"]
        ), axis=1
    )

    # Take max score of accounts alerts per submodel
    grouped_alerts = grouped_alerts.groupby([constants.PARTY_KEY, 'RULE_ID', "VALUE_DATETIME"]) \
                                   .agg({
        "SCORE": max,
        "ALERT_ID": (lambda x: sum(list(x),[])),
        "SUBMODEL": "first",
        "MODEL": "first"
    }).reset_index(drop=False)

    return grouped_alerts


def consolidate_alerts(alerts, all_alerts_groups, inputfile, all_model=False):
    alerts = alerts.merge(
        all_alerts_groups[['ALERT_ID', 'GLOBAL_ALERT_ID']].drop_duplicates(),
        on='ALERT_ID', how='left'
    )
    
    alerts = alerts[
        (alerts["GLOBAL_ALERT_ID"] > 0) \
        | (alerts["ALERT_ID"].str.startswith('TRUTH'))
    ].reset_index(drop=True)
    if all_model:
        alerts["GLOBAL_ALERT_ID"] = np.where(
            alerts["ALERT_ID"].str.startswith('TRUTH') \
                & ~(alerts["GLOBAL_ALERT_ID"] > 0),
            alerts["ALERT_ID"], alerts["GLOBAL_ALERT_ID"]
        )
    alerts = alerts.drop("ALERT_ID", axis=1) \
        .rename(columns={"GLOBAL_ALERT_ID": "ALERT_ID"})            
    alerts["ALERT_ID"] = alerts["ALERT_ID"].astype(str)
    
    if not all_model:
        schema = pq.read_schema(inputfile)
    else:
        schema = pyarrow.schema([
            pyarrow.field(field, pyarrow.string()) for field in [
                constants.PARTY_KEY, 'ACCOUNT_KEY', 'TRANSACTION_KEY', constants.TRANS_DATE_KEY,
                'ALERT_ID', 'RULE_ID', "CRDS_CODE"
            ]
        ])
        alerts[constants.TRANS_DATE_KEY] = alerts[constants.TRANS_DATE_KEY].astype(str)

    writer = ParquetStreamer(
        inputfile,
        schema
    )
    writer.write(alerts)
    writer.writer.close()


def compute_scores(parameters):
    '''Consolidate hits to alerts from generated parquet alert files
    '''

    generated_alert_cols = [
        constants.PARTY_KEY, 'TRANSACTION_KEY', 'ACCOUNT_KEY',
        constants.TRANS_DATE_KEY,'ALERT_ID', 'RULE_ID', 'CRDS_CODE'
    ]
    
    thresholds = load_parameters(parameters.BU, parameters.ALERTING.PARAMETERS)
    GENERATED_ALERT_PATH = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts'
    )
    os.makedirs(GENERATED_ALERT_PATH, exist_ok=True)
    
    inputfiles = {}
    alerts = {}
    all_ungrouped_alerts = []
    all_alerts = []
    for model in parameters.LIST_MODEL:
        if model != 'THV':
            # Update the thresholds with computed ones for the model
            thresholds = update_thresholds(parameters, thresholds, model)

        # Load hits from parquet file
        inputfiles[model] = os.path.join(
            GENERATED_ALERT_PATH,
            '{}_{}_{}.parquet'.format(
                model, parameters.BU, parameters.EXPERIMENT_KEY
            )
        )
        alerts[model] = pd.read_parquet(inputfiles[model])
        if alerts[model].empty:
            continue

        alerts[model]['VALUE_DATETIME'] = lookup(alerts[model][constants.TRANS_DATE_KEY], '%Y%m%d')

        alerts[model]["ALERT_ID"] = \
            alerts[model]["ALERT_ID"].astype(str) + "_" + model
        alerts[model]["MODEL"] = model
        SUBMODEL_MAP[model](parameters, alerts[model])
        
        alerts[model]['RULE_ID'] = alerts[model]['SUBMODEL']
        if model == "EFT":
            alerts[model]['RULE_ID'] = alerts[model]['RULE_ID'] + ' - ' + alerts[model]["transaction_type"]
        alerts[model]['RULE_ID'] = alerts[model]["RULE_ID"].map(parameters.SUBMODEL_RULE_ID_MAP)
        
        all_ungrouped_alerts += [alerts[model][generated_alert_cols]]
    
        if "transaction_type" not in alerts[model].columns:
            alerts[model]["transaction_type"] = ""

        # Agg hits with same ALERT_ID (for FTF typically), and list their transaction key
        agg_functions = {
            constants.PARTY_KEY: "first",
            "ACCOUNT_KEY": "first",
            constants.CLUSTER_KEY: "first",
            constants.MODEL_TRANSACTION_KEY[model]: list,
            constants.MAIN_AMNT_KEY: "first",
            "VALUE_DATETIME": max,
            "transaction_type": "first",
            "SUM_OCCURRENCES": "first",
            "RULE_ID": "first",
            "SUBMODEL": "first"
        }
        if constants.TSD_COUNTRY_KEY in alerts[model].columns:
            agg_functions[constants.TSD_COUNTRY_KEY] = "first"
        if model == "FTF":
            agg_functions["SUM_INCOMING"] = "first"
            
        grouped_alerts = alerts[model].groupby(['ALERT_ID'])\
                                        .agg(agg_functions)\
                                        .reset_index(drop=False)                

        # Tag model, submodels and rule_id (eg: excessive Single Transaction - Cash)
        grouped_alerts["MODEL"] = model
        if model == "FTF":
            grouped_alerts[constants.MAIN_AMNT_KEY] = grouped_alerts["SUM_INCOMING"]
        
        # Compute score associated to each hit
        grouped_alerts['SCORE'] = grouped_alerts.apply(
            lambda x: get_alert_score(
                x.ACCOUNT_KEY,
                x[constants.MAIN_AMNT_KEY],
                x[constants.CLUSTER_KEY],
                model,
                x.SUBMODEL,
                thresholds,
                x['transaction_type']
            ), axis=1
        )

        all_alerts += [
            agg_model_score(grouped_alerts, thresholds)
        ]
        
    # Concat all hits between different models
    if not all_alerts:
        return

    other_truth_alerts, other_ungrouped_truth_alerts = agg_truth_alerts(parameters)
    if other_truth_alerts is not None:
        all_alerts += [other_truth_alerts]        
    all_alerts = pd.concat(all_alerts, axis=0)
    
    if other_ungrouped_truth_alerts is not None:
        all_ungrouped_alerts += [other_ungrouped_truth_alerts[generated_alert_cols]]
    all_ungrouped_alerts = pd.concat(all_ungrouped_alerts, axis=0, ignore_index=True)
    
    # Consolidate alerts on a daily and party basis (V8; in V3 on ACCOUNT_KEY) 
    all_alerts_groups = all_alerts.groupby([constants.PARTY_KEY, "VALUE_DATETIME"])\
                                    .agg({
        "SCORE": sum,
        "ALERT_ID": (lambda x: sum(list(x),[])),
        "SUBMODEL": list
    }).reset_index(drop=False)

    # Filter alerts with score > 40
    all_alerts_groups = all_alerts_groups[
        all_alerts_groups["SCORE"] >= 40
    ].reset_index(drop=False).rename(columns={"index": "GLOBAL_ALERT_ID"})
            
    # Label consolidated alerts with a new global alert ids
    all_alerts_groups["GLOBAL_ALERT_ID"] = 1 + all_alerts_groups["GLOBAL_ALERT_ID"]

    # Get a dataframe with mapping between global alert ids and model alert ids
    all_alerts_groups = all_alerts_groups.explode("ALERT_ID").reset_index(drop=True)

    # Filter consolidated alerts per model and write to parquet files
    for model in parameters.LIST_MODEL:
        if alerts[model].empty:
            continue
            
        consolidate_alerts(alerts[model], all_alerts_groups, inputfiles[model])

    inputfile_all = os.path.join(
        GENERATED_ALERT_PATH,
        'ALL_{}_{}.parquet'.format(
            parameters.BU, parameters.EXPERIMENT_KEY
        )
    )
    consolidate_alerts(all_ungrouped_alerts, all_alerts_groups, inputfile_all, all_model=True)


def generate_alerts(parameters):
    ''' Generation of hits for the different cases (base case, with review of monitoring scope, 
    with review of thresholds or with review of monitoring scope + thresholds). Hits are
    generated for the different and different models.
    '''

    ALERT_FUNCTIONS = {
        "EFT": compute_EFT_hits,
        "FTF": compute_FTF_hits,
        "TSD": compute_TSD_hits,
        "THV": compute_THV_hits
    }

    constants.LOGGER.info(f'Start alerts generation process for BU {parameters.BU}')
    GENERATED_ALERT_PATH = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts'
    )
    os.makedirs(GENERATED_ALERT_PATH, exist_ok=True)
    
    for model in parameters.LIST_MODEL:

        inputfile = os.path.join(
            constants.READ_WRITE_DATA_PATH, parameters.BU, 'processed',
            'CTP_{}_{}_{}.parquet'.format(
                parameters.BU,
                constants.TRANSACTION_TYPE_PER_MODEL[model],
                parameters.ALERTING.TRANSACTIONS
            )
        )
        outputfile = os.path.join(
            GENERATED_ALERT_PATH,
            '{}_{}_{}.parquet'.format(
                model, parameters.BU, parameters.EXPERIMENT_KEY
            )
        )
        schema = pq.read_schema(inputfile)\
                    .append(pyarrow.field(f'{model}_Hit', pyarrow.bool_()))\
                    .append(pyarrow.field('ALERT_ID', pyarrow.string()))
        schema = update_field_name(schema, 'CLIENTNUM', constants.PARTY_KEY)
        schema = update_field_type(schema, constants.CLUSTER_KEY, pyarrow.string())
        schema = update_field_type(
            schema, constants.MODEL_TRANSACTION_KEY[model], pyarrow.string()
        )
        schema = schema.append(pyarrow.field("SUM_OCCURRENCES", pyarrow.int32()))
        if model == "FTF":
            schema = schema.append(pyarrow.field("SUM_INCOMING", pyarrow.float64()))
            if parameters.ALERTING.LOOKBACK_SUMS != None:
                input_lookback = os.path.join(
                    constants.READ_WRITE_DATA_PATH, parameters.BU, 'processed',
                    'FTF_lookback_sums_{}_{}.parquet'.format(
                        parameters.BU,
                        parameters.ALERTING.LOOKBACK_SUMS
                    )
                )
                lookback_sums = filter_transactions(
                    pd.read_parquet(input_lookback), parameters.ALERTING.ANALYSIS_DATES
                )
                lookback_sums['POS_ID'] = lookback_sums['POS_ID'].apply(list)
                parameters.LOOKBACK_SUMS = lookback_sums
            else:
                parameters.LOOKBACK_SUMS = None
            
        writer = ParquetStreamer(
            outputfile, 
            schema
        )
        
        constants.LOGGER.info(
            'Processing raw {} for BU {}'.format(
                constants.TRANSACTION_TYPE_PER_MODEL[model], parameters.BU
            )
        )
        
        ichunk = 0
        for chunk in tqdm(get_transactions_by_chunk(inputfile)):
            chunk = filter_transactions(chunk, parameters.ALERTING.ANALYSIS_DATES)
            if chunk.empty:
                continue
            chunk[constants.CLUSTER_KEY] = chunk[constants.CLUSTER_KEY].astype(str)
            if 'VALUE_DATETIME' not in chunk.columns:
                chunk["VALUE_DATETIME"] = lookup(
                    chunk[constants.TRANS_DATE_KEY], '%Y%m%d'
                )
            res = ALERT_FUNCTIONS[model](parameters, chunk)
            
            if not res.empty:
                res['ALERT_ID'] = res['ALERT_ID'].astype(str) + "_chunk" + str(ichunk)
                res = res.rename(columns={"CLIENTNUM": constants.PARTY_KEY})
                writer.write(res)

            ichunk += 1
        writer.writer.close()
    
    if constants.KPIS_BASE == "ALERTS":
        compute_scores(parameters)