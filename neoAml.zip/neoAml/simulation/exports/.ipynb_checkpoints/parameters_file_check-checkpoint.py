from openpyxl import load_workbook
import copy
import pandas as pd
import math
import os
import numpy as np

from ..utils import constants
from ..utils.utils import get_accounts


def load_parameters_file(file):
    workbook = load_workbook(file)
    data = {}

    for sheet_name in workbook.sheetnames :    
        cols = [x[0].value for x in workbook[sheet_name].columns]
        data[sheet_name] = pd.DataFrame(workbook[sheet_name].values,columns=cols)  
        data[sheet_name].drop(0,inplace=True)
        data[sheet_name].dropna(axis=1,how='all',inplace=True)
        data[sheet_name].dropna(axis=0,how='all',inplace=True)
        data[sheet_name].astype('string')
        data[sheet_name] = data[sheet_name].fillna(np.nan)
    return data

def load_accounts_file(business_unit):
    accounts_dir = os.path.join(constants.READ_ONLY_DATA_PATH, business_unit, 'Accounts')
    accounts_file = None
    for file in os.listdir(accounts_dir):
        if file.endswith('.csv'):
            accounts_file = os.path.join(accounts_dir, file)
    return pd.read_csv(accounts_file, sep=';')


def load_clusters_file(nameclusters):
    cluster_mapping = pd.read_excel(nameclusters)
    C = ['CLUA000','CLUA001','CLUA002','CLUA003']
    L = [2, 0, 1, 2]
    cluster_mapping['CLUSTER_ID'] = 'CLUA' \
    + cluster_mapping['CLUSTER_ID'].astype(str).str.zfill(3)

    return dict(zip(
        C + list(cluster_mapping['CLUSTER_ID']),
        L + list(cluster_mapping['RISK_LEVEL'])
    ))


def check_duplicates(OUTPUT_STREAM, test_data):
    for k in test_data.keys():
        duplicated = test_data[k][test_data[k].duplicated(keep=False) ]
        if len(duplicated)!=0:
            OUTPUT_STREAM.write(
                f'Check duplicates: In the sheet {k} the duplicated rows are\n{duplicated}\n\n'
            )
        

def check_country_name(parameters, OUTPUT_STREAM, test_data):
    tenant_id = [
        'Tenant Thresholds','Population Thresholds','Individual Thresholds',
        'Tenant Scores','Population Scores','Individual Scores','Lists'
    ]
    tenant_cd = ['Lists-TSD THV LTH', 'SBP - Event Thresholds', 'SBP - SB Thresholds']
    region_cd = [
        'Tenant Thresholds', 'Population Thresholds', 'Tenant Scores','Population Scores',
        'Lists', 'Lists-TSD THV LTH','SBP - Event Thresholds', 'SBP - SB Thresholds'
    ]
    region = parameters.BU + '_R'
    for k in tenant_id:
        if len(test_data[k]) == 0:
            continue
        if sum(test_data[k]['TENANT_ID'] == parameters.BU) != len(test_data[k]['TENANT_ID']):
            OUTPUT_STREAM.write(
                f'Check Country names : The TENANT_ID is not correct in sheet {k}\n\n'
            )
    for k in region_cd:  
        if len(test_data[k]) == 0:
            continue
        if sum(test_data[k]['REGION_CD'] == region)!=len(test_data[k]['REGION_CD']):
            OUTPUT_STREAM.write(
                f'Check Country names : The REGION_CD is not correct in sheet {k}\n\n'
            )
    for k in tenant_cd:        
        if len(test_data[k]) == 0:
            continue
        if sum(test_data[k]['TENANT_CD'] == parameters.BU)!= len(test_data[k]['TENANT_CD']):
            OUTPUT_STREAM.write(
                f'Check Country names : The TENANT_CD is not correct in sheet {k}\n\n'
            )
 
            
def check_missing_clusters(OUTPUT_STREAM, test_data, clusters):
    list_clusters = list(clusters.keys())
    for sheet in ['Population Thresholds', 'Population Scores']:
        population = test_data[sheet]
        for rule in population['RULE_ID'].unique():
            C_file = population[population['RULE_ID']==rule]['POPULATION_GROUP_ID'].unique()
            Missing_clusters=[k for k in list_clusters if k not in C_file]
            if Missing_clusters!= []:
                OUTPUT_STREAM.write(
                    f"Check Missing clusters: The clusters {Missing_clusters} \
                    are missing in the sheet {sheet} for the rule {rule}\n\n"
                )
    for sheet in ['SBP - Event Thresholds', 'SBP - SB Thresholds']:
        C_file = test_data[sheet]['POPULATION_GROUP_CD'].unique()
        Missing_clusters=[
            k for k in list_clusters if k.replace('CLUA', 'CLUP') not in C_file
        ]
        if Missing_clusters != []:
            OUTPUT_STREAM.write(
                f"Check Missing clusters: The clusters {Missing_clusters} \
                are missing in the sheet {sheet}\n\n"
            )


def stringify_column(col):
    col.loc[col == "N/A"] = "nan"
    if col.dtype == float:
        col = col.apply(lambda x: int(x) if math.isfinite(x) else np.nan)
        col = col.astype(str)
    if col.dtype == int:
        col = col.astype(str)

            
def check_default_values(OUTPUT_STREAM, ref_data, test_data):    
    for sheet, pivots in constants.BASE_PARAMETERS_SHEET_NAMES.items():
        ref = copy.deepcopy(ref_data[sheet])
        test = copy.deepcopy(test_data[sheet])
        if sheet in ['Population Thresholds', 'Population Scores']:
            ref = ref[ref['POPULATION_GROUP_ID'] == 'CLUA000']
            test = test[test['POPULATION_GROUP_ID'] == 'CLUA000']
        for pivot in pivots:
            ref[pivot] = stringify_column(ref[pivot])
            test[pivot] = stringify_column(test[pivot])
        ref = ref.merge(test, how='outer', on=pivots)

        to_check = None
        for param in constants.TO_VALIDATE_PARAMETERS_SHEET_NAMES[sheet]:
            if to_check is None:
                to_check = ref[param + '_y'].isna()
            else:
                to_check = to_check & ref[param + '_y'].isna()        
        missing_lines = ref[to_check]
        if len(missing_lines) > 0:
            OUTPUT_STREAM.write(
                f'Check default values: Missing data on reference lines\n{missing_lines}\n\n'
            )

        to_check = None
        for param in constants.TO_VALIDATE_PARAMETERS_SHEET_NAMES[sheet]:
            if to_check is None:
                to_check = ref[param + '_x'].isna()
            else:
                to_check = to_check & ref[param + '_x'].isna()        
        new_lines = ref[to_check]
        if len(new_lines) > 0:
            OUTPUT_STREAM.write(
                f'Check default values: New lines appearing\n{missing_lines}\n\n'
            )

        for param in constants.TO_VALIDATE_PARAMETERS_SHEET_NAMES[sheet]:
            ref[param + '_x'] = stringify_column(ref[param + '_x'])
            ref[param + '_y'] = stringify_column(ref[param + '_y'])
            diff = ref[
                (ref[param + '_x'] != ref[param + '_y']) \
                & ~(ref[param + '_y'].isna()) \
                & ~(ref[param + '_x'].isna())
            ]
            if len(diff) > 0:
                OUTPUT_STREAM.write(
                    f'Check default values: Not identical default values for parameter \
                    {param} at lines \n {diff[[param + "_x", param + "_y"]]}\n\n'
                )

                
def check_null_thresholds(OUTPUT_STREAM, test_data):
    null_values = test_data['Population Thresholds'][
        (test_data['Population Thresholds']['THRESHOLD_VALUE'].isnull())
    ]
    if len(null_values) > 0:
        OUTPUT_STREAM.write(
            f'Check null thresholds: Has null thresholds at lines\n{null_values}\n\n'
        )

        
def check_tsd_thresholds(OUTPUT_STREAM, test_data, clusters):
    list_clusters = list(clusters.keys())
    Tenant = copy.deepcopy(test_data['Tenant Thresholds'])
    population = copy.deepcopy(test_data['Population Thresholds'])
    TSD3 = Tenant[Tenant['RULE_ID'] == 'BNP-TSD-EFT-ALL-A-S01-HRC']
    TSD4 = Tenant[Tenant['RULE_ID'] == 'BNP-TSD-EFT-ALL-A-S01-VRC']
    min_trans_val_TSD3 = int(
        TSD3[TSD3['THRESHOLD_NAME'] == 'Minimal Transaction Value']['THRESHOLD_VALUE'].values[0]
    )
    min_trans_val_TSD4 = int(
        TSD4[TSD4['THRESHOLD_NAME'] == 'Minimal Transaction Value']['THRESHOLD_VALUE'].values[0]
    )
    if (min_trans_val_TSD4 > min_trans_val_TSD3): 
        OUTPUT_STREAM.write(
            'Check TSD thresholds : tenant threshold for TSD 4 is higher than tenant threshold for TSD 3\n\n'
        ) 
    if min_trans_val_TSD3 > 1_000_000:
        OUTPUT_STREAM.write(
            'Check TSD thresholds : tenant threshold for TSD 3 is higher than one million\n\n'
        )

    for c in list_clusters:
        Cluster = population[population['POPULATION_GROUP_ID'] == c]
        TSD3 = Cluster[Cluster['RULE_ID'] == 'BNP-TSD-EFT-ALL-A-S01-HRC']
        TSD4 = Cluster[Cluster['RULE_ID'] == 'BNP-TSD-EFT-ALL-A-S01-VRC']
        contin=True
        if len(TSD3[
            TSD3['THRESHOLD_NAME'] == 'Minimal Transaction Value'
        ]['THRESHOLD_VALUE'].values) != 0 :
            min_trans_val_TSD3=int(TSD3[
                TSD3['THRESHOLD_NAME']=='Minimal Transaction Value'
            ]['THRESHOLD_VALUE'].values[0])
        else: 
            contin=False
            OUTPUT_STREAM.write(
                f'Check TSD thresholds: No TSD3 thresholds defined for cluster {c}\n\n'
            )

        if len(TSD4[
            TSD4['THRESHOLD_NAME'] == 'Minimal Transaction Value'
        ]['THRESHOLD_VALUE'].values) != 0 :
            min_trans_val_TSD4 = int(TSD4[
                TSD4['THRESHOLD_NAME']=='Minimal Transaction Value'
            ]['THRESHOLD_VALUE'].values[0])
        else:
            contin=False
            OUTPUT_STREAM.write(
                f'Check TSD thresholds: No TSD4 thresholds defined for cluster {c}\n\n'
            )
        if contin:    
            if (min_trans_val_TSD4 > min_trans_val_TSD3):
                OUTPUT_STREAM.write(
                    f'Check TSD thresholds : TSD 4 threshold is higher than TSD 3 threshold for cluster {c}\n\n'
                ) 
            if min_trans_val_TSD3 > 1_000_000:
                OUTPUT_STREAM.write(
                    f'Check TSD thresholds : TSD 3 threshold is higher than one million for cluster {c}\n\n'
                )


def check_sbp_thresholds(OUTPUT_STREAM, ref_data, test_data):
    SBP_verif = test_data['SBP - Event Thresholds']
    Null1 = SBP_verif[SBP_verif.isna().any(axis=1)]
    if len(Null1) > 0:
        OUTPUT_STREAM.write(
            f'Check SBP thresholds: Null values in SBP event thresholds\n{Null1}\n\n'
        )
        
    SBP_thr_verif = test_data['SBP - SB Thresholds']
    Null1 = SBP_thr_verif[SBP_thr_verif.isna().any(axis=1)]
    if len(Null1) > 0:
        OUTPUT_STREAM.write(
            f'Check SBP thresholds: Null values in SBP SB thresholds\n{Null1}\n\n'
        )

    PM_value = SBP_verif[SBP_verif['EVENT_TYPE_CD'] == 'Party Monthly Value']
    output = PM_value.loc[PM_value['MIN_TRX_SUM_USER'].astype(int) < 20000]
    if len(output) > 0:
        OUTPUT_STREAM.write(
            f'Check SBP thresholds: Party monthly value is lower than 20 000 euros for\n{output}\n\n'
        )

    PM_volume=SBP_verif[SBP_verif['EVENT_TYPE_CD'] == 'Party Monthly Volume']
    output=PM_volume.loc[PM_volume['MIN_TRX_QTY_USER'].astype(int) < 5]
    if len(output) > 0:
        OUTPUT_STREAM.write(
            f'Check SBP thresholds: Party monthly volume is lower than 5 for\n{output}\n\n'
        )

    SBP_thr_verif = SBP_thr_verif.merge(
        ref_data['SBP - SB Thresholds'], how='outer',
        on=['POPULATION_GROUP_CD', 'PARAMETER_DESC']
    )
    diff = SBP_thr_verif[
        (SBP_thr_verif['THRESHOLD_USER_x'] != SBP_thr_verif['THRESHOLD_USER_y']) \
        & (SBP_thr_verif['POPULATION_GROUP_CD'].isin(['CLUP000', 'CLUP001', 'CLUP002', 'CLUP003']))
    ]
    if len(diff) > 0:
        OUTPUT_STREAM.write(
            f'Check SBP thresholds: Difference found on default clusters \n{diff}\n\n'
        )
        
    for sheet in [
        'SBP - Event Weights', 'SBP - Multiplier for Volume',
        'SBP - Party Risk Level', 'SBP - Transaction Risk Level'
    ]:
        df1 = ref_data[sheet].drop(['Tenant Code', 'Region Code'], axis=1)
        df2 = test_data[sheet].drop(['Tenant Code', 'Region Code'], axis=1)
        if not df1.equals(df2):
            OUTPUT_STREAM.write(
                f"Check SBP thresholds: Differences found in {sheet}: \n{df1}\n{df2}\n\n"
            )


def check_new_clients_clusters(OUTPUT_STREAM, test_data, clusters):
    LR = [k for k, v in clusters.items() if v == 0]
    MR = [k for k, v in clusters.items() if v == 1]
    HR = [k for k, v in clusters.items() if v == 2]

    population = test_data['Population Thresholds']

    for x in population['RULE_ID'].unique():
        data = population[population['RULE_ID'] == x]
        min_LR = np.min(data[data['POPULATION_GROUP_ID'].isin(LR)]['THRESHOLD_VALUE'])
        min_MR = np.min(data[data['POPULATION_GROUP_ID'].isin(MR)]['THRESHOLD_VALUE'])
        min_HR = np.min(data[data['POPULATION_GROUP_ID'].isin(HR)]['THRESHOLD_VALUE'])
        
        cd_LR = data['POPULATION_GROUP_ID'] == 'CLUA001'
        if (not data[cd_LR].empty) and (data[cd_LR]['THRESHOLD_VALUE'] != min_LR).item():
            OUTPUT_STREAM.write(
                f'Check new clients cluster : threshold for cluster 1 on rule \
                {x} does not match minimum of low risk clusters {LR}, which is {min_LR}\n'
            )
        cd_MR = data['POPULATION_GROUP_ID'] == 'CLUA002'
        if (not data[cd_MR].empty) and (data[cd_MR]['THRESHOLD_VALUE'] != min_MR).item(): 
            OUTPUT_STREAM.write(
                f'Check new clients cluster : threshold for cluster 2 on rule \
                {x} does not match minimum of low risk clusters {MR}, which is {min_MR}\n'
            )
        cd_HR = data['POPULATION_GROUP_ID'] == 'CLUA003'
        if (not data[cd_HR].empty) and (data[cd_HR]['THRESHOLD_VALUE'] != min_HR).item(): 
            OUTPUT_STREAM.write(
                f'Check new clients cluster : threshold for cluster 3 on rule \
                {x} does not match minimum of low risk clusters {HR}, which is {min_HR}\n'
            )

            
def check_thv_list(OUTPUT_STREAM, ref_data, test_data):
    df1 = copy.deepcopy(test_data['Lists-TSD THV LTH'])
    null_vals = df1[df1[['LIST_CD', 'LIST_NAME']].isna().any(axis=1)]
    if len(null_vals) > 0:
        OUTPUT_STREAM.write(
            f'Check THV list: missing value for LIST_CD or LIST_NAME on lines\n{null_vals}\n\n'
        )
        
    diff={}
    for liste in ref_data['Lists-TSD THV LTH']['LIST_CD'].unique() :
        list_code = df1[df1['LIST_CD'] == liste]
        set1 = set(list_code['ENTITY_KEY'])
        list_code = df1[df1['LIST_CD'] == liste]
        set2 = set(list_code['ENTITY_KEY'])
        diff[liste] = [(set1-set2),(set2-set1)]
    if diff != {} :
        for k in diff.keys():
            if diff[k][0] != set():
                OUTPUT_STREAM.write(
                    f'Check THV list: Element {k} entity {diff[k][0]} is not in reference\n\n'
                )
            if diff[k][1] != set():
                OUTPUT_STREAM.write(
                    f'Check THV list: Element {k} entity {diff[k][1]} is missing\n\n'
                )


def check_individual_clients(parameters, OUTPUT_STREAM, test_data):
    accounts = get_accounts(parameters)
    PARAMS_MAPPING = {
        "Individual Thresholds": "THRESHOLD_VALUE",
        "Individual Scores": "SCORE"
    }
    for sheet in ['Individual Thresholds', 'Individual Scores']:
        if len(test_data[sheet]) == 0:
            continue
        clients = [x[:15] for x in test_data[sheet]['ENTITY_KEY'].unique()]
        clients = set(clients)
        for client in clients :
            accounts_client = accounts[accounts['CLIENTNUM'] == client]['ACCOUNT_KEY']
            indiv_values = []
            for y in accounts_client :
                value = test_data[sheet][
                    test_data[sheet]['ENTITY_KEY'] == y
                ][PARAMS_MAPPING[sheet]]
                if len(value) != 0 : 
                    indiv_values.append(value.values[0])
                else: 
                    OUTPUT_STREAM.write(
                        f'The account(s) {y} of the client {client} do not have a threshold/score value\n\n'
                    )
            if  len(set(indiv_values)) > 1 :
                OUTPUT_STREAM.write(
                    f'The threshold/score value is not the same for all the accounts of the client {client}\n\n'
                )

    
def check_parameters_file(parameters, nameparams, nameclusters):
    constants.LOGGER.info(f"Check validity of parameters export file {nameparams}")
    
    ref_data = load_parameters_file(os.path.join(
        constants.READ_ONLY_DATA_PATH, 'other_resources', 'parameters_template.xlsx'
    ))
    test_data = load_parameters_file(nameparams)
    clusters = load_clusters_file(nameclusters)

    output_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'parameters_files', 'parameters_check.txt'
    )
    with open(output_file, 'w') as OUTPUT_STREAM:
        check_duplicates(OUTPUT_STREAM, test_data)
        check_country_name(parameters, OUTPUT_STREAM, test_data)
        check_missing_clusters(OUTPUT_STREAM, test_data, clusters)
        check_default_values(OUTPUT_STREAM, ref_data, test_data)
        check_null_thresholds(OUTPUT_STREAM, test_data)
        check_tsd_thresholds(OUTPUT_STREAM, test_data, clusters)
        check_sbp_thresholds(OUTPUT_STREAM, ref_data, test_data)
        check_new_clients_clusters(OUTPUT_STREAM, test_data, clusters)
        check_thv_list(OUTPUT_STREAM, ref_data, test_data)
        #check_individual_clients(parameters, OUTPUT_STREAM, test_data, bu)
