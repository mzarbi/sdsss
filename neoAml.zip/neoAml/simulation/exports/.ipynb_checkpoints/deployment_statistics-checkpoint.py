import os
import json
import pandas as pd
import numpy as np
from datetime import datetime
import holidays
import pyarrow.parquet as pq

from ..kpis.compute_kpis import associate_alert_ids
from ..utils import constants

from ..utils.utils import lookup, export_to_xlsx

                
def load_alerts_files(parameters):
    truth_alerts_file = os.path.join(
        constants.READ_WRITE_DATA_PATH,
        parameters.BU, 'alerts',
        'ALL_{}_truth.parquet'.format(parameters.BU)
    )
    alerts = pd.read_parquet(
        truth_alerts_file,
        columns=[
            'ALERT_ID', 'ALERT_DATE', 'TRANSACTION_KEY',
            'CLIENT_N0', 'CRDS_CODE', 'RULE_ID', 'STEP', 'ACCOUNT_KEY',
            'SCORE', 'ALERT_SCORE'
        ]
    )
    alerts['ALERT_DATE'] = lookup(alerts['ALERT_DATE'])
    alerts = alerts[
        (alerts.ALERT_DATE >= parameters.ANALYSIS_DATES["CLUSTERING_TEST"]["FROM"])
        & (alerts.ALERT_DATE <= parameters.ANALYSIS_DATES["CLUSTERING_TEST"]["TO"])
    ]
    
    run_alerts_file = os.path.join(
        constants.READ_WRITE_DATA_PATH,
        parameters.BU, 'alerts',
        'ALL_{}_{}.parquet'.format(parameters.BU, parameters.FILES_EXPORT.ALERTS)
    )
    schema = pq.read_schema(run_alerts_file)
    columns =  [
        'ALERT_ID', 'TRANSACTION_KEY', 'CLIENT_N0', 'RULE_ID', 'ACCOUNT_KEY'
    ]
    if "ALERT_DATE" in schema.names:
        columns.append("ALERT_DATE")
    else:
        columns.append("TRANS_INSERT_DATE")
    run_alerts = pd.read_parquet(
        run_alerts_file,
        columns=columns
    )
    if "ALERT_DATE" not in run_alerts.columns:
        run_alerts = run_alerts.rename(columns={
            "TRANS_INSERT_DATE": "ALERT_DATE"
        })
    run_alerts['ALERT_DATE'] = lookup(run_alerts['ALERT_DATE'])
    run_alerts = run_alerts[
        (run_alerts.ALERT_DATE >= parameters.ANALYSIS_DATES["CLUSTERING_TEST"]["FROM"])
        & (run_alerts.ALERT_DATE <= parameters.ANALYSIS_DATES["CLUSTERING_TEST"]["TO"])
    ]
    
    clusters_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'Clusters',
        '{}_SAM8_Cluster_Mapping_{}.csv'.format(parameters.BU, parameters.FILES_EXPORT.CLUSTERS)
    )
    clusters = pd.read_csv(
        clusters_file,
        sep=';',
        usecols=['PARTY_KEY', 'CLUSTER_ID']
    ).rename(columns={"PARTY_KEY": "CLIENT_N0"}).drop_duplicates()

    alerts = pd.merge(alerts, clusters, how='left', on='CLIENT_N0')
    run_alerts = pd.merge(
        run_alerts, clusters, how='left', on='CLIENT_N0')
    
    return alerts, run_alerts


def compute_prod_table(parameters, alerts):
    if len(alerts[pd.isnull(alerts.CLUSTER_ID)]) > 0:
        constants.LOGGER.info('There are {} rows with missing CLUSTER_ID'.format(len(alerts[pd.isnull(alerts.CLUSTER_ID)])))
    alerts = alerts[pd.notnull(alerts.CLUSTER_ID)]
    alerts['CLUSTER_ID'] = alerts['CLUSTER_ID'].astype(int)

    parameters.DEPLOYMENT_STATS_MODEL_MAPPING.update(constants.SAM3_KEYWORD_MODEL_MAPPING)
    alerts['MODEL_NAME'] = alerts['RULE_ID'].map(parameters.DEPLOYMENT_STATS_MODEL_MAPPING)
    alerts['NB_L1'] = np.where(alerts.STEP.str.contains('L1 - closed', regex=True), 1, 0)
    alerts['NB_L2'] = np.where(alerts.STEP.str.contains('L2|Level 2', regex=True), 1, 0)
    alerts['NB_L3'] = np.where(alerts.STEP.str.contains('L3|Level 3', regex=True), 1, 0)
    alerts['NB_NOT_CLOSED'] = np.where(
        (alerts['NB_L1'] == 0) & (alerts['NB_L2'] == 0) & (alerts['NB_L3'] == 0),
        1, 0
    )
    new_columns = ['NB_L1', 'NB_L2', 'NB_L3', 'NB_NOT_CLOSED']
    for col in new_columns:
        alerts[col] = alerts.groupby(['CLUSTER_ID', 'RULE_ID'])[col].transform(sum)
    alerts['TOTAL'] = alerts[new_columns].sum(axis=1)
    alerts = alerts[['CLUSTER_ID', 'RULE_ID', 'MODEL_NAME', 'TOTAL'] + new_columns].drop_duplicates()\
    .sort_values(['CLUSTER_ID', 'MODEL_NAME']).reset_index(drop=True)

    return alerts


def generate_all_prod_tables(parameters, alerts):
    prod_alerts_table = compute_prod_table(
        parameters,
        alerts[
            ['ALERT_ID', 'CRDS_CODE', 'STEP', 'RULE_ID', 'ALERT_DATE', 'CLUSTER_ID']
        ].drop_duplicates()
    )
    prod_hits_table = compute_prod_table(
        parameters,
        alerts[
            ['ALERT_ID', 'TRANSACTION_KEY', 'CRDS_CODE', 'STEP', 'RULE_ID', 'ALERT_DATE', 'CLUSTER_ID']
        ].drop_duplicates()
    )
    prod_rule_account_table = compute_prod_table(
        parameters,
        alerts[
            ['ALERT_ID', 'ACCOUNT_KEY', 'CRDS_CODE', 'STEP', 'RULE_ID', 'ALERT_DATE', 'CLUSTER_ID']
        ].drop_duplicates()
    )
    return prod_alerts_table, prod_hits_table, prod_rule_account_table


def compute_run_table(parameters, alerts, run_alerts):    
    alerts['RULE_ID'] = alerts['RULE_ID'].map(constants.SAM3_SAM8_RULES_MAPPING)\
                                         .fillna(alerts['RULE_ID'])
    alerts["STEP"] = np.where(
        alerts["STEP"].str.contains('L3|Level 3', regex=True),
        "L3",
        np.where(
            alerts["STEP"].str.contains("L2|Level 2", regex=True),
            "L2",
            "L1"
        )
    )
    alerts = alerts.groupby(
        [e for e in alerts.columns if e not in ['STEP', 'ALERT_DATE', 'ALERT_ID']]
    ).max().reset_index()

    if len(run_alerts[pd.isnull(run_alerts.CLUSTER_ID)]) > 0:
        constants.LOGGER.info('There are {} rows with missing CLUSTER_ID'.format(len(run_alerts[pd.isnull(run_alerts.CLUSTER_ID)])))
    run_alerts = run_alerts[pd.notnull(run_alerts.CLUSTER_ID)]
    #run_alerts['CLUSTER_ID'] = run_alerts['CLUSTER_ID'].str[-2:].astype(int)

    # Create temporary column to keep SAM8 EFT buckets
    run_alerts['NEW_RULE_ID'] = run_alerts['RULE_ID']
    run_alerts['RULE_ID'] = run_alerts['RULE_ID'].map(constants.SAM8_SAM3_RULES_MAPPING)\
    .fillna(run_alerts['RULE_ID'])
    run_alerts = pd.merge(
        run_alerts, alerts, how='left',
        on=[e for e in alerts.columns if e not in ['STEP', 'ALERT_ID']] 
    )
    run_alerts = run_alerts.drop('RULE_ID', axis=1).rename(columns={'NEW_RULE_ID': 'RULE_ID'})
    parameters.DEPLOYMENT_STATS_MODEL_MAPPING.update(constants.SAM8_KEYWORD_MODEL_MAPPING)
    run_alerts['MODEL_NAME'] = run_alerts['RULE_ID'].map(parameters.DEPLOYMENT_STATS_MODEL_MAPPING)
    
    run_alerts['EXISTING_L1'] = np.where(
        (pd.notnull(run_alerts.STEP))
        & (run_alerts.STEP == 'L1'),
        1, 0
    )
    run_alerts['EXISTING_L2'] = np.where(
        (pd.notnull(run_alerts.STEP))
        & (run_alerts.STEP == 'L2'),
        1, 0
    )
    run_alerts['EXISTING_L3'] = np.where(
        (pd.notnull(run_alerts.STEP))
        & (run_alerts.STEP == 'L3'),
        1, 0
    )
    run_alerts['EXISTING_NOT_CLOSED'] = np.where(
        (pd.notnull(run_alerts.STEP))
        & (run_alerts['EXISTING_L1'] == 0)
        & (run_alerts['EXISTING_L2'] == 0)
        & (run_alerts['EXISTING_L3'] == 0),
        1, 0
    )
    trans_type = 'ALERTS' if 'CLIENT_N0' in alerts.columns else 'HITS'
    run_alerts[f'NEW_{trans_type}'] = np.where(pd.isnull(run_alerts.STEP), 1, 0)
    new_columns = ['EXISTING_L1', 'EXISTING_L2', 'EXISTING_L3', 'EXISTING_NOT_CLOSED', f'NEW_{trans_type}']
    for col in new_columns:
        run_alerts[col] = run_alerts.groupby(['CLUSTER_ID', 'RULE_ID'])[col].transform(sum)
    run_alerts['TOTAL_RUN'] = run_alerts[new_columns].sum(axis=1)
    run_alerts = run_alerts[['CLUSTER_ID', 'RULE_ID', 'MODEL_NAME', 'TOTAL_RUN'] + new_columns]\
    .drop_duplicates().sort_values(['CLUSTER_ID', 'MODEL_NAME']).reset_index(drop=True)
    for col in ['TOTAL_RUN'] + new_columns:
        run_alerts[col] = run_alerts[col].astype(int)
    
    return run_alerts


def generate_all_run_tables(parameters, alerts, run_alerts):
    run_alerts_table = compute_run_table(
        parameters,
        alerts[
            ['CLIENT_N0', 'RULE_ID', 'ALERT_ID', 'STEP', 'ALERT_DATE']
        ].drop_duplicates(),
        run_alerts[
            ['CLIENT_N0', 'RULE_ID', 'ALERT_ID', 'CLUSTER_ID', 'ALERT_DATE']
        ].drop_duplicates()
    )
    run_hits_table = compute_run_table(
        parameters,
        alerts[
            ['TRANSACTION_KEY', 'RULE_ID', 'ALERT_ID', 'STEP', 'ALERT_DATE']
        ].drop_duplicates(),
        run_alerts[
            ['TRANSACTION_KEY', 'RULE_ID', 'ALERT_ID', 'CLUSTER_ID', 'ALERT_DATE']
        ].drop_duplicates()
    )
    run_rule_account_table = compute_run_table(
        parameters,
        alerts[
            ['ACCOUNT_KEY', 'RULE_ID', 'ALERT_ID', 'STEP', 'ALERT_DATE']
        ].drop_duplicates(),
        run_alerts[
            ['ACCOUNT_KEY', 'RULE_ID', 'ALERT_ID', 'CLUSTER_ID', 'ALERT_DATE']
        ].drop_duplicates()
    )
    
    return run_alerts_table, run_hits_table, run_rule_account_table


def get_number_workdays(parameters):
    start = datetime.strptime(
        parameters.ANALYSIS_DATES["CLUSTERING_TEST"]["FROM"], '%Y-%m-%d'
    ).date()
    end = datetime.strptime(
        parameters.ANALYSIS_DATES["CLUSTERING_TEST"]["TO"], '%Y-%m-%d'
    ).date()
    try:
        list_holidays = [
            e.date() for e in pd.date_range(start, end).tolist()
            if e in holidays.CountryHoliday(parameters.ISO2_BU, **constants.COUNTRY_HOLIDAY_PARAMETERS[parameters.BU])
        ]
    except KeyError: # Country not found in holiday library
        list_holidays = []

    return np.busday_count(start, end, holidays=list_holidays)


def generate_slides_table(parameters, alerts, working_days):
    if 'CLIENT_N0' in alerts.columns:
        trans_type = 'RULE'
    elif 'TRANSACTION_KEY' in alerts.columns:
        trans_type = 'HIT'
    else:
        trans_type = 'RULE/ACCOUNT'
    alerts['RULE_ID'] = alerts['RULE_ID'].map(parameters.DEPLOYMENT_STATS_MODEL_MAPPING)\
    .fillna(alerts['RULE_ID'])
    dt = alerts.groupby('RULE_ID').agg(ALERTS_COUNT=('ALERT_ID', 'count'))\
    .rename(columns={'ALERTS_COUNT': f'{trans_type}_COUNT'})
    dt_reset = dt.reset_index()
    multi_rules = [
        e for e in list(set(parameters.DEPLOYMENT_STATS_MODEL_MAPPING.values()))
        if int(e[:2]) > 8
    ]

    slide_stats = {
        f'{trans_type} Counts': dt.to_dict('index'),
        f'Total {trans_type} Counts': sum(
            alerts.groupby('RULE_ID').agg({'ALERT_ID': 'count'}).reset_index()['ALERT_ID']
        ),
        'Distinct Alerts': len(alerts.ALERT_ID.unique()),
        'Average alerts per working day': round(
            len(alerts.ALERT_ID.unique()) / working_days, 1
        ),
        f'Mono-transaction Models {trans_type} Counts': sum(
            dt_reset[~dt_reset.RULE_ID.isin(multi_rules)][f'{trans_type}_COUNT']
        ),
        f'Multi-transaction Models {trans_type} Counts': sum(
            dt_reset[dt_reset.RULE_ID.isin(multi_rules)][f'{trans_type}_COUNT']
        )
    }

    return slide_stats


def generate_all_slides_figures(parameters, alerts, run_alerts):
    slide_stats = {}
    working_days = get_number_workdays(parameters)
    
    alerts['ALERT_ID'] = alerts['ALERT_DATE'].astype(str) + alerts['CLIENT_N0']
    
    parameters.DEPLOYMENT_STATS_MODEL_MAPPING.update(constants.SAM3_KEYWORD_MODEL_MAPPING)
    slide_stats['Production Alerts Rule Counts'] = generate_slides_table(
        parameters, 
        alerts[
            ['ALERT_ID', 'RULE_ID', 'CLIENT_N0']
        ].drop_duplicates(),
        working_days
    )
    slide_stats['Production Alerts Hit Counts'] = generate_slides_table(
        parameters, 
        alerts[
            ['ALERT_ID', 'RULE_ID', 'TRANSACTION_KEY']
        ],
        working_days
    )
    slide_stats['Production Alerts Rule/Account Counts'] = generate_slides_table(
        parameters, 
        alerts[
            ['ALERT_ID', 'RULE_ID', 'ACCOUNT_KEY']
        ].drop_duplicates(),
        working_days
    )

    parameters.DEPLOYMENT_STATS_MODEL_MAPPING.update(constants.SAM8_KEYWORD_MODEL_MAPPING)
    slide_stats['Run Alerts Rule Counts'] = generate_slides_table(
        parameters, 
        run_alerts[
            ['ALERT_ID', 'RULE_ID', 'CLIENT_N0']
        ].drop_duplicates(),
        working_days
    )
    slide_stats['Run Alerts Hit Counts'] = generate_slides_table(
        parameters, 
        
        run_alerts[
            ['ALERT_ID', 'RULE_ID', 'TRANSACTION_KEY']
        ],
        working_days
    )
    slide_stats['Run Alerts Rule/Account Counts'] = generate_slides_table(
        parameters, 
        run_alerts[
            ['ALERT_ID', 'RULE_ID', 'ACCOUNT_KEY']
        ].drop_duplicates(),
        working_days
    )
    
    return slide_stats


def build_missing_escalations_report(alerts, run_alerts):
    agg_alerts = alerts.groupby(["ALERT_ID"]).agg({
        "STEP": "first",
        "ALERT_DATE": max,
        "CLIENT_N0": "first",
        "SCORE": sum,
        "ALERT_SCORE": "first",
        "ACCOUNT_KEY": "first",
        "RULE_ID": "unique"
    }).reset_index(drop=False)
    agg_run_alerts = run_alerts.groupby(["ALERT_ID"]).agg({
        "ALERT_DATE": max,
        "CLIENT_N0": "first",
    }).reset_index(drop=False) \
      .rename(columns={"ALERT_ID": "SIMU_ALERT_ID"})
    
    agg_alerts = agg_alerts.merge(
        agg_run_alerts,
        on=["CLIENT_N0", "ALERT_DATE"],
        how="left"
    )

    missing_escalations = {
        "alerts": agg_alerts[
            (agg_alerts["SIMU_ALERT_ID"].isna()) \
            & (agg_alerts["STEP"].str.contains("L2|L3"))
        ]
    }
    missing_escalations["hits"] = alerts[
        alerts["ALERT_ID"].isin(missing_escalations["alerts"]["ALERT_ID"])
    ]
    return missing_escalations


def generate_deployment_statistics(parameters):
    # Export run alerts to csv
    export_alerts_to_csv(parameters)

    constants.LOGGER.info("FILES_EXPORT deployment statistics step : Generate deployment statistics files")
    os.makedirs(
        os.path.join(constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'deployment_stats_files'),
        exist_ok=True
    )

    alerts, run_alerts = load_alerts_files(parameters)

    prod_alerts_table, prod_hits_table, prod_rule_account_table = generate_all_prod_tables(
        parameters, alerts
    )
    run_alerts_table, run_hits_table, run_rule_account_table = generate_all_run_tables(
        parameters, alerts, run_alerts
    )
    
    deployment_tables_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'deployment_stats_files',
        'CIB ITO FS - {} - SAM8R DPL - {} figures - {}.xlsx'.format(
            parameters.BU,
            parameters.EXPERIMENT_KEY.upper(),
            datetime.today().strftime('%y%m%d')
        )
    )
    deployment_tables = {
        'PROD_hits': prod_hits_table,
        '{}_hits'.format(parameters.EXPERIMENT_KEY.upper()): run_hits_table,
        'PROD_Rule count': prod_alerts_table,
        '{}_Rule count'.format(parameters.EXPERIMENT_KEY.upper()): run_alerts_table,
        'PROD_Rule_account_count': prod_rule_account_table,
        '{}_R-A_count'.format(parameters.EXPERIMENT_KEY.upper()): run_rule_account_table
    }
    export_to_xlsx(
        deployment_tables, deployment_tables_file
    )

    slide_stats = generate_all_slides_figures(parameters, alerts, run_alerts)
    slide_stats_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'deployment_stats_files',
        'slides_stats.txt'
    )
    with open(slide_stats_file, 'w') as f:
            f.write(json.dumps(slide_stats, indent=4))
            
    missing_escalations = build_missing_escalations_report(alerts, run_alerts)
    missing_escalations_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'deployment_stats_files',
        'CIB ITO FS - {} - SAM8R DPL - {} missing escalations - {}.xlsx'.format(
            parameters.BU,
            parameters.EXPERIMENT_KEY.upper(),
            datetime.today().strftime('%y%m%d')
        )
    )
    export_to_xlsx(
        missing_escalations, missing_escalations_file
    )

def export_alerts_to_csv(parameters):
    inputdir = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'alerts'
    )
    outputdir = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'exports', 'alerts'
    )
    os.makedirs(outputdir, exist_ok=True)
    for file in os.listdir(inputdir):
        key_list = file.split(".")[0].split("_")
        if len(key_list) == 3:
            key = key_list[-1]
        else:
            key = '_'.join(key_list[2:])
        if key != parameters.FILES_EXPORT.ALERTS:
            continue
        model = key_list[0]

        df = pd.read_parquet(os.path.join(
            inputdir, file
        ))
        df.to_csv(
            os.path.join(
                outputdir,  f"{model}_{parameters.BU}_{key}.csv"
            ), index=False, sep=";"
        )