import os
import pandas as pd
from datetime import datetime

from ..thresholds.sbp import fill_all_sbp_thresholds
from ..utils import constants

from ..utils.serialization import load_parameters, load_pickle_file
from ..utils.utils import export_to_xlsx
from ..exports.parameters_file_check import check_parameters_file


def change_clusters_names(clusters, thresholds):
    all_clusters = list(set(['1', '2', '3'] + clusters))
    for cluster in all_clusters:
        if thresholds.get(str(cluster)) is not None:
            thresholds['CLUA' + str(cluster).zfill(3)] = thresholds[str(cluster)]
            del thresholds[str(cluster)]

        
def create_default_values(clusters, default_value):
    thresholds = {}
    all_clusters = list(set(['1', '2', '3'] + clusters))
    for cluster in all_clusters:
        thresholds['CLUA' + str(cluster).zfill(3)] = default_value
        
    return thresholds


def fill_other_values(parameters, df, model, model_full_name, iso3_bu):
    assert len(iso3_bu) == 3
    df['FROM_VALUE'] = df['FROM_VALUE'].astype(int)
    df['RULE_ID'] = parameters.SUBMODEL_RULE_ID_MAP[model_full_name]
    df['RULE_NAME'] = model_full_name
    df['ROLE_ID'] = df['RULE_NAME'].map(constants.ROLE_ID_MAPPING).fillna(1).astype(int)
    df['SCORE_FACTOR_NAME'] = constants.SCORE_FACTOR_MAPPING.get(model_full_name, 'Activity Value')
    df['THRESHOLD_NAME'] = constants.MODEL_THRESHOLD_NAME[model]
    df['PARAM_ID'] = 'S_1'
    df['TENANT_ID'] = iso3_bu
    df['REGION_CD'] = df['TENANT_ID'] + '_R'
    
    return df


def generate_threshold_files(parameters, threshold_type, clusters):

    if threshold_type == 'cluster':
        POPULATION_KEY = 'POPULATION_GROUP_ID'
        THRESHOLDS_COLUMNS = constants.POPULATION_THRESHOLDS_COLUMNS
        SCORES_COLUMNS = constants.POPULATION_SCORES_COLUMNS
    else:
        POPULATION_KEY = 'ENTITY_KEY'
        THRESHOLDS_COLUMNS = constants.INDIVIDUAL_THRESHOLDS_COLUMNS
        SCORES_COLUMNS = constants.INDIVIDUAL_SCORES_COLUMNS

    list_df = []

    for model in ['EFT', 'TSD', 'FTF', 'STP']:
        
        if model != 'STP':
            par = load_pickle_file(os.path.join(
                constants.READ_WRITE_DATA_PATH, parameters.BU, 'thresholds',
                f'{model}_{parameters.BU}_{parameters.FILES_EXPORT.THRESHOLDS}.pickle'
            ))

        for model_full_name in parameters.ALL_MODEL_FULL_NAMES[model]: 
            dthr = {}
            dsc = {}
            if model == 'EFT':
                bucket = model_full_name.split(' - ')[1]
                if bucket in parameters.BUCKETS:
                    if par[threshold_type]['EFT']['Excessive Single Transactions']\
                          [constants.MODEL_THRESHOLD_NAME['EFT']].get(bucket) is None:
                        if threshold_type == 'cluster':
                            dthr = create_default_values(clusters, parameters.EFT_BUCKET_MIN_VALUE[bucket])
                            dsc = create_default_values(clusters, parameters.EFT_BUCKET_MIN_VALUE[bucket])
                    else:
                        dthr = par[threshold_type]['EFT']['Excessive Single Transactions']\
                                  [constants.MODEL_THRESHOLD_NAME['EFT']][bucket]
                        dsc = {}
                        for key, sub_d in par[f'{threshold_type}_score']['EFT']\
                                             ['Excessive Single Transactions']\
                                             [constants.MODEL_SCORE_NAME['EFT']][bucket].items():
                            dsc[key] = list(sub_d.values())[0]
                        if threshold_type == 'cluster':
                            change_clusters_names(clusters, dthr)
                            change_clusters_names(clusters, dsc)
                else:
                    print(f'WARNING "{bucket}" will have default threshold values')
                    if threshold_type == 'cluster':
                        dthr = create_default_values(clusters, constants.DEFAULT_THRESHOLDS['EFT'])
                        dsc = create_default_values(clusters, constants.DEFAULT_SCORES['EFT'])

            elif model != 'STP':
                dthr = par[threshold_type][model][model_full_name]\
                          [constants.MODEL_THRESHOLD_NAME[model]]
                dsc = {}
                for key, sub_d in par[f'{threshold_type}_score'][model]\
                                     [model_full_name][constants.MODEL_SCORE_NAME[model]].items():
                    dsc[key] = list(sub_d.values())[0]
                if threshold_type == 'cluster':
                    change_clusters_names(clusters, dthr)
                    change_clusters_names(clusters, dsc)

            elif model == 'STP' and threshold_type == 'cluster':
                dthr = create_default_values(clusters, constants.DEFAULT_THRESHOLDS[model])

            df = pd.DataFrame(dthr.items(), columns=[POPULATION_KEY, 'FROM_VALUE'])            
            df = fill_other_values(parameters, df, model, model_full_name, parameters.BU)
            if dsc:
                scores = pd.DataFrame(dsc.items(), columns=[POPULATION_KEY, 'SCORE'])
                df = pd.merge(df, scores, how='left', on=POPULATION_KEY)
           
            df.sort_values(POPULATION_KEY, inplace=True)
            list_df.append(df)

    df = pd.concat(list_df, ignore_index=True)
    if len(df) == 0:
        return pd.DataFrame(columns=THRESHOLDS_COLUMNS), \
               pd.DataFrame(columns=SCORES_COLUMNS)
    df1 = df[SCORES_COLUMNS]
    df1 = df1[~df1.RULE_NAME.isin(parameters.ALL_MODEL_FULL_NAMES['STP'])]
    df1['SCORE'] = df1['SCORE'].astype(int)

    df['PARAM_ID'] = 'C_1'
    df.rename(columns={'FROM_VALUE': 'THRESHOLD_VALUE'}, inplace=True)
    df2 = df[THRESHOLDS_COLUMNS]

    return df2, df1

def generate_tenant_thresholds(parameters, template_parameters, thresholds):
    tenant_scores = template_parameters['Tenant Thresholds']

    for model in ['EFT', 'TSD', 'FTF']:
        for model_full_name in parameters.ALL_MODEL_FULL_NAMES[model]:
            model_name = model_full_name.split(' - ')[0]
            if model == 'EFT' and isinstance(
                thresholds['user'][model][model_name] \
                          ['Recurrence Period (days)'], dict):
                bucket = model_full_name.split(' - ')[1]
                if bucket in parameters.BUCKETS:
                    recurrence = thresholds['user'][model][model_name] \
                                           ['Recurrence Period (days)'][bucket]
                    nb_occurences = thresholds['user'][model][model_name] \
                                              ['No. of Occurrences'][bucket]
            elif model != 'STP':
                recurrence = thresholds['user'][model][model_name]['Recurrence Period (days)']
                nb_occurences = thresholds['user'][model][model_name]['No. of Occurrences']   
            recurrence_condition = (tenant_scores.RULE_ID == parameters.SUBMODEL_RULE_ID_MAP[model_full_name]) \
                                   & (tenant_scores.ATTRIBUTE_NAME == 'RECURRENCE_PERIOD')
            occurence_condition = (tenant_scores.RULE_ID == parameters.SUBMODEL_RULE_ID_MAP[model_full_name]) \
                                  & (tenant_scores.ATTRIBUTE_NAME == 'RECURRENCE')
            tenant_scores.loc[recurrence_condition, 'THRESHOLD_VALUE'] = recurrence
            tenant_scores.loc[occurence_condition, 'THRESHOLD_VALUE'] = nb_occurences

    return tenant_scores


def generate_parameters_files(parameters):        
    V8_export_dir = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        'exports', 'parameters_files'
    )
    os.makedirs(V8_export_dir, exist_ok=True)
    template_parameters_file = ""
    for filename in os.listdir(V8_export_dir):
        if filename.endswith(".xlsx"):
            template_parameters_file = os.path.join(
                V8_export_dir,
                filename
            )
            if "RAW" in filename:
                break

    if template_parameters_file == "":
        constants.LOGGER.info("No valid V8 parameters template found")
        return

    template_parameters = pd.read_excel(template_parameters_file, None)
    template_parameters = {k.strip(): v for k, v in template_parameters.items()}

    params = load_parameters(parameters.BU, parameters.FILES_EXPORT.PARAMETERS)
    
    constants.LOGGER.info("Build parameters dataframe")
    list_clusters = pd.read_csv(os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU,
        f'Clusters/{parameters.BU}_SAM8_Cluster_Mapping_{parameters.FILES_EXPORT.CLUSTERS}.csv'
    ), sep=';', usecols=['CLUSTER_ID'])['CLUSTER_ID'].unique().tolist()
    template_parameters['Population Thresholds'], template_parameters['Population Scores'] \
    = generate_threshold_files(parameters, 'cluster', list_clusters)
    template_parameters['Individual Thresholds'], template_parameters['Individual Scores'] \
    = generate_threshold_files(parameters, 'individual', list_clusters)
    
    template_parameters['Tenant Thresholds'] \
    = generate_tenant_thresholds(parameters, template_parameters, params)

    template_parameters['SBP - SB Thresholds'], template_parameters['SBP - Event Thresholds'] \
    = fill_all_sbp_thresholds(parameters, 
        template_parameters,
        list_clusters, parameters.FILES_EXPORT.TRANSACTIONS, parameters.FILES_EXPORT.CLUSTERS
    )

    final_namefile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'parameters_files',
        'CIB ITO FS - SAM8R {} {} Parameters - {}.xlsx'.format(
            parameters.BU,
            parameters.EXPERIMENT_KEY.upper(),
            datetime.today().strftime('%y%m%d')
        )
    )
    final_clusterfile = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'clusters_files',
        'CIB ITO FS - SAM8R {} {} Cluster Mapping - {}.xlsx'.format(
            parameters.BU,
            parameters.EXPERIMENT_KEY.upper(),
            datetime.today().strftime('%y%m%d')
        )
    )
    constants.LOGGER.info(f"Export parameters to {final_namefile}")
    export_to_xlsx(
        template_parameters, final_namefile,
        subsheets=constants.PARAMETERS_FILE_SHEETS
    )

    check_parameters_file(parameters, final_namefile, final_clusterfile)
