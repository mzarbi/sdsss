import os
import pandas as pd

from ..utils import constants


def clean_features_file(df):
    cols_to_keep = [
        "CRDS_CODE", "KYC_RECORD_TYPE", "LIFECYCLE_STATUS", "KYC_STATUS", "KYC_SEGMENT",
        "RISK_LEVEL", "COUNTRY_INCORPORATION", "ADVERSE_INFO",
        "BNPP_ENTITY", "FROM_RELIANCE", "HAS_FSI", "HAS_KYC",
        'RISK_SCORE', 'NUMBER_TRANSACTIONS', 'MEAN_TRANSACTIONS',
        'MEDIAN_LOG_TRANSACTIONS', 'STD_LOG_TRANSACTIONS',
        'NUMBER_TRANSACTIONS_HIGH_RISK', 'MEDIAN_TRANSACTIONS_HIGH_RISK', 'FTF_HITS'
    ]
    df = df[cols_to_keep]
    return df
    
def clean_cluster_mapping_file(df):
    cols_to_keep = ["CRDS_CODE", "CLUSTER_ID"]
    df = df[cols_to_keep]
    return df

def create_features_export(parameters):
    features_file_train = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, "features",
        f"{parameters.BU}_clustering_features_train_{parameters.FILES_EXPORT.FEATURES}.csv"
    )
    features_train = clean_features_file(
        pd.read_csv(
            features_file_train, sep=';'
        )
    )
    features_file_test = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, "features",
        f"{parameters.BU}_clustering_features_test_{parameters.FILES_EXPORT.FEATURES}.csv"
    )
    features_test = clean_features_file(
        pd.read_csv(
            features_file_test, sep=';'
        )
    )
    features_only_in_test = features_test[
        ~features_test["CRDS_CODE"].isin(features_train["CRDS_CODE"])
    ]
    
    features = pd.concat(
        [features_train, features_only_in_test],
        axis=0
    )
    
    cluster_file_train = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, "Clusters",
        f"{parameters.BU}_SAM8_Cluster_Mapping_{parameters.FILES_EXPORT.CLUSTERS}.csv"
    )
    clustering = clean_cluster_mapping_file(
        pd.read_csv(
            cluster_file_train, sep=';'
        )
    )
    features = features.merge(clustering, how="left", on="CRDS_CODE").drop_duplicates()

    out_features_path = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, "exports/audit_trail",
        f"clustering_features_{parameters.FILES_EXPORT.FEATURES}.csv"
    )
    features.to_csv(out_features_path, index=False, sep=";")
