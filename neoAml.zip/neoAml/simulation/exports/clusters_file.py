import os
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

from ..cluster.clustering import prepare_clustering_features
from ..utils import constants
from ..utils.parameters import PipelineArgs

from ..utils.serialization import load_pickle_file
from ..utils.utils import export_to_xlsx


def create_cluster_mapping(parameters):

    clusters_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'Clusters',
        '{}_SAM8_Cluster_Mapping_{}.csv'.format(parameters.BU, parameters.FILES_EXPORT.CLUSTERS)
    )
    clusters = pd.read_csv(
        clusters_file, sep=';',
        usecols=["CLIENT_KEY", "CLUSTER_ID"]
    )
    clusters["BU"] = parameters.BU
    clusters["CLIENT_VERSION"] = 1
    clusters["VERSION_ACTIVE_FLAG"] = 1
    clusters["VERSION_START_DATE"] = datetime.today().strftime('%d-%b-%y')
    clusters["VERSION_END_DATE"] = ""
    clusters["RUN_PERIOD_START_DATE"] = datetime.strptime(
        parameters.ANALYSIS_DATES["CLUSTERING_TRAIN"]["FROM"], '%Y-%m-%d'
    ).strftime('%d-%b-%y')
    clusters["RUN_PERIOD_END_DATE"] = datetime.strptime(
        parameters.ANALYSIS_DATES["CLUSTERING_TRAIN"]["TO"], '%Y-%m-%d'
    ).strftime('%d-%b-%y')

    clusters = clusters[[
        "BU", "CLIENT_KEY", "CLUSTER_ID", "CLIENT_VERSION", "VERSION_ACTIVE_FLAG",
        "VERSION_START_DATE", "VERSION_END_DATE", "RUN_PERIOD_START_DATE", "RUN_PERIOD_END_DATE"
    ]]
    
    return clusters


def extract_risk_mapping(parameters):
    clusters_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'Clusters',
        '{}_SAM8_Cluster_Mapping_{}.csv'.format(parameters.BU, parameters.FILES_EXPORT.CLUSTERS)
    )
    clusters = pd.read_csv(
        clusters_file, sep=';',
        usecols=["CLIENT_KEY", "CLUSTER_ID", "RISK_LEVEL"]
    )
    return clusters.groupby(["CLUSTER_ID"])["RISK_LEVEL"] \
                   .agg(max).to_dict()


def create_cluster_summary(parameters, clusters, risk_mapping):

    postings_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'processed',
        'CTP_{}_Postings_{}.parquet'.format(parameters.BU, parameters.FILES_EXPORT.TRANSACTIONS)
    )
    postings = pd.read_parquet(
        postings_file,
        columns=[constants.MAIN_AMNT_KEY, 'POS_ID', 'CLIENTNUM']
    )

    clusters_mapping = dict(zip(clusters['CLIENT_KEY'], clusters['CLUSTER_ID']))
    postings['CLUSTER_ID'] = postings['CLIENTNUM'].map(clusters_mapping)
    summary = postings.groupby('CLUSTER_ID').agg(
        MEDIAN=(constants.MAIN_AMNT_KEY, 'median'),
        AVERAGE=(constants.MAIN_AMNT_KEY, 'mean'),
        MIN_AMOUNT=(constants.MAIN_AMNT_KEY, 'min'),
        MAX_AMOUNT=(constants.MAIN_AMNT_KEY, 'max'),
        STD=(constants.MAIN_AMNT_KEY, 'std')
    ).reset_index()
    for col in ['CLUSTER_ID', 'MEDIAN', 'AVERAGE', 'MIN_AMOUNT', 'MAX_AMOUNT', 'STD']:
        summary[col] = summary[col].astype(int)        
    summary.insert(loc=0, column='BU', value=parameters.BU)
    summary.insert(loc=2, column='RISK_LEVEL', value=summary['CLUSTER_ID'].map(risk_mapping).fillna(0))
    summary['CURRENCY_CD'] = constants.CURRENCIES_MAPPING.get(parameters.BU, 'EUR')
    summary['CLUSTER_VERSION'] = 1
    summary['VERSION_ACTIVE_FLAG'] = 1
    summary['VERSION_START_DATE'] = datetime.today().strftime('%d-%b-%y')
    summary['VERSION_END_DATE'] = None
    summary['RUN_PERIOD_START_DATE'] = datetime.strptime(
        parameters.ANALYSIS_DATES["CLUSTERING_TRAIN"]["FROM"], '%Y-%m-%d'
    ).strftime('%d-%b-%y')
    summary['RUN_PERIOD_END_DATE'] = datetime.strptime(
        parameters.ANALYSIS_DATES["CLUSTERING_TRAIN"]["TO"], '%Y-%m-%d'
    ).strftime('%d-%b-%y')
    summary = summary[summary['CLUSTER_ID'] != 0]
    summary['CLUSTER_ID'] = summary['CLUSTER_ID'].astype(int)
    summary['RISK_LEVEL'] = summary['RISK_LEVEL'].astype(int)
    
    return summary


def reorder_cat(df, column, ordered_levels):
    for level in ordered_levels:
        if level not in set(df.columns):
            ordered_levels.remove(level)
    df = df[ordered_levels]
    
    return df


def count_cat(df, column, ordered_levels):
    dt = df[['CLUSTER_ID', column]]
    dt = df[['CLUSTER_ID', column]]
    dt = dt.groupby(['CLUSTER_ID', column]).size().reset_index(name='counts')
    dt['size'] = dt.groupby('CLUSTER_ID')['counts'].transform('sum')
    dt['percent'] = dt['counts'] / dt['size']
    dt.drop(['counts', 'size'], axis=1, inplace=True)
    dt = dt.pivot(index='CLUSTER_ID', columns=column, values='percent').reset_index()
    dt.columns = list(dt.columns)
    dt = dt.fillna(0.0)
    dt = dt.set_index('CLUSTER_ID')
    
    dt = reorder_cat(dt, column, ordered_levels)
    
    return dt


def count_all_cats(df):

    list_df = []
    list_df.append(count_cat(df, constants.FEATURES_RISK_KEY, ['0-LOW', '1-MEDIUM', '2-HIGH']))
    list_df.append(count_cat(df, 'BNPP_ENTITY', ['BNPP_ENTITY']))
    list_df.append(count_cat(df, 'KYC_SEGMENT', ['COMMERCIAL_CORP', 'FINANCIAL_INST', 'OTHER']))

    dt = pd.concat(list_df, axis=1)
    
    return dt


def count_num(df, column):
    dt = df[['CLUSTER_ID', column]]
    dt = dt.groupby('CLUSTER_ID')[column].agg("mean").reset_index()
    dt[column] = (dt[column] - min(dt[column])) / (max(dt[column]) - min(dt[column]))
    dt = dt.set_index('CLUSTER_ID')

    return dt


def count_all_nums(df):
    list_dt = []
    for col in constants.CLUSTERS_HEATMAP_COLUMNS:
        if col in df:
            df[col] = df[col].fillna(0)
            list_dt.append(count_num(df, col))
    dt = pd.concat(list_dt, axis=1)
    
    return dt


def plot_cluster_description(parameters, features):

    cat_features = count_all_cats(features)
    num_features = count_all_nums(features)
    
    ratio = cat_features.shape[1] / num_features.shape[1]
    fig, (ax, ax2) = plt.subplots(1, 2, gridspec_kw={'width_ratios': [ratio, 1]}, figsize=(30, 15))

    fig.subplots_adjust(wspace=0.01)
    sns.heatmap(cat_features, cmap="Blues", ax=ax, cbar=False)
    sns.heatmap(num_features, cmap="Greens", ax=ax2, cbar=False)
    plt.yticks(rotation=0)
    ax2.yaxis.tick_right()
    ax.set_yticklabels(ax.get_yticklabels(), rotation=0, ha='center')
    ax.set_xticklabels(ax.get_xticklabels(), rotation=40, ha='right')
    ax2.set_yticklabels(ax2.get_yticklabels(), rotation=0, ha='center')
    ax2.set_xticklabels(ax2.get_xticklabels(), rotation=40, ha='right')
    plt.ylabel('')
    plt.setp(ax2.get_yticklabels(), visible=False)
    ax2.tick_params(axis='both', which='both', length=0)
    for label in ax.get_yticklabels():
        label.set_size(13)
        label.set_weight("bold")
    ax.set_ylabel('CLUSTER', fontweight='bold', fontsize=13)
    
    clusters_heatmap_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'clusters_files',
        'Cluster Heatmap {} {} - {}.png'.format(
            parameters.BU,
            parameters.EXPERIMENT_KEY.upper(),
            datetime.today().strftime('%y%m%d')
        )
    )
    plt.savefig(clusters_heatmap_file, bbox_inches='tight')
    

def generate_clusters_heatmap(parameters, clusters):
    parameters.CLUSTERING = PipelineArgs({"FEATURES" : parameters.FILES_EXPORT.FEATURES})
    #to prepare clustering features, we need the parameters.CLUSTERING.FEATURES var
    
    features = prepare_clustering_features(parameters, 'train')
    clusters_mapping = dict(zip(clusters['CLIENT_KEY'], clusters['CLUSTER_ID']))
    features['CLUSTER_ID'] = features['CLIENT_KEY'].map(clusters_mapping)
    features = features[features.CLUSTER_ID != 0]

    plot_cluster_description(parameters, features)


def generate_clusters_files(parameters):
    constants.LOGGER.info("FILES_EXPORT clusters step : Generate the clusters mapping and summary file")
    risk_mapping = extract_risk_mapping(parameters)
    clusters = create_cluster_mapping(parameters)
    summary = create_cluster_summary(parameters, clusters, risk_mapping)
    
    os.makedirs(
        os.path.join(constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'clusters_files'),
        exist_ok=True
    )
    clusters_mapping_file = os.path.join(
        constants.READ_WRITE_DATA_PATH, parameters.BU, 'exports', 'clusters_files',
        'CIB ITO FS - SAM8R {} {} Cluster Mapping - {}.xlsx'.format(
            parameters.BU,
            parameters.EXPERIMENT_KEY.upper(),
            datetime.today().strftime('%y%m%d')
        )
    )
    clusters_info = {
        'aml_cb_CLIENT_cluster': summary,
        'aml_cb_clusters': clusters
    }
    export_to_xlsx(
        clusters_info, clusters_mapping_file,
        subsheets=constants.CLUSTERS_FILE_SHEETS
    )

    constants.LOGGER.info("FILES_EXPORT clusters step : Generate clusters heatmap")
    generate_clusters_heatmap(parameters, clusters)
