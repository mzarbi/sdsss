import os
import sys

from .utils import constants

logger = constants.LOGGER
from .utils.parameters import Parameters

#pipeline main steps
from .serialization.parameters import serialize_parameters
from .serialization.input_data import serialize_input_data
from .cluster.features import model_features
from .cluster.clustering import cluster
from .cluster.inject import inject_clustering
from .thresholds.thresholds import generate_thresholds
from .alert_generation.alerts_generation import generate_alerts
from .kpis.compute_kpis import generate_kpis
from .exports.clusters_file import generate_clusters_files
from .exports.parameters_file import generate_parameters_files
from .exports.deployment_statistics import generate_deployment_statistics
from .exports.audit_trail import create_features_export


def run_pipeline(params):
    assert isinstance(params, Parameters)

    logger.info(
        'Starting Pipeline with steps {} for BU {}'.format(
            params.PIPELINE_STEPS,
            params.BU
        )
    )

    # Serialize default parameters
    if 'PARAMETERS_SERIALIZATION' in params.PIPELINE_STEPS:
        logger.info("PARAMETERS_SERIALIZATION step : Serialize default parameters")
        serialize_parameters(params)

    # Serialize input data
    if 'DATA_SERIALIZATION' in params.PIPELINE_STEPS:
        logger.info("DATA_SERIALIZATION step : Serialize input data")
        serialize_input_data(params)

    # Make custom features from model
    if 'CLUSTERING_FEATURES' in params.PIPELINE_STEPS:
        logger.info("CLUSTERING_FEATURES step : compute model features for clustering")
        model_features(params)

    # Make custom clusters
    if 'CLUSTERING' in params.PIPELINE_STEPS:
        logger.info("CLUSTERING step : Perform custom clustering")
        if 'FEATURES' in params.CLUSTERING:
            cluster(params)
        if 'CLUSTERS' in params.CLUSTERING:
            inject_clustering(params)

    # Review model thresholds
    if 'THRESHOLDS' in params.PIPELINE_STEPS:
        logger.info("THRESHOLDS step : Review model thresholds")
        generate_thresholds(params)

    # Generate alerts
    if 'ALERTING' in params.PIPELINE_STEPS:
        logger.info("ALERTING step : simulate Actimize and alerts")
        generate_alerts(params)

    # Extract KPIs
    if 'KPIS' in params.PIPELINE_STEPS:
        logger.info("KPIS step : extract KPIs")
        generate_kpis(params)

    # Export files after the run
    if 'FILES_EXPORT' in params.PIPELINE_STEPS:
        logger.info("FILES_EXPORT step : Export files after the run")
        if 'CLUSTERS' in params.FILES_EXPORT \
                and 'THRESHOLDS' in params.FILES_EXPORT \
                and 'PARAMETERS' in params.FILES_EXPORT:
            generate_clusters_files(params)
            generate_parameters_files(params)
            create_features_export(params)
        if 'ALERTS' in params.FILES_EXPORT:
            generate_deployment_statistics(params)
