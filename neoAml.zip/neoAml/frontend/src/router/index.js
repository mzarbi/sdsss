import { createRouter, createWebHistory } from "vue-router";
import Dashboard from "@/views/Dashboard.vue";
import NewSimulation from "@/views/NewSimulation";
import SimulationExplorer from "@/views/SimulationExplorer";
import SimulationDetail from "@/views/SimulationDetail";
import DataExplorer from "@/views/DataExplorer";

const routes = [
  {
    path: "/",
    name: "/",
    redirect: "/dashboard",
  },
  {
    path: "/dashboard",
    name: "Dashboard",
    component: Dashboard,
  },
  {
    path: "/simulation",
    name: "New Simulation",
    component: NewSimulation,
  },
  {
    path: "/simulations",
    name: "Simulation Explorer",
    component: SimulationExplorer,
  },
  {
    path: '/simulations/:id',
    name: 'Simulation',
    component: SimulationDetail
  },
  {
    path: "/data",
    name: "Data Explorer",
    component: DataExplorer,
  },


];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
  linkActiveClass: "active",
});

export default router;
