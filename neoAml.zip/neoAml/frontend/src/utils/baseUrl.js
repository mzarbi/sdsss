export function getBaseUrl() {
    if (!window.baseUrl || window.baseUrl === '{{ base_url }}') {
        window.baseUrl = 'http://127.0.0.1:5000/app';
    }
    return window.baseUrl
}
