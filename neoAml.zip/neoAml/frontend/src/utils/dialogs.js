import Swal from 'sweetalert2';
import 'sweetalert2/src/sweetalert2.scss';
import { createApp, h } from 'vue';

const baseSwalOptions = {
  customClass: {
    container: 'swal-container',
    popup: 'swal-popup',
    header: 'swal-header',
    title: 'swal-title',
    closeButton: 'swal-close-button',
    icon: 'swal-icon',
    image: 'swal-image',
    content: 'swal-content',
    input: 'swal-input',
    actions: 'swal-actions',
    confirmButton: 'swal-confirm-button',
    cancelButton: 'swal-cancel-button',
    footer: 'swal-footer',
  },
  buttonsStyling: true,
  confirmButtonText: 'OK',
  cancelButtonText: 'Cancel',
};

export const showLoadingDialog = (message = 'Loading...') => {
  Swal.fire({
    ...baseSwalOptions,
    title: message,
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading();
    },
  });
};

export const showSuccessDialog = (message = 'Operation Successful') => {
  Swal.fire({
    ...baseSwalOptions,
    title: 'Success',
    text: message,
    iconHtml: '<i class="fas fa-check-circle" style="color: #4caf50;"></i>',
  });
};

export const showErrorDialog = (message = 'An error occurred') => {
  Swal.fire({
    ...baseSwalOptions,
    title: 'Error',
    text: message,
    iconHtml: '<i class="fas fa-times-circle" style="color: #f44336;"></i>',
  });
};

export const showConfirmDialog = (message = 'Are you sure?', confirmCallback) => {
  Swal.fire({
    ...baseSwalOptions,
    title: 'Confirm',
    text: message,
    iconHtml: '<i class="fas fa-exclamation-triangle" style="color: #ff9800;"></i>',
    showCancelButton: true,
  }).then((result) => {
    if (result.isConfirmed) {
      confirmCallback();
    }
  });
};

export const showCustomDialog = (component, props = {}, options = {}) => {
  const swalOptions = {
    ...baseSwalOptions,
    ...options,
    html: '<div id="vue-custom-dialog"></div>',
    didOpen: () => {
      const container = document.getElementById('vue-custom-dialog');
      const app = createApp({
        render() {
          return h(component, props);
        },
      });
      app.mount(container);
    },
  };

  return Swal.fire(swalOptions);
};
