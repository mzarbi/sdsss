import axios from 'axios';
import Swal from 'sweetalert2';

// Create an Axios instance with default settings
const apiClient = axios.create({
  baseURL: window.baseUrl || 'http://localhost:5000', // Replace with your API base URL
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
apiClient.interceptors.request.use(
  (config) => {
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
apiClient.interceptors.response.use(
  (response) => {
    // Handle the response data
    return response;
  },
  (error) => {
    // Handle the response error
    return Promise.reject(error);
  }
);

// Function to show a loading dialog
const showLoadingDialog = (message = 'Loading...') => {
  Swal.fire({
    title: message,
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading();
    },
  });
};

// Function to close the loading dialog
const closeLoadingDialog = () => {
  Swal.close();
};

// Function to show a success dialog
const showSuccessDialog = (message = 'Operation Successful') => {
  Swal.fire({
    icon: 'success',
    title: 'Success',
    text: message,
  });
};

// Function to show an error dialog
const showErrorDialog = (message = 'An error occurred') => {
  Swal.fire({
    icon: 'error',
    title: 'Error',
    text: message,
  });
};

// Example of a utility function to get data
export const getData = async (endpoint, options = {}) => {
  const { showLoading = true, loadingMessage, successMessage, errorMessage } = options;
  if (showLoading) showLoadingDialog(loadingMessage);

  try {
    const response = await apiClient.get(endpoint);
    if (showLoading) closeLoadingDialog();
    if (successMessage) showSuccessDialog(successMessage);
    return response.data;
  } catch (error) {
    if (showLoading) closeLoadingDialog();
    if (errorMessage) showErrorDialog(errorMessage);
    console.error('Error fetching data:', error);
    throw error;
  }
};


export const postData = async (endpoint, data, options = {}) => {
  const { showLoading = true, loadingMessage, successMessage, errorMessage } = options;
  if (showLoading) showLoadingDialog(loadingMessage);

  try {
    const response = await apiClient.post(endpoint, data);
    if (showLoading) closeLoadingDialog();
    if (successMessage) showSuccessDialog(successMessage);
    return response.data;
  } catch (error) {
    if (showLoading) closeLoadingDialog();
    if (errorMessage) showErrorDialog(errorMessage);
    console.error('Error posting data:', error);
    throw error;
  }
};

export default apiClient;
