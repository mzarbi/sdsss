<template>
  <div class="card mb-4">
    <div class="card-header pb-0">
      <h6>Simulations Table</h6>
    </div>
    <div class="card-body px-0 pt-0 pb-2">
      <div class="table-responsive p-0">
        <table class="table align-items-center mb-0">
          <thead>
          <tr>
            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name</th>
            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Description</th>
            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Business Unit</th>
            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Data Start Date</th>
            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Data End Date</th>
            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Status</th>
            <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Actions</th>
          </tr>
          </thead>
          <tbody>
          <tr v-for="simulation in simulations" :key="simulation.id">
            <td>
              <div class="d-flex px-2 py-1">
                <div class="d-flex flex-column justify-content-center">
                  <a :href="`/simulations/${simulation.id}`">
                    <h6 class="mb-0 text-sm">{{ simulation.name }}</h6>
                  </a>
                </div>
              </div>
            </td>
            <td>
              <p class="text-xs font-weight-bold mb-0">{{ simulation.description }}</p>
            </td>
            <td>
              <p class="text-xs font-weight-bold mb-0">{{ simulation.business_unit }}</p>
            </td>
            <td>
              <p class="text-xs font-weight-bold mb-0">{{ simulation.data_start_date }}</p>
            </td>
            <td>
              <p class="text-xs font-weight-bold mb-0">{{ simulation.data_end_date }}</p>
            </td>
            <td>
              <span class="badge2 badge2-success" v-if="getBadgeType(simulation.status) === 'success'">{{ simulation.status }}</span>
              <span class="badge2 badge2-danger" v-if="getBadgeType(simulation.status) === 'danger'">{{ simulation.status }}</span>
              <span class="badge2 badge2-primary" v-if="getBadgeType(simulation.status) === 'primary'">{{ simulation.status }}</span>
            </td>
            <td class="align-middle">
              <button class="btn btn-danger btn-sm" @click="confirmDelete(simulation.id)">Delete</button>
            </td>
          </tr>
          </tbody>
        </table>
        <div class="pagination">
          <button @click="prevPage" :disabled="currentPage === 1">Previous</button>
          <span>Page {{ currentPage }} of {{ totalPages }}</span>
          <button @click="nextPage" :disabled="currentPage === totalPages">Next</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from "axios";
  import Swal from "sweetalert2";
  import {getBaseUrl} from "../utils/baseUrl";

  export default {
    name: "SimulationTable",
    components: {
    },
    data() {
      return {
        simulations: [],
        currentPage: 1,
        totalPages: 1,
        pageSize: 5,  // Number of simulations per page
      };
    },
    methods: {
      fetchSimulations() {
        axios.get(`${getBaseUrl()}/api/simulations?page=${this.currentPage}&size=${this.pageSize}`)
                .then(response => {
                  this.simulations = response.data.simulations;
                  this.totalPages = Math.ceil(response.data.total / this.pageSize);
                })
                .catch(error => {
                  console.error("Error fetching simulations:", error);
                });
      },
      prevPage() {
        if (this.currentPage > 1) {
          this.currentPage--;
          this.fetchSimulations();
        }
      },
      nextPage() {
        if (this.currentPage < this.totalPages) {
          this.currentPage++;
          this.fetchSimulations();
        }
      },
      getBadgeType(status) {
        switch (status) {
          case 'created':
            return 'primary';
          case 'stopped':
            return 'primary';
          case 'running':
            return 'success';
          default:
            return 'danger';
        }
      },
      confirmDelete(simulationId) {
        this.showConfirmDialog('Are you sure you want to delete this simulation?', () => {
          this.deleteSimulation(simulationId);
        });
      },
      deleteSimulation(simulationId) {
        axios.delete(`${getBaseUrl()}/api/simulations/${simulationId}`)
                .then(() => {
                  this.fetchSimulations();
                })
                .catch(error => {
                  console.error("Error deleting simulation:", error);
                });
      },
      showConfirmDialog(message, confirmCallback) {
        Swal.fire({
          title: 'Confirm',
          text: message,
          iconHtml: '<i class="fas fa-exclamation-triangle" style="color: #ff9800;"></i>',
          showCancelButton: true,
          confirmButtonText: 'Yes, delete it!',
          cancelButtonText: 'No, cancel',
        }).then((result) => {
          if (result.isConfirmed) {
            confirmCallback();
          }
        });
      }
    },
    mounted() {
      this.fetchSimulations();
    }
  };
</script>

<style>
  .pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 10px;
  }

  .pagination button {
    margin: 0 5px;
  }
  .badge2 {
    display: inline-block;
    padding: 0.25em 0.4em;
    font-size: 75%;
    font-weight: 700;
    line-height: 1;
    text-align: center;
    white-space: nowrap;
    vertical-align: baseline;
    border-radius: 0.25rem;
  }

  .badge2-primary {
    color: #fff;
    background-color: #007bff;
  }

  .badge2-success {
    color: #fff;
    background-color: #28a745;
  }

  .badge2-danger {
    color: #fff;
    background-color: #dc3545;
  }

</style>
