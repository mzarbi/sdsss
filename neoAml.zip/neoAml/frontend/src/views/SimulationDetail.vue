<template>
    <div class="py-1 container-fluid">
        <div class="mt-3 row">
            <div class="card h-100">
                <li class="list-group-item border-0 d-flex p-4 border-radius-lg">
                    <div class="d-flex flex-column">
                        <h6 class="mb-3 text-sm">{{ simulation ? simulation.flowName : 'Loading...' }}</h6>
                        <span class="mb-2 text-xs">
                          ID :
                          <span class="text-dark font-weight-bold ms-sm-2">
                            {{ simulation.id }}</span
                          >
                        </span>
                        <span class="mb-2 text-xs">
                          Business unit:
                          <span class="text-dark ms-sm-2 font-weight-bold">
                            {{ simulation.flowBusinessUnit }}</span
                          >
                        </span>

                    </div>
                    <!--
                     <div class="ms-auto text-end">
                        <a class="btn btn-link text-success px-3 mb-0" @click="editSimulation">
                            <i class="text-success fas fa-play me-2" aria-hidden="true"></i
                            >Run
                        </a>
                        <a class="btn btn-link text-primary px-3 mb-0" @click="editSimulation">
                            <i class="fas fa-pencil-alt text-primary me-2" aria-hidden="true"></i
                            >Save
                        </a>
                        <a class="btn btn-link text-danger text-gradient px-3 mb-0"
                           @click="confirmDelete(simulation.id)" >
                            <i class="far fa-trash-alt me-2 text-danger" aria-hidden="true"></i>Delete
                        </a>
                    </div>
                    -->

                </li>
            </div>
        </div>

        <div class="mt-3 row">
            <div class="card h-100">
                <ul class="list-group">
                    <div class="p-4">
                        <ul class="nav nav-tabs">
                            <li class="nav-item">
                                <strong class="nav-link" :class="{ active: activeTab === 'overview' }"
                                   @click="activeTab = 'overview'">Overview</strong>
                            </li>
                            <li class="nav-item">
                                <strong class="nav-link" :class="{ active: activeTab === 'settings' }"
                                   @click="activeTab = 'settings'">Pipeline Settings</strong>
                            </li>
                            <li class="nav-item">
                                <strong class="nav-link" :class="{ active: activeTab === 'inputs' }"
                                   @click="activeTab = 'inputs'">Inputs</strong>
                            </li>
                            <li class="nav-item">
                                <strong class="nav-link" :class="{ active: activeTab === 'fs' }"
                                   @click="activeTab = 'fs'">File System</strong>
                            </li>
                            <li class="nav-item">
                                <strong class="nav-link" :class="{ active: activeTab === 'logs' }"
                                   @click="activeTab = 'logs'">Logs</strong>
                            </li>
                        </ul>

                        <div v-if="activeTab === 'overview'">
                            <strong>Overview</strong>
                            <p>{{ simulation ? simulation.description : 'Loading...' }}</p>
                        </div>

                        <div v-if="activeTab === 'settings'">
                            <PipelineSettings :simulation="simulation"></PipelineSettings>
                        </div>

                        <div v-if="activeTab === 'inputs'">
                            <Inputs
                                    :simulation="simulation"
                            ></Inputs>
                        </div>

                        <div v-if="activeTab === 'fs'">
                            <FancyTree :simulationId="simulationId"></FancyTree>
                        </div>

                        <div v-if="activeTab === 'logs'">
                            <log-display :simulationId="simulationId"></log-display>
                        </div>
                    </div>

                </ul>
            </div>
        </div>
    </div>

</template>

<script>
    import axios from "axios";
    import Swal from "sweetalert2";
    import LogDisplay from "./components/LogDisplay";
    import FancyTree from "./components/FancyTree";
    import Inputs from "./forms/Inputs";
    import PipelineSettings from "./forms/PipelineSettings";
    import {getBaseUrl} from "../utils/baseUrl";
    export default {
        name: "SimulationDetail",
        components: {PipelineSettings, Inputs, LogDisplay, FancyTree},
        data() {
            return {
                simulation: null,
                simulationId: this.$route.params.id,
                activeTab: 'overview',
            };
        },
        created() {
            this.fetchSimulation(this.simulationId);
        },
        methods: {
            fetchSimulation(id) {
                axios.get(`${getBaseUrl()}/api/simulations/flow/${id}`)
                    .then(response => {
                        this.simulation = response.data;
                    })
                    .catch(error => {
                        console.error("Error fetching simulation:", error);
                    });
            },
            editSimulation() {
                // Handle the edit action
                console.log("Editing simulation with ID:", this.simulation.id);
            },
            confirmDelete(simulationId) {
                this.showConfirmDialog('Are you sure you want to delete this simulation?', () => {
                    this.deleteSimulation(simulationId);
                });
            },
            deleteSimulation(simulationId) {
                axios.delete(`${getBaseUrl()}/api/simulations/${simulationId}`)
                    .then(() => {
                        this.$router.push('/');
                    })
                    .catch(error => {
                        console.error("Error deleting simulation:", error);
                    });
            },
            showConfirmDialog(message, confirmCallback) {
                Swal.fire({
                    title: 'Confirm',
                    text: message,
                    iconHtml: '<i class="fas fa-exclamation-triangle" style="color: #ff9800;"></i>',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No, cancel',
                }).then((result) => {
                    if (result.isConfirmed) {
                        confirmCallback();
                    }
                });
            }
        }
    };
</script>

<style scoped>
    .navbar {
        margin-bottom: 20px;
    }

    .nav-link {
        cursor: pointer;
    }
</style>
