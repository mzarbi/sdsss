<template>
  <simulation-parameters ref="newSimParameters"></simulation-parameters>
  <new-sim-configurator
    :toggle="toggleConfigurator"
    :class="[
      this.$store.state.showConfig ? 'show' : '',
      this.$store.state.hideConfigButton ? 'd-none' : '',
    ]"
    :events="events"
    :isLoading="isLoading"
    @create-simulation="handleCreateSimulation"
  />
</template>

<script>
import NewSimConfigurator from "@/views/components/NewSimConfigurator.vue";
import SimulationParameters from "./forms/SimulationParameters";
import { mapMutations } from "vuex";
import axios from "axios";
import {getBaseUrl} from "../utils/baseUrl";

export default {
  name: "NewSimulation",
  components: {
    SimulationParameters,
    NewSimConfigurator
  },
  data() {
    return {
      isLoading: false,
      events: [],
    };
  },
  methods: {
    ...mapMutations(["toggleConfigurator"]),

    async sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    },

    async handleCreateSimulation() {
      this.isLoading = true;
      this.events = [];
      try {
        this.addEvent("Fetching parameters...");
        const parameters = this.$refs.newSimParameters.exportData();
        await this.sleep(500); // Sleep for 500ms

        this.addEvent("Validating input...");
        const validationErrors = this.validateInput(parameters);
        if (validationErrors.length > 0) {
          validationErrors.forEach(error => this.addEvent(error, 'danger'));
          this.isLoading = false;
          return;
        }
        await this.sleep(500); // Sleep for 500ms

        this.addEvent("Creating simulation...");
        const response = await axios.post(getBaseUrl() + '/api/simulations', parameters);
        this.addEvent(response.data.message);
        await this.sleep(500); // Sleep for 500ms

        parameters.id = response.data.simulation.id
        this.addEvent("Creating simulation folder...");
        await axios.post(getBaseUrl() + '/api/create-simulation-folder', parameters);
        await this.sleep(500); // Sleep for 500ms

        this.addEvent("Simulation created successfully");
        this.isLoading = false;
        this.$router.push('/simulations/' + parameters.id);
      } catch (error) {
        this.isLoading = false;
        this.addEvent("Error: " + error.message, 'danger');
        console.error("Error during simulation creation:", error);
      }
    },

    validateInput(data) {
      const errors = [];
      if (!data.flowName) {
        errors.push("Flow name is required.");
      }
      if (!data.flowActimizeVersion) {
        errors.push("Actimize version is required.");
      }
      if (data.flowModels.length === 0) {
        errors.push("At least one model must be selected.");
      }
      if (!data.flowBusinessUnit) {
        errors.push("Business unit is required.");
      }
      if (!data.flowCurrency) {
        errors.push("Currency is required.");
      }
      if (!data.flowDataStartDate) {
        errors.push("Data start date is required.");
      }
      if (!data.flowDataEndDate) {
        errors.push("Data end date is required.");
      }
      if (new Date(data.flowDataStartDate) > new Date(data.flowDataEndDate)) {
        errors.push("Data start date must be before data end date.");
      }
      if (!data.flowTrainStartDate) {
        errors.push("Training start date is required.");
      }
      if (!data.flowTrainEndDate) {
        errors.push("Training end date is required.");
      }
      if (new Date(data.flowTrainStartDate) > new Date(data.flowTrainEndDate)) {
        errors.push("Training start date must be before training end date.");
      }
      if (!data.flowTestStartDate) {
        errors.push("Test start date is required.");
      }
      if (!data.flowTestEndDate) {
        errors.push("Test end date is required.");
      }
      if (new Date(data.flowTestStartDate) > new Date(data.flowTestEndDate)) {
        errors.push("Test start date must be before test end date.");
      }
      return errors;
    },

    addEvent(message, type = 'success') {
      this.events.push({ message, type });
    },
  },
};
</script>
