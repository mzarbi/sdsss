<template>
    <div class="py-4 container-fluid" v-if="dataLoaded">
        <div class="row">
            <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4" v-for="card in statisticsCards" :key="card.title">
                <mini-statistics-card
                        :title="card.title"
                        :value="card.value"
                        :percentage="card.percentage"
                        :icon="{
                            component: card.icon.component,
                            background: iconBackground,
                        }"
                        direction-reverse
                />
            </div>
        </div>
        <div class="row">
            <div class="col-lg-7 mb-lg-0 mb-4">
                <div class="card">
                    <div class="card-body p-3">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="d-flex flex-column h-100">
                                    <p class="mb-1 pt-2 text-bold">Simulation Overview</p>
                                    <h5 class="font-weight-bolder">AML Simulations Dashboard</h5>
                                    <p class="mb-5">
                                        Detailed information about active users, simulations, ingested files, and more.
                                    </p>
                                    <a
                                            class="text-body text-sm font-weight-bold mb-0 icon-move-right mt-auto"
                                            href="javascript:;"
                                    >
                                        Read More
                                        <i
                                                class="fas fa-arrow-right text-sm ms-1"
                                                aria-hidden="true"
                                        ></i>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-5 ms-auto text-center mt-5 mt-lg-0">
                                <div class="bg-gradient-success border-radius-lg h-100">
                                    <img
                                            src="../assets/img/shapes/waves-white.svg"
                                            class="position-absolute h-100 w-50 top-0 d-lg-block d-none"
                                            alt="waves"
                                    />
                                    <div
                                            class="position-relative d-flex align-items-center justify-content-center h-100"
                                    >
                                        <img
                                                class="w-100 position-relative z-index-2 pt-4"
                                                src="../assets/img/illustrations/rocket-white.png"
                                                alt="rocket"
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="card h-100 p-3">
                    <div
                            class="overflow-hidden position-relative border-radius-lg bg-cover h-100"
                            :style="{ backgroundImage: 'url(' + backgroundImageUrl + ')' }"
                    >
                        <span class="mask bg-gradient-dark"></span>
                        <div class="card-body position-relative z-index-1 p-3 h-100">
                            <div class="d-flex flex-column h-100">
                                <h5 class="text-white font-weight-bolder mb-4 pt-2">
                                    Work with the simulations
                                </h5>
                                <p class="text-white mb-5">
                                    Gain insights into AML simulations and manage tasks efficiently.
                                </p>
                                <a
                                        class="text-white font-weight-bold ps-1 mb-0 icon-move-left mt-auto"
                                        href="javascript:;"
                                >
                                    Read more
                                    <i
                                            class="fas fa-arrow-right text-sm ms-1"
                                            aria-hidden="true"
                                    ></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-4 row">
            <div class="mb-4 col-lg-5 mb-lg-0">
                <div class="card z-index-2">
                    <div class="p-3 card-body">
                        <reports-bar-chart
                                id="chart-bar"
                                title="Active Users"
                                :description="barChartDescription"
                                :chart="barChartData"
                                :items="barChartItems"
                        />
                    </div>
                </div>
            </div>
            <div class="col-lg-7">
                <div class="card z-index-2">
                    <gradient-line-chart
                            id="chart-line"
                            title="Simulations Trend"
                            :description="lineChartDescription"
                            :chart="lineChartData"
                    />
                </div>
            </div>
        </div>
        <div class="row my-4">
            <div class="col-lg-8 col-md-6 mb-md-0 mb-4">
                <simulations-card :simulations="recentSimulations"/>
            </div>
            <div class="col-lg-4 col-md-6">
                <timeline-list
                        class="h-100"
                        title="Simulations Overview"
                        :description="timelineDescription"
                >
                    <timeline-item
                            v-for="item in timelineItems"
                            :key="item.title"
                            :color="item.color"
                            :icon="item.icon"
                            :title="item.title"
                            :date-time="item.dateTime"
                    />
                </timeline-list>
            </div>
        </div>
    </div>
</template>


<script>
    import MiniStatisticsCard from "@/examples/Cards/MiniStatisticsCard.vue";
    import ReportsBarChart from "@/examples/Charts/ReportsBarChart.vue";
    import GradientLineChart from "@/examples/Charts/GradientLineChart.vue";
    import TimelineList from "./components/TimelineList.vue";
    import TimelineItem from "./components/TimelineItem.vue";
    import SimulationsCard from "./components/SimulationsCard.vue";
    import {
        faHandPointer,
        faUsers,
        faCreditCard,
        faScrewdriverWrench,
    } from "@fortawesome/free-solid-svg-icons";
    import {getData} from "../utils/apiClient";
    import {getBaseUrl} from "../utils/baseUrl";
    export default {
        name: "dashboard-default",
        data() {
            return {
                dataLoaded: false,
                iconBackground: "bg-gradient-success",
                faCreditCard,
                faScrewdriverWrench,
                faUsers,
                faHandPointer,
                backgroundImageUrl: 'https://demos.creative-tim.com/soft-ui-dashboard/assets/img/ivancik.jpg',
                statisticsCards: [],
                activeUsersData: [],
                simulationsData: [],
                completedTasksData: [],
                barChartData: {},
                barChartItems: [],
                lineChartData: {},
                recentSimulations: [],
                timelineItems: [],
            };
        },
        components: {
            MiniStatisticsCard,
            ReportsBarChart,
            GradientLineChart,
            SimulationsCard,
            TimelineList,
            TimelineItem,
        },
        methods: {
            fetchData() {
                getData(getBaseUrl() + '/dashboard/data', {errorMessage: "Could not fetch dashboard data."})  // Update the URL to your API endpoint
                    .then(response => {
                        this.dataLoaded = true;
                        this.statisticsCards = response.statisticsCards;
                        this.activeUsersData = response.activeUsersData;
                        this.simulationsData = response.simulationsData;
                        this.completedTasksData = response.completedTasksData;
                        this.barChartData = response.barChartData;
                        this.barChartDescription = response.barChartDescription;
                        this.barChartItems = response.barChartItems;
                        this.lineChartData = response.lineChartData;
                        this.lineChartDescription = response.lineChartDescription;
                        this.recentSimulations = response.recentSimulations;
                        this.timelineDescription = response.timelineDescription;
                        this.timelineItems = response.timelineItems;
                    })
                    .catch(error => {
                        console.error('Error fetching data:', error);
                    });
            }
        },
        created() {
            this.fetchData();
        }
    };
</script>
