<template>
    <li class="px-0 border-0 list-group-item" :data-tooltip="tooltip">
        <label>{{ label }}</label>
        <textarea
                class="form-control"
                aria-label="With textarea"
                v-model="localValue"
        ></textarea>
    </li>
</template>

<script>
    export default {
        props: {
            label: String,
            modelValue: String,
            tooltip: String,
        },
        data() {
            return {
                localValue: this.modelValue,
            };
        },
        watch: {
            modelValue(newValue) {
                this.localValue = newValue;
            },
            localValue(newValue) {
                this.$emit('update:modelValue', newValue);
            },
        },
    };
</script>
