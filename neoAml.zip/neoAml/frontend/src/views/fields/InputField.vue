<template>
    <li class="px-0 border-0 list-group-item" :data-tooltip="tooltip">
        <label>{{ label }}</label>
        <input
                class="cselect"
                :placeholder="placeholder"
                v-model="localValue"
                :disabled="disabled"
        />
    </li>
</template>

<script>
    export default {
        props: {
            label: String,
            placeholder: String,
            modelValue: [String, Number],
            disabled: Boolean,
            tooltip: String,
            type: String
        },
        data() {
            return {
                localValue: this.modelValue,
            };
        },
        watch: {
            modelValue(newValue) {
                this.localValue = newValue;
            },
            localValue(newValue) {
                this.$emit('update:modelValue', newValue);
            },
        },
    };
</script>
