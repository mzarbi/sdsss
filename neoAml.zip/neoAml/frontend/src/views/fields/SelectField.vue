<template>
    <li class="px-0 border-0 list-group-item" :data-tooltip="tooltip">
        <label>{{ label }}</label>
        <select class="cselect" v-model="localValue">
            <option v-for="option in options" :key="option.id" :value="option[field]">{{ option[display] }}</option>
        </select>
    </li>
</template>

<script>
    export default {
        props: {
            label: String,
            modelValue: [String, Number],
            options: Array,
            tooltip: String,
            field: String,
            display: String
        },
        data() {
            return {
                localValue: this.modelValue,
            };
        },
        watch: {
            modelValue(newValue) {
                this.localValue = newValue;
            },
            localValue(newValue) {
                this.$emit('update:modelValue', newValue);
            },
        },
    };
</script>
