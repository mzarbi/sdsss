<template>
    <li class="px-0 border-0 list-group-item" :data-tooltip="tooltip">
        <label>{{ label }}</label>
        <select class="cselect" v-model="localValue" multiple>
            <option v-for="option in options" :key="option.id" :value="option.name">{{ option.name }}</option>
        </select>
    </li>
</template>

<script>
    export default {
        props: {
            label: String,
            modelValue: {
                type: Array,
                default: () => [],
            },
            options: Array,
            tooltip: String,
        },
        data() {
            return {
                localValue: this.modelValue,
            };
        },
        watch: {
            modelValue(newValue) {
                this.localValue = newValue;
            },
            localValue(newValue) {
                this.$emit('update:modelValue', newValue);
            },
        },
    };
</script>
