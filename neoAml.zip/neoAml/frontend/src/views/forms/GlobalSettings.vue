<template>
    <div>
        <CollapsibleCard
                ref="collapsibleCard"
                title="Global Settings"
                description="This is a description of the card"
                :showRunBtn="false"
                :collapsed="true"
                @save-step="handleSaveStep"
                @run-step="handleRunStep"
                @edit-step="handleEditStep"
        >
            <template #default="{ isEditMode, formData }">
                <div v-if="isEditMode" style="padding: 1rem">
                    <form @submit.prevent="handleSubmit(formData)">
                        <!-- General Settings Section -->
                        <section>
                            <h5>General Settings</h5>
                            <div class="form-group">
                                <label for="modelVersion">Model Version</label>
                                <input type="text" id="modelVersion" v-model="MODEL_VERSION" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="bu">BU</label>
                                <input type="text" id="bu" v-model="BU" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="localCurrencyRate">Local Currency Rate</label>
                                <input type="number" id="localCurrencyRate" v-model.number="LOCAL_CURRENCY_RATE" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="lookbackPeriod">Lookback Period</label>
                                <input type="number" id="lookbackPeriod" v-model.number="LOOKBACK_PERIOD" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="bucketMappingMode">Bucket Mapping Mode</label>
                                <input type="text" id="bucketMappingMode" v-model="BUCKET_MAPPING_MODE" class="form-control" @input="syncJsonString()" />
                            </div>
                        </section>

                        <!-- EFT Constant Thresholds Section -->
                        <section>
                            <h5>EFT Constant Thresholds</h5>
                            <div class="form-group">
                                <label for="eftCash">EFT Cash Threshold</label>
                                <input type="number" id="eftCash" v-model.number="EFT_CONSTANT_THRESHOLDS___Cash" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="eftCheck">EFT Check Threshold</label>
                                <input type="number" id="eftCheck" v-model.number="EFT_CONSTANT_THRESHOLDS___Check" class="form-control" @input="syncJsonString()" />
                            </div>
                        </section>

                        <!-- Analysis Dates Section -->
                        <section>
                            <h5>Analysis Dates</h5>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th></th>
                                    <th>From</th>
                                    <th>To</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Data</td>
                                    <td><input type="date" v-model="ANALYSIS_DATES___DATA___FROM" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="date" v-model="ANALYSIS_DATES___DATA___TO" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                <tr>
                                    <td>Train</td>
                                    <td><input type="date" v-model="ANALYSIS_DATES___TRAIN___FROM" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="date" v-model="ANALYSIS_DATES___TRAIN___TO" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                <tr>
                                    <td>Test</td>
                                    <td><input type="date" v-model="ANALYSIS_DATES___TEST___FROM" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="date" v-model="ANALYSIS_DATES___TEST___TO" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                </tbody>
                            </table>
                        </section>


                        <!-- Standard Percentile Section -->
                        <section>
                            <h5>Standard Percentile</h5>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th></th>
                                    <th>LOW RISK</th>
                                    <th>MEDIUM RISK</th>
                                    <th>HIGH RISK</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Excessive Single Transactions</td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Excessive_Single_Transactions___0" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Excessive_Single_Transactions___1" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Excessive_Single_Transactions___2" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                <tr>
                                    <td>Flow Through of Funds</td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___0" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___1" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___2" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                <tr>
                                    <td>Transfer to/from High-Risk Countries (Level 3)</td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___0" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___1" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___2" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                <tr>
                                    <td>Transfer to/from Very High-Risk Countries (Level 4)</td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___0" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___1" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___2" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                </tbody>
                            </table>
                        </section>

                        <!-- Percent Escalation Significantly Below, Hits Account Significantly Above, Hits From Escalation Significantly Above Section -->
                        <section>
                            <h5>Thresholds and Hits</h5>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th></th>
                                    <th>Percent Escalation Significantly Below</th>
                                    <th>Hits Account Significantly Above</th>
                                    <th>Hits From Escalation Significantly Above</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>Flow Through of Funds (Credits / Debits)</td>
                                    <td><input type="number" v-model.number="PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Flow_Through_of_Funds_Credits_Debits" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Flow_Through_of_Funds_Credits_Debits" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Flow_Through_of_Funds_Credits_Debits" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                <tr>
                                    <td>Excessive Single Transactions</td>
                                    <td><input type="number" v-model.number="PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Excessive_Single_Transactions" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Excessive_Single_Transactions" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Excessive_Single_Transactions" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                <tr>
                                    <td>Transfer to/from High-Risk Countries (Level 3)</td>
                                    <td><input type="number" v-model.number="PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Transfer_to_from_High_Risk_Countries_Level_3" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Transfer_to_from_High_Risk_Countries_Level_3" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Transfer_to_from_High_Risk_Countries_Level_3" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                <tr>
                                    <td>Transfer to/from Very High-Risk Countries (Level 4)</td>
                                    <td><input type="number" v-model.number="PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Transfer_to_from_Very_High_Risk_Countries_Level_4" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Transfer_to_from_Very_High_Risk_Countries_Level_4" class="form-control" @input="syncJsonString()" /></td>
                                    <td><input type="number" v-model.number="HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Transfer_to_from_Very_High_Risk_Countries_Level_4" class="form-control" @input="syncJsonString()" /></td>
                                </tr>
                                </tbody>
                            </table>
                        </section>

                    </form>
                </div>
                <div v-else style="padding: 1rem">
                    <textarea v-model="jsonString" @input="updateFormDataFromJson" class="form-control" style="height: 500px;"></textarea>
                </div>
            </template>
        </CollapsibleCard>
    </div>
</template>


<script>
    import CollapsibleCard from '../components/CollapsibleCard';
    import axios from "axios";
    import {getBaseUrl} from "../../utils/baseUrl";
    export default {
        name: 'GlobalSettings',
        components: {CollapsibleCard},
        props:["simulationId"],
        data() {
            return {
                MODEL_VERSION: "SAM8",
                BU: "ARE",
                LOCAL_CURRENCY_RATE: 1.0,
                LOOKBACK_PERIOD: 2,
                BUCKET_MAPPING_MODE: "SIMPLE",
                EFT_CONSTANT_THRESHOLDS___Cash: 15000,
                EFT_CONSTANT_THRESHOLDS___Check: 15000,
                ANALYSIS_DATES___DATA___FROM: "2021-03-01",
                ANALYSIS_DATES___DATA___TO: "2022-05-31",
                ANALYSIS_DATES___TRAIN___FROM: "2021-03-01",
                ANALYSIS_DATES___TRAIN___TO: "2022-02-28",
                ANALYSIS_DATES___TEST___FROM: "2022-03-01",
                ANALYSIS_DATES___TEST___TO: "2022-05-31",
                STANDARD_PERCENTILE___Excessive_Single_Transactions___0: 95,
                STANDARD_PERCENTILE___Excessive_Single_Transactions___1: 85,
                STANDARD_PERCENTILE___Excessive_Single_Transactions___2: 75,
                STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___0: 95,
                STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___1: 85,
                STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___2: 75,
                STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___0: 98,
                STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___1: 85,
                STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___2: 75,
                STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___0: 95,
                STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___1: 80,
                STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___2: 70,
                PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Flow_Through_of_Funds_Credits_Debits: 60,
                PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Excessive_Single_Transactions: 60,
                PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Transfer_to_from_High_Risk_Countries_Level_3: 60,
                PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Transfer_to_from_Very_High_Risk_Countries_Level_4: 30,
                HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Flow_Through_of_Funds_Credits_Debits: 25,
                HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Excessive_Single_Transactions: 50,
                HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Transfer_to_from_High_Risk_Countries_Level_3: 50,
                HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Transfer_to_from_Very_High_Risk_Countries_Level_4: 130,
                HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Flow_Through_of_Funds_Credits_Debits: 25,
                HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Excessive_Single_Transactions: 50,
                HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Transfer_to_from_High_Risk_Countries_Level_3: 50,
                HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Transfer_to_from_Very_High_Risk_Countries_Level_4: 130,

                jsonString: ''
            };
        },

        watch:{
            jsonString: {
                handler() {
                    this.updateFormDataFromJson();
                    console.log(this.jsonString);
                },
                immediate: true,
            },
        },
        created() {
            this.syncJsonString();
        },
        mounted() {
            this.loadInitialData();
        },
        methods: {
            loadInitialData() {
                axios.get(getBaseUrl() + '/api/load-gs/' + this.simulationId)
                    .then(response => {
                        this.jsonString = JSON.stringify(response.data, null, 2);
                        this.updateFormDataFromJson();
                    })
                    .catch(error => {
                        console.error('Error loading initial data:', error);
                    });
            },
            handleSaveStep() {
                this.syncJsonString();
                axios.post(getBaseUrl() + '/api/save-gs/' + this.simulationId, { data: JSON.parse(this.jsonString) })
                    .catch(error => {
                        console.error('Save error:', error);
                    });
            },
            handleRunStep() {
                console.log('Run Step button clicked');
                // Add your logic here
            },
            handleEditStep() {

            },
            handleSubmit(formData) {
                this.jsonString = JSON.stringify(this.convertFormDataToJson(formData), null, 2);
            },
            syncJsonString() {
                this.jsonString = JSON.stringify(this.convertFormDataToJson(), null, 2);
            },
            convertFormDataToJson() {
                return {
                    MODEL_VERSION: this.MODEL_VERSION,
                    LIST_MODEL: ["EFT", "FTF", "TSD"],
                    BU: this.BU,
                    LOCAL_CURRENCY_RATE: this.LOCAL_CURRENCY_RATE,
                    LOOKBACK_PERIOD: this.LOOKBACK_PERIOD,
                    BUCKET_MAPPING_MODE: this.BUCKET_MAPPING_MODE,
                    EFT_CONSTANT_THRESHOLDS: {
                        Cash: this.EFT_CONSTANT_THRESHOLDS___Cash,
                        Check: this.EFT_CONSTANT_THRESHOLDS___Check
                    },
                    ANALYSIS_DATES: {
                        DATA: {
                            FROM: this.ANALYSIS_DATES___DATA___FROM,
                            TO: this.ANALYSIS_DATES___DATA___TO
                        },
                        TRAIN: {
                            FROM: this.ANALYSIS_DATES___TRAIN___FROM,
                            TO: this.ANALYSIS_DATES___TRAIN___TO
                        },
                        TEST: {
                            FROM: this.ANALYSIS_DATES___TEST___FROM,
                            TO: this.ANALYSIS_DATES___TEST___TO
                        }
                    },
                    STANDARD_PERCENTILE: {
                        "Excessive Single Transactions": [
                            this.STANDARD_PERCENTILE___Excessive_Single_Transactions___0,
                            this.STANDARD_PERCENTILE___Excessive_Single_Transactions___1,
                            this.STANDARD_PERCENTILE___Excessive_Single_Transactions___2
                        ],
                        "Flow Through of Funds (Credits / Debits)": [
                            this.STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___0,
                            this.STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___1,
                            this.STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___2
                        ],
                        "Transfer to/from High-Risk Countries (Level 3)": [
                            this.STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___0,
                            this.STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___1,
                            this.STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___2
                        ],
                        "Transfer to/from Very High-Risk Countries (Level 4)": [
                            this.STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___0,
                            this.STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___1,
                            this.STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___2
                        ]
                    },
                    PERCENT_ESCALATION_SIGNIFICANTLY_BELOW: {
                        "Flow Through of Funds (Credits / Debits)": this.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Flow_Through_of_Funds_Credits_Debits,
                        "Excessive Single Transactions": this.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Excessive_Single_Transactions,
                        "Transfer to/from High-Risk Countries (Level 3)": this.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Transfer_to_from_High_Risk_Countries_Level_3,
                        "Transfer to/from Very High-Risk Countries (Level 4)": this.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Transfer_to_from_Very_High_Risk_Countries_Level_4
                    },
                    HITS_ACCOUNT_SIGNIFICANTLY_ABOVE: {
                        "Flow Through of Funds (Credits / Debits)": this.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Flow_Through_of_Funds_Credits_Debits,
                        "Excessive Single Transactions": this.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Excessive_Single_Transactions,
                        "Transfer to/from High-Risk Countries (Level 3)": this.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Transfer_to_from_High_Risk_Countries_Level_3,
                        "Transfer to/from Very High-Risk Countries (Level 4)": this.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Transfer_to_from_Very_High_Risk_Countries_Level_4
                    },
                    HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE: {
                        "Flow Through of Funds (Credits / Debits)": this.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Flow_Through_of_Funds_Credits_Debits,
                        "Excessive Single Transactions": this.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Excessive_Single_Transactions,
                        "Transfer to/from High-Risk Countries (Level 3)": this.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Transfer_to_from_High_Risk_Countries_Level_3,
                        "Transfer to/from Very High-Risk Countries (Level 4)": this.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Transfer_to_from_Very_High_Risk_Countries_Level_4
                    }
                };
            },
            updateFormDataFromJson() {
                try {
                    const parsed = JSON.parse(this.jsonString);
                    this.convertJsonToFormData(parsed);

                } catch (e) {
                    console.error('Invalid JSON');
                    console.error(e);
                }
            },
            convertJsonToFormData(jsonData) {
                this.MODEL_VERSION = jsonData.MODEL_VERSION;
                this.BU = jsonData.BU;
                this.LOCAL_CURRENCY_RATE = jsonData.LOCAL_CURRENCY_RATE;
                this.LOOKBACK_PERIOD = jsonData.LOOKBACK_PERIOD;
                this.BUCKET_MAPPING_MODE = jsonData.BUCKET_MAPPING_MODE;
                this.EFT_CONSTANT_THRESHOLDS___Cash = jsonData.EFT_CONSTANT_THRESHOLDS.Cash;
                this.EFT_CONSTANT_THRESHOLDS___Check = jsonData.EFT_CONSTANT_THRESHOLDS.Check;
                this.ANALYSIS_DATES___DATA___FROM = jsonData.ANALYSIS_DATES.DATA.FROM;
                this.ANALYSIS_DATES___DATA___TO = jsonData.ANALYSIS_DATES.DATA.TO;
                this.ANALYSIS_DATES___TRAIN___FROM = jsonData.ANALYSIS_DATES.TRAIN.FROM;
                this.ANALYSIS_DATES___TRAIN___TO = jsonData.ANALYSIS_DATES.TRAIN.TO;
                this.ANALYSIS_DATES___TEST___FROM = jsonData.ANALYSIS_DATES.TEST.FROM;
                this.ANALYSIS_DATES___TEST___TO = jsonData.ANALYSIS_DATES.TEST.TO;
                this.STANDARD_PERCENTILE___Excessive_Single_Transactions___0 = jsonData.STANDARD_PERCENTILE["Excessive Single Transactions"][0];
                this.STANDARD_PERCENTILE___Excessive_Single_Transactions___1 = jsonData.STANDARD_PERCENTILE["Excessive Single Transactions"][1];
                this.STANDARD_PERCENTILE___Excessive_Single_Transactions___2 = jsonData.STANDARD_PERCENTILE["Excessive Single Transactions"][2];
                this.STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___0 = jsonData.STANDARD_PERCENTILE["Flow Through of Funds (Credits / Debits)"][0];
                this.STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___1 = jsonData.STANDARD_PERCENTILE["Flow Through of Funds (Credits / Debits)"][1];
                this.STANDARD_PERCENTILE___Flow_Through_of_Funds_Credits_Debits___2 = jsonData.STANDARD_PERCENTILE["Flow Through of Funds (Credits / Debits)"][2];
                this.STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___0 = jsonData.STANDARD_PERCENTILE["Transfer to/from High-Risk Countries (Level 3)"][0];
                this.STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___1 = jsonData.STANDARD_PERCENTILE["Transfer to/from High-Risk Countries (Level 3)"][1];
                this.STANDARD_PERCENTILE___Transfer_to_from_High_Risk_Countries_Level_3___2 = jsonData.STANDARD_PERCENTILE["Transfer to/from High-Risk Countries (Level 3)"][2];
                this.STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___0 = jsonData.STANDARD_PERCENTILE["Transfer to/from Very High-Risk Countries (Level 4)"][0];
                this.STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___1 = jsonData.STANDARD_PERCENTILE["Transfer to/from Very High-Risk Countries (Level 4)"][1];
                this.STANDARD_PERCENTILE___Transfer_to_from_Very_High_Risk_Countries_Level_4___2 = jsonData.STANDARD_PERCENTILE["Transfer to/from Very High-Risk Countries (Level 4)"][2];
                this.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Flow_Through_of_Funds_Credits_Debits = jsonData.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW["Flow Through of Funds (Credits / Debits)"];
                this.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Excessive_Single_Transactions = jsonData.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW["Excessive Single Transactions"];
                this.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Transfer_to_from_High_Risk_Countries_Level_3 = jsonData.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW["Transfer to/from High-Risk Countries (Level 3)"];
                this.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW___Transfer_to_from_Very_High_Risk_Countries_Level_4 = jsonData.PERCENT_ESCALATION_SIGNIFICANTLY_BELOW["Transfer to/from Very High-Risk Countries (Level 4)"];
                this.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Flow_Through_of_Funds_Credits_Debits = jsonData.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE["Flow Through of Funds (Credits / Debits)"];
                this.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Excessive_Single_Transactions = jsonData.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE["Excessive Single Transactions"];
                this.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Transfer_to_from_High_Risk_Countries_Level_3 = jsonData.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE["Transfer to/from High-Risk Countries (Level 3)"];
                this.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE___Transfer_to_from_Very_High_Risk_Countries_Level_4 = jsonData.HITS_ACCOUNT_SIGNIFICANTLY_ABOVE["Transfer to/from Very High-Risk Countries (Level 4)"];
                this.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Flow_Through_of_Funds_Credits_Debits = jsonData.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE["Flow Through of Funds (Credits / Debits)"];
                this.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Excessive_Single_Transactions = jsonData.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE["Excessive Single Transactions"];
                this.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Transfer_to_from_High_Risk_Countries_Level_3 = jsonData.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE["Transfer to/from High-Risk Countries (Level 3)"];
                this.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE___Transfer_to_from_Very_High_Risk_Countries_Level_4 = jsonData.HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE["Transfer to/from Very High-Risk Countries (Level 4)"]

            }
        }
    };
</script>

<style scoped>
    .form-group {
        margin-bottom: 1rem;
    }
    .form-control {
        font-family: monospace;
    }
</style>
