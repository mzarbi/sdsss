<template>
    <div>
        <CollapsibleCard
                ref="collapsibleCard"
                title="Step5"
                description="Settings related to file exports"
                :showRunBtn="true"
                :collapsed="true"
                @save-step="handleSaveStep"
                @run-step="handleRunStep"
                @edit-step="handleEditStep"
        >
            <template #default="{ isEditMode, formData }">
                <div v-if="isEditMode" style="padding: 1rem">
                    <form @submit.prevent="handleSubmit(formData)">
                        <!-- General Settings Section -->
                        <section>
                            <h5>General Settings</h5>
                            <div class="form-group">
                                <label for="experimentKey">Experiment Key</label>
                                <input type="text" id="experimentKey" v-model="EXPERIMENT_KEY" class="form-control" @input="syncJsonString()" />
                            </div>
                        </section>

                        <!-- Files Export Section -->
                        <section>
                            <h5>Files Export</h5>
                            <div class="form-group">
                                <label for="filesExportFeatures">Features</label>
                                <input type="text" id="filesExportFeatures" v-model="FILES_EXPORT_FEATURES" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="filesExportThresholds">Thresholds</label>
                                <input type="text" id="filesExportThresholds" v-model="FILES_EXPORT_THRESHOLDS" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="filesExportParameters">Parameters</label>
                                <input type="text" id="filesExportParameters" v-model="FILES_EXPORT_PARAMETERS" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="filesExportTransactions">Transactions</label>
                                <input type="text" id="filesExportTransactions" v-model="FILES_EXPORT_TRANSACTIONS" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="filesExportClusters">Clusters</label>
                                <input type="text" id="filesExportClusters" v-model="FILES_EXPORT_CLUSTERS" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="filesExportAlerts">Alerts</label>
                                <input type="text" id="filesExportAlerts" v-model="FILES_EXPORT_ALERTS" class="form-control" @input="syncJsonString()" />
                            </div>
                        </section>
                    </form>
                </div>
                <div v-else style="padding: 1rem">
                    <textarea v-model="jsonString" @input="updateFormDataFromJson" class="form-control" style="height: 500px;"></textarea>
                </div>
            </template>
        </CollapsibleCard>
    </div>
</template>
<script>
    import axios from 'axios';
    import CollapsibleCard from '../components/CollapsibleCard';
    import {getBaseUrl} from "../../utils/baseUrl";

    export default {
        name: 'PipelineSettings',
        components: { CollapsibleCard },
        props: ["simulationId"],
        data() {
            return {
                EXPERIMENT_KEY: "run0_simul",
                FILES_EXPORT_FEATURES: "run0_simul",
                FILES_EXPORT_THRESHOLDS: "run0_simul",
                FILES_EXPORT_PARAMETERS: "RAW",
                FILES_EXPORT_TRANSACTIONS: "run0_simul",
                FILES_EXPORT_CLUSTERS: "run0_simul",
                FILES_EXPORT_ALERTS: "run0_AMLIT",
                jsonString: ''
            };
        },

        watch: {
            jsonString: {
                handler() {
                    this.updateFormDataFromJson();
                },
                immediate: true,
            },
        },
        created() {
            this.syncJsonString();
        },
        mounted() {
            this.loadInitialData();
        },
        methods: {
            loadInitialData() {
                axios.get(getBaseUrl() + '/api/load-step/' + this.simulationId + '/5')
                    .then(response => {
                        this.jsonString = JSON.stringify(response.data, null, 2);
                        this.updateFormDataFromJson();
                    })
                    .catch(error => {
                        console.error('Error loading initial data:', error);
                    });
            },
            handleSaveStep() {
                this.syncJsonString();
                axios.post(getBaseUrl() + '/api/save-step/' + this.simulationId + '/5', { data: JSON.parse(this.jsonString) })
                    .catch(error => {
                        console.error('Save error:', error);
                    });
            },
            handleRunStep() {
                this.syncJsonString();
                axios.post(getBaseUrl() + '/api/run-step/' + this.simulationId + '/5', { data: JSON.parse(this.jsonString) })
                    .catch(error => {
                        console.error('Run error:', error);
                    });
            },
            handleEditStep() {
                // Add your logic here
            },
            syncJsonString() {
                this.jsonString = JSON.stringify(this.convertFormDataToJson(), null, 2);
            },
            convertFormDataToJson() {
                return {
                    EXPERIMENT_KEY: this.EXPERIMENT_KEY,
                    PIPELINE_STEPS: {
                        FILES_EXPORT: {
                            FEATURES: this.FILES_EXPORT_FEATURES,
                            THRESHOLDS: this.FILES_EXPORT_THRESHOLDS,
                            PARAMETERS: this.FILES_EXPORT_PARAMETERS,
                            TRANSACTIONS: this.FILES_EXPORT_TRANSACTIONS,
                            CLUSTERS: this.FILES_EXPORT_CLUSTERS,
                            ALERTS: this.FILES_EXPORT_ALERTS
                        }
                    }
                };
            },
            updateFormDataFromJson() {
                try {
                    const parsed = JSON.parse(this.jsonString);
                    this.convertJsonToFormData(parsed);
                } catch (e) {
                    console.error('Invalid JSON');
                    console.error(e);
                }
            },
            convertJsonToFormData(jsonData) {
                this.EXPERIMENT_KEY = jsonData.EXPERIMENT_KEY;
                this.FILES_EXPORT_FEATURES = jsonData.PIPELINE_STEPS.FILES_EXPORT.FEATURES;
                this.FILES_EXPORT_THRESHOLDS = jsonData.PIPELINE_STEPS.FILES_EXPORT.THRESHOLDS;
                this.FILES_EXPORT_PARAMETERS = jsonData.PIPELINE_STEPS.FILES_EXPORT.PARAMETERS;
                this.FILES_EXPORT_TRANSACTIONS = jsonData.PIPELINE_STEPS.FILES_EXPORT.TRANSACTIONS;
                this.FILES_EXPORT_CLUSTERS = jsonData.PIPELINE_STEPS.FILES_EXPORT.CLUSTERS;
                this.FILES_EXPORT_ALERTS = jsonData.PIPELINE_STEPS.FILES_EXPORT.ALERTS;
            }
        }
    };
</script>
<style scoped>
    .form-group {
        margin-bottom: 1rem;
    }
    .form-control {
        font-family: monospace;
    }
</style>
