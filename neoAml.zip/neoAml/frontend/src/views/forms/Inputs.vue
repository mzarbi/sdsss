<template>
    <div class="card mb-4">
        <div class="card-header pb-0">
            <h6>Create Simulation Files</h6>
        </div>
        <div class="card-body px-0 pt-0 pb-2">
            <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                    <thead>
                    <tr>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Data Type</th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Start
                            Date
                        </th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">End Date
                        </th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Actimize
                            Version
                        </th>
                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Controls
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="(file, index) in files" :key="index">
                        <td>
                            <div class="d-flex px-2 py-1">
                                <div class="d-flex flex-column justify-content-center">
                                    <h6 class="mb-0 text-sm">{{ file.dataType }}</h6>
                                </div>
                            </div>
                        </td>
                        <td v-if="file.hasStartDate">
                            <input type="date" v-model="file.startDate" class="form-control"/>
                        </td>
                        <td v-else>
                            <p class="text-xs font-weight-bold mb-0">N/A</p>
                        </td>
                        <td v-if="file.hasEndDate">
                            <input type="date" v-model="file.endDate" class="form-control"/>
                        </td>
                        <td v-else>
                            <p class="text-xs font-weight-bold mb-0">N/A</p>
                        </td>
                        <td v-if="file.hasActimizeVersion">
                            <select v-model="file.actimizeVersion" class="form-control">
                                <option value="V3">V3</option>
                                <option value="V8">V8</option>
                                <option value="VFT">VFT</option>
                            </select>
                        </td>
                        <td v-else>
                            <p class="text-xs font-weight-bold mb-0">N/A</p>
                        </td>
                        <td style="width: 150px">
                            <div class="d-flex flex-column">
                                <a class="btn btn-link text-secondary px-3 mb-0" @click="checkFiles(index)">
                                    <i class="text-secondary fas fa-search me-2" aria-hidden="true"></i>Check
                                </a>
                                <a :class="['btn btn-link text-primary px-3 mb-0', { loading: file.loading }]"
                                   @click="downloadFiles(index)">
                                    <i class="text-primary fas fa-folder-plus me-2" aria-hidden="true"></i>Download
                                </a>
                            </div>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
    import Swal from 'sweetalert2';
    import axios from 'axios';
    import {getBaseUrl} from "../../utils/baseUrl";

    export default {
        props: ['simulation'],
        data() {
            return {
                files: [
                    {
                        dataType: 'Parameters',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'Payments',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'Postings',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'Alerts',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'Alerts Notes',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'Alerts Steps',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'It alerts',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'Parties',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'Buckets',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'Accounts',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: true,
                        hasEndDate: true,
                        hasActimizeVersion: true,
                        loading: false
                    },
                    {
                        dataType: 'GCARS report',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.simulation.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: false,
                        hasEndDate: false,
                        hasActimizeVersion: false,
                        loading: false
                    },
                    {
                        dataType: 'KYC reliance worldwide',
                        startDate: this.simulation.flowDataStartDate,
                        endDate: this.flowDataEndDate,
                        actimizeVersion: this.simulation.flowActimizeVersion,
                        hasStartDate: false,
                        hasEndDate: false,
                        hasActimizeVersion: false,
                        loading: false
                    },
                ],
            };
        },
        methods: {
            async checkFiles(index) {
                const file = this.files[index];
                try {
                    const response = await axios.post(`${getBaseUrl()}/fs/check_files`, {
                        dataType: file.dataType,
                        startDate: file.startDate,
                        endDate: file.endDate,
                        actimizeVersion: file.actimizeVersion
                    });
                    Swal.fire({
                        title: 'Files Check',
                        text: `${response.data.count} files found for data type: ${file.dataType}`,
                        icon: 'info',
                    });
                } catch (error) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Failed to check files',
                        icon: 'error',
                    });
                }
            },
            async downloadFiles(index) {
                const file = this.files[index];
                file.loading = true;
                try {
                    await axios.post(`${getBaseUrl()}/fs/download_files/${this.simulation.id}`, {
                        dataType: file.dataType,
                        startDate: file.startDate,
                        endDate: file.endDate,
                        actimizeVersion: file.actimizeVersion
                    });
                    Swal.fire({
                        title: 'Download Initiated',
                        text: `Files are being downloaded to the simulation directory for data type: ${file.dataType}`,
                        icon: 'success',
                    });
                } catch (error) {
                    Swal.fire({
                        title: 'Error',
                        text: 'Failed to initiate download',
                        icon: 'error',
                    });
                } finally {
                    file.loading = false;
                }
            }
        },
    };
</script>

<style scoped>
    .table {
        width: 100%;
        margin-top: 20px;
    }

    .table th,
    .table td {
        text-align: center;
        vertical-align: middle;
    }

    .form-control {
        width: 100%;
    }

    .btn {
        width: 100%;
    }

    .card {
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        overflow: hidden;
    }

    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
    }

    .card-body {
        padding: 20px;
    }

    .loading {
        opacity: 0.2;
        pointer-events: none;
    }
</style>
