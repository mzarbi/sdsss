<template>
    <div>
        <CollapsibleCard
                ref="collapsibleCard"
                title="Serialization Step"
                description="This is a description of the card"
                :showRunBtn="true"
                :collapsed="true"
                @save-step="handleSaveStep"
                @run-step="handleRunStep"
                @edit-step="handleEditStep"
        >
            <template #default="{ isEditMode, formData }">
                <div v-if="isEditMode" style="padding: 1rem">
                    <form @submit.prevent="handleSubmit(formData)">
                        <!-- General Settings Section -->
                        <section>
                            <h5>General Settings</h5>
                            <div class="form-group">
                                <label for="experimentKey">Experiment Key</label>
                                <input type="text" id="experimentKey" v-model="EXPERIMENT_KEY" class="form-control" @input="syncJsonString()" />
                            </div>
                        </section>

                        <!-- Pipeline Steps Section -->
                        <section>
                            <h5>Pipeline Steps</h5>
                            <div class="form-group">
                                <label for="parametersSerialization">Parameters Serialization</label>
                                <input type="text" id="parametersSerialization" v-model="PARAMETERS_SERIALIZATION_PARAMETERS" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <div class="form-check">
                                    <input
                                            id="alertsSerialization"
                                            class="form-check-input"
                                            type="checkbox"
                                            v-model="DATA_SERIALIZATION_ALERTS_SERIALISATION"
                                            @change="syncJsonString()"
                                    />
                                    <label for="alertsSerialization" class="custom-control-label">
                                        Alerts Serialization
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-check">
                                    <input
                                            id="transactionsSerialization"
                                            class="form-check-input"
                                            type="checkbox"
                                            v-model="DATA_SERIALIZATION_TRANSACTIONS_SERIALISATION"
                                            @change="syncJsonString()"
                                    />
                                    <label for="transactionsSerialization" class="custom-control-label">
                                        Transactions Serialization
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="amlitAlertsSerialization">AMLIT Alerts Serialization</label>
                                <input type="text" id="amlitAlertsSerialization" v-model="DATA_SERIALIZATION_AMLIT_ALERTS_SERIALISATION" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <div class="form-check">
                                    <input
                                            id="lookbackSums"
                                            class="form-check-input"
                                            type="checkbox"
                                            v-model="DATA_SERIALIZATION_LOOKBACK_SUMS"
                                            @change="syncJsonString()"
                                    />
                                    <label for="lookbackSums" class="custom-control-label">
                                        Lookback Sums
                                    </label>
                                </div>
                            </div>
                        </section>
                    </form>
                </div>
                <div v-else style="padding: 1rem">
                    <textarea v-model="jsonString" @input="updateFormDataFromJson" class="form-control" style="height: 500px;"></textarea>
                </div>
            </template>
        </CollapsibleCard>
    </div>
</template>

<script>
    import CollapsibleCard from '../components/CollapsibleCard';
    import axios from "axios";
    import {getBaseUrl} from "../../utils/baseUrl";
    export default {
        name: 'Step0',
        components: {CollapsibleCard},
        props:["simulationId"],
        data() {
            return {
                EXPERIMENT_KEY: "RAW",
                PARAMETERS_SERIALIZATION_PARAMETERS: "KEY",
                DATA_SERIALIZATION_ALERTS_SERIALISATION: true,
                DATA_SERIALIZATION_TRANSACTIONS_SERIALISATION: true,
                DATA_SERIALIZATION_AMLIT_ALERTS_SERIALISATION: "",
                DATA_SERIALIZATION_LOOKBACK_SUMS: true,
                jsonString: ''
            };
        },

        watch: {
            jsonString: {
                handler() {
                    this.updateFormDataFromJson();
                },
                immediate: true,
            },
        },
        created() {
            this.syncJsonString();
        },
        mounted() {
            this.loadInitialData();
        },
        methods: {
            loadInitialData() {
                axios.get(getBaseUrl() + '/api/load-step/' + this.simulationId + '/0')
                    .then(response => {
                        this.jsonString = JSON.stringify(response.data, null, 2);
                        this.updateFormDataFromJson();
                    })
                    .catch(error => {
                        console.error('Error loading initial data:', error);
                    });
            },
            handleSaveStep() {
                this.syncJsonString();
                axios.post(getBaseUrl() + '/api/save-step/' + this.simulationId + '/0', { data: JSON.parse(this.jsonString) })
                    .catch(error => {
                        console.error('Save error:', error);
                    });
            },
            handleRunStep() {
                this.syncJsonString();
                axios.post(getBaseUrl() + '/api/run-step/' + this.simulationId + '/0', { data: JSON.parse(this.jsonString) })
                    .catch(error => {
                        console.error('Run error:', error);
                    });
            },
            handleEditStep() {

            },
            syncJsonString() {
                this.jsonString = JSON.stringify(this.convertFormDataToJson(), null, 2);
            },
            convertFormDataToJson() {
                return {
                    EXPERIMENT_KEY: this.EXPERIMENT_KEY,
                    PIPELINE_STEPS: {
                        PARAMETERS_SERIALIZATION: {
                            PARAMETERS: this.PARAMETERS_SERIALIZATION_PARAMETERS
                        },
                        DATA_SERIALIZATION: {
                            ALERTS_SERIALISATION: this.DATA_SERIALIZATION_ALERTS_SERIALISATION,
                            TRANSACTIONS_SERIALISATION: this.DATA_SERIALIZATION_TRANSACTIONS_SERIALISATION,
                            AMLIT_ALERTS_SERIALISATION: this.DATA_SERIALIZATION_AMLIT_ALERTS_SERIALISATION,
                            LOOKBACK_SUMS: this.DATA_SERIALIZATION_LOOKBACK_SUMS
                        }
                    }
                };
            },
            updateFormDataFromJson() {
                try {
                    const parsed = JSON.parse(this.jsonString);
                    this.convertJsonToFormData(parsed);
                } catch (e) {
                    console.error('Invalid JSON');
                    console.error(e);
                }
            },
            convertJsonToFormData(jsonData) {
                this.EXPERIMENT_KEY = jsonData.EXPERIMENT_KEY;
                this.PARAMETERS_SERIALIZATION_PARAMETERS = jsonData.PIPELINE_STEPS.PARAMETERS_SERIALIZATION.PARAMETERS;
                this.DATA_SERIALIZATION_ALERTS_SERIALISATION = jsonData.PIPELINE_STEPS.DATA_SERIALIZATION.ALERTS_SERIALISATION;
                this.DATA_SERIALIZATION_TRANSACTIONS_SERIALISATION = jsonData.PIPELINE_STEPS.DATA_SERIALIZATION.TRANSACTIONS_SERIALISATION;
                this.DATA_SERIALIZATION_AMLIT_ALERTS_SERIALISATION = jsonData.PIPELINE_STEPS.DATA_SERIALIZATION.AMLIT_ALERTS_SERIALISATION;
                this.DATA_SERIALIZATION_LOOKBACK_SUMS = jsonData.PIPELINE_STEPS.DATA_SERIALIZATION.LOOKBACK_SUMS;
            }
        }
    };
</script>
<style scoped>
    .form-group {
        margin-bottom: 1rem;
    }
    .form-control {
        font-family: monospace;
    }
</style>
