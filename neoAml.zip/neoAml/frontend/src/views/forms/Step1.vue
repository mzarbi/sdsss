<template>
    <div>
        <CollapsibleCard
                ref="collapsibleCard"
                title="Feature Engineering Settings"
                description="Settings related to clustering features"
                :showRunBtn="true"
                :collapsed="true"
                @save-step="handleSaveStep"
                @run-step="handleRunStep"
                @edit-step="handleEditStep"
        >
            <template #default="{ isEditMode, formData }">
                <div v-if="isEditMode" style="padding: 1rem">
                    <form @submit.prevent="handleSubmit(formData)">
                        <!-- General Settings Section -->
                        <section>
                            <h5>General Settings</h5>
                            <div class="form-group">
                                <label for="experimentKey">Experiment Key</label>
                                <input type="text" id="experimentKey" v-model="EXPERIMENT_KEY" class="form-control" @input="syncJsonString()" />
                            </div>
                        </section>

                        <!-- Clustering Features Section -->
                        <section>
                            <h5>Clustering Features</h5>
                            <div class="form-group">
                                <label for="transactions">Transactions</label>
                                <input type="text" id="transactions" v-model="CLUSTERING_FEATURES_TRANSACTIONS" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="parameters">Parameters</label>
                                <input type="text" id="parameters" v-model="CLUSTERING_FEATURES_PARAMETERS" class="form-control" @input="syncJsonString()" />
                            </div>
                            <div class="form-group">
                                <label for="lookbackSums">Lookback Sums</label>
                                <input type="text" id="lookbackSums" v-model="CLUSTERING_FEATURES_LOOKBACK_SUMS" class="form-control" @input="syncJsonString()" />
                            </div>
                        </section>

                    </form>
                </div>
                <div v-else style="padding: 1rem">
                    <textarea v-model="jsonString" @input="updateFormDataFromJson" class="form-control" style="height: 500px;"></textarea>
                </div>
            </template>
        </CollapsibleCard>
    </div>
</template>
<script>
    import CollapsibleCard from '../components/CollapsibleCard';
    import axios from "axios";
    import {getBaseUrl} from "../../utils/baseUrl";

    export default {
        name: 'ClusteringSettings',
        components: { CollapsibleCard },
        props:["simulationId"],
        data() {
            return {
                EXPERIMENT_KEY: "run0_simul",
                CLUSTERING_FEATURES_TRANSACTIONS: "RAW",
                CLUSTERING_FEATURES_PARAMETERS: "RAW",
                CLUSTERING_FEATURES_LOOKBACK_SUMS: "RAW",
                jsonString: ''
            };
        },

        watch: {
            jsonString: {
                handler() {
                    this.updateFormDataFromJson();
                    console.log(this.jsonString);
                },
                immediate: true,
            },
        },
        created() {
            this.syncJsonString();
        },
        mounted() {
            this.loadInitialData();
        },
        methods: {
            loadInitialData() {
                axios.get(getBaseUrl() + '/api/load-step/' + this.simulationId + '/1')
                    .then(response => {
                        this.jsonString = JSON.stringify(response.data, null, 2);
                        this.updateFormDataFromJson();
                    })
                    .catch(error => {
                        console.error('Error loading initial data:', error);
                    });
            },
            handleSaveStep() {
                console.log('Save Step button clicked');
                this.syncJsonString();
                axios.post(getBaseUrl() + '/api/save-step/' + this.simulationId + '/1', { data: this.jsonString })
                    .then(response => {
                        console.log('Save successful:', response.data);
                    })
                    .catch(error => {
                        console.error('Save error:', error);
                    });
            },
            handleRunStep() {
                console.log('Run Step button clicked');
                this.syncJsonString();
                axios.post(getBaseUrl() + '/api/run-step/' + this.simulationId + '/1', { data: this.jsonString })
                    .then(response => {
                        console.log('Run successful:', response.data);
                    })
                    .catch(error => {
                        console.error('Run error:', error);
                    });
            },
            handleEditStep() {

            },
            handleSubmit(formData) {
                this.jsonString = JSON.stringify(this.convertFormDataToJson(), null, 2);
                console.log('Form submitted', formData);
            },
            syncJsonString() {
                this.jsonString = JSON.stringify(this.convertFormDataToJson(), null, 2);
            },
            convertFormDataToJson() {
                return {
                    EXPERIMENT_KEY: this.EXPERIMENT_KEY,
                    PIPELINE_STEPS: {
                        CLUSTERING_FEATURES: {
                            TRANSACTIONS: this.CLUSTERING_FEATURES_TRANSACTIONS,
                            PARAMETERS: this.CLUSTERING_FEATURES_PARAMETERS,
                            LOOKBACK_SUMS: this.CLUSTERING_FEATURES_LOOKBACK_SUMS
                        }
                    }
                };
            },
            updateFormDataFromJson() {
                try {
                    const parsed = JSON.parse(this.jsonString);
                    this.convertJsonToFormData(parsed);
                } catch (e) {
                    console.error('Invalid JSON');
                    console.error(e);
                }
            },
            convertJsonToFormData(jsonData) {
                this.EXPERIMENT_KEY = jsonData.EXPERIMENT_KEY;
                this.CLUSTERING_FEATURES_TRANSACTIONS = jsonData.PIPELINE_STEPS.CLUSTERING_FEATURES.TRANSACTIONS;
                this.CLUSTERING_FEATURES_PARAMETERS = jsonData.PIPELINE_STEPS.CLUSTERING_FEATURES.PARAMETERS;
                this.CLUSTERING_FEATURES_LOOKBACK_SUMS = jsonData.PIPELINE_STEPS.CLUSTERING_FEATURES.LOOKBACK_SUMS;
            }
        }
    };
</script>
<style scoped>
    .form-group {
        margin-bottom: 1rem;
    }
    .form-control {
        font-family: monospace;
    }
</style>
