<template>
    <div style="padding: 1rem">
    </div>
    <div class="row">
        <div class="col">
            <GlobalSettings :simulationId="simulation.id"></GlobalSettings>
        </div>

    </div>
    <div class="row">
        <div class="col">
            <Step0 :simulationId="simulation.id"></Step0>
        </div>
        <div class="col">
            <Step1 :simulationId="simulation.id"></Step1>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <Step2 :simulationId="simulation.id"></Step2>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <Step3 :simulationId="simulation.id"></Step3>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <Step4 :simulationId="simulation.id"></Step4>
        </div>
        <div class="col">
            <Step5 :simulationId="simulation.id"></Step5>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <Step6 :simulationId="simulation.id"></Step6>
        </div>
    </div>


</template>

<script>
    import GlobalSettings from "@/views/forms/GlobalSettings";
    import Step0 from "@/views/forms/Step0";
    import Step1 from "@/views/forms/Step1";
    import Step2 from "@/views/forms/Step2";
    import Step3 from "@/views/forms/Step3";
    import Step4 from "@/views/forms/Step4";
    import Step5 from "@/views/forms/Step5";
    import Step6 from "@/views/forms/Step6";
    export default {
        name: "PipelineSettings",
        props:["simulation"],
        components: {GlobalSettings, Step0, Step1, Step2, Step3, Step4, Step5, Step6}
    }
</script>

<style scoped>

</style>