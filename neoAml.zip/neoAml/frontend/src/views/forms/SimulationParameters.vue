<template>
    <div class="py-1 container-fluid">
        <div class="mt-3 row">
            <div>
                <div class="card h-100">
                    <div class="p-3 pb-0 card-header" style="margin-bottom: 1rem">
                        <div class="row">
                            <div class="col-md-10">
                                <h6 style="cursor: pointer;" class="mb-0 header-section" @click="toggleFlowParameters">
                                    Simulation Parameters
                                </h6>
                            </div>
                        </div>
                        <ul class="list-group">
                            <li class="px-0 border-0 list-group-item">
                                <p style="line-height: 1.625; font-weight: 600; font-size: 0.85rem;">
                                    Fill in all parameters to launch a new run. You can check and modify percentile and outliers setting in “Advanced parameters”
                                </p>
                            </li>
                        </ul>
                    </div>
                    <div class="p-3 card-body" v-if="toggleFlowParametersState">
                        <ul class="list-group">
                            <InputField label="Name" v-model="flowName" :disabled="fieldsDisabled" tooltip="Each run needs a discriminant name" />
                            <TextAreaField label="Description" v-model="flowDescription" tooltip="You can add notes here" />
                            <SelectField
                                    label="Actimize Version"
                                    v-model="flowActimizeVersion"
                                    :options="actimizeVersionList"
                                    field="name"
                                    display="name"
                                    tooltip="The actimize version"
                            />
                            <MultipleSelectField
                                    label="Models"
                                    v-model="flowModels"
                                    :options="modelsList"
                                    multiple
                                    tooltip="The list of actimize models to simulate"
                            />
                            <SelectField
                                    label="Business Unit"
                                    v-model="flowBusinessUnit"
                                    :options="businessUnitList"
                                    field="trigram"
                                    display="name"
                                    tooltip="Business unit == country"
                            />
                            <SelectField
                                    label="Currency"
                                    v-model="flowCurrency"
                                    :options="currencyList"
                                    field="currency"
                                    display="currency"
                                    tooltip="Currency"
                            />
                            <InputField
                                    label="Local Currency Rate"
                                    v-model="flowLocalCurrencyRate"
                                    tooltip="The exchange rates against the euro"
                            />
                            <InputField
                                    label="FTF Lookback Period"
                                    v-model="flowLookbackPeriod"
                                    tooltip="The look back period is either 1 or 2"
                            />
                            <SelectField
                                    label="Bucket Mapping Mode"
                                    v-model="flowBucketMappingMode"
                                    :options="bucketMappingModeList"
                                    field="name"
                                    display="name"
                                    tooltip="For compatibility reasons we have two modes of bucket mapping"
                            />
                            <ul class="list-group">
                                <li class="px-0 border-0 list-group-item" data-tooltip="The start and the end dates for the simulation">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Data Start Date</label>
                                            <input type="date" class="cselect" placeholder="" v-model="flowDataStartDate" />
                                        </div>
                                        <div class="col-md-6">
                                            <label>Data End Date</label>
                                            <input type="date" class="cselect" placeholder="" v-model="flowDataEndDate" />
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <ul class="list-group">
                                <li class="px-0 border-0 list-group-item" data-tooltip="The start and end dates for the training data">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Train Start Date</label>
                                            <input type="date" class="cselect" placeholder="" v-model="flowTrainStartDate" />
                                        </div>
                                        <div class="col-md-6">
                                            <label>Train End Date</label>
                                            <input type="date" class="cselect" placeholder="" v-model="flowTrainEndDate" />
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <ul class="list-group">
                                <li class="px-0 border-0 list-group-item" data-tooltip="The start and end dates for the testing data">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label>Test Start Date</label>
                                            <input type="date" class="cselect" placeholder="" v-model="flowTestStartDate" />
                                        </div>
                                        <div class="col-md-6">
                                            <label>Test End Date</label>
                                            <input type="date" class="cselect" placeholder="" v-model="flowTestEndDate" />
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
    import InputField from '@/views/fields/InputField.vue';
    import TextAreaField from '@/views/fields/TextAreaField.vue';
    import SelectField from '@/views/fields/SelectField.vue';
    import MultipleSelectField from '@/views/fields/MultipleSelectField.vue';
    import {countriesList} from "../../utils/countries";
    MultipleSelectField

    export default {
        components: {
            InputField,
            TextAreaField,
            SelectField,
            MultipleSelectField
        },
        props: {
            newSimulation: Boolean
        },
        data() {
            return {
                toggleFlowParametersState: true,
                flowName: this.getSimulationName(),
                fieldsDisabled:  this.newSimulation,
                flowDescription: '',
                actimizeVersionList: [
                    { name: "V3" },
                    { name: "V8" },
                ],
                flowActimizeVersion: "V8",
                modelsList: [
                    { name: "EFT" },
                    { name: "FTF" },
                    { name: "TSD" }
                ],
                flowModels: ["EFT", "FTF", "TSD"],
                businessUnitList: countriesList,
                flowBusinessUnit: "FRA",
                currencyList: countriesList,
                flowCurrency: "EUR",
                flowLocalCurrencyRate: 1,
                flowLookbackPeriod: 2,
                bucketMappingModeList: [
                    { name: "Simple" },
                    { name: "Advanced" },
                ],
                flowBucketMappingMode: "Simple",
                flowDataStartDate: '2020-01-01',
                flowDataEndDate: '2021-12-31',
                flowTrainStartDate: '2020-01-01',
                flowTrainEndDate: '2020-12-31',
                flowTestStartDate: '2021-01-01',
                flowTestEndDate: '2021-12-31',
            };
        },
        watch: {
            flowBusinessUnit(newValue) {
                const selectedCountry = this.businessUnitList.find(
                    country => country.trigram === newValue
                );
                if (selectedCountry) {
                    this.flowCurrency = selectedCountry.currency;
                }
            },
        },
        methods: {
            getSimulationName() {
                // Get the current date
                const now = new Date();

                // Extract day, month, and year from the date
                const day = String(now.getDate()).padStart(2, '0');
                const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are zero-based
                const year = now.getFullYear();

                // Generate a random number between 0 and 999 and pad it to 3 digits
                const randomNumber = String(Math.floor(Math.random() * 1000)).padStart(3, '0');

                // Construct the final string
                const simulationString = `SIMULATION_${day}${month}${year}_${randomNumber}`;

                return simulationString;
            },

            toggleFlowParameters() {
                this.toggleFlowParametersState = !this.toggleFlowParametersState;
            },
            exportData() {
                const data = {
                    flowName: this.flowName,
                    flowDescription: this.flowDescription,
                    flowActimizeVersion: this.flowActimizeVersion,
                    flowModels: this.flowModels,
                    flowBusinessUnit: this.flowBusinessUnit,
                    flowCurrency: this.flowCurrency,
                    flowLocalCurrencyRate: this.flowLocalCurrencyRate,
                    flowLookbackPeriod: this.flowLookbackPeriod,
                    flowBucketMappingMode: this.flowBucketMappingMode,
                    flowDataStartDate: this.flowDataStartDate,
                    flowDataEndDate: this.flowDataEndDate,
                    flowTrainStartDate: this.flowTrainStartDate,
                    flowTrainEndDate: this.flowTrainEndDate,
                    flowTestStartDate: this.flowTestStartDate,
                    flowTestEndDate: this.flowTestEndDate,
                };
                return data;
            },
            importData(data) {
                this.flowName = data.flowName;
                this.flowDescription = data.flowDescription;
                this.flowActimizeVersion = data.flowActimizeVersion;
                this.flowModels = data.flowModels;
                this.flowBusinessUnit = data.flowBusinessUnit;
                this.flowCurrency = data.flowCurrency;
                this.flowLocalCurrencyRate = data.flowLocalCurrencyRate;
                this.flowLookbackPeriod = data.flowLookbackPeriod;
                this.flowBucketMappingMode = data.flowBucketMappingMode;
                this.flowDataStartDate = data.flowDataStartDate;
                this.flowDataEndDate = data.flowDataEndDate;
                this.flowTrainStartDate = data.flowTrainStartDate;
                this.flowTrainEndDate = data.flowTrainEndDate;
                this.flowTestStartDate = data.flowTestStartDate;
                this.flowTestEndDate = data.flowTestEndDate;
            },
        },
    };
</script>

<style>
    .cselect {
        display: block;
        width: 100%;
        padding: .5rem .75rem;
        font-size: .875rem;
        font-weight: 400;
        line-height: 1.4rem;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #d2d6da;
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        border-radius: .5rem;
        transition: box-shadow .15s ease, border-color .15s ease;
    }
</style>
