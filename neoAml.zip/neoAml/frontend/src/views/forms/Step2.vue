<template>
    <div>
        <CollapsibleCard
                ref="collapsibleCard"
                title="Clustering Settings"
                description="Settings related to pipeline steps"
                :showRunBtn="true"
                :collapsed="true"
                @save-step="handleSaveStep"
                @run-step="handleRunStep"
                @edit-step="handleEditStep"
        >
            <template #default="{ isEditMode, formData }">
                <div v-if="isEditMode" style="padding: 1rem">
                    <form @submit.prevent="handleSubmit(formData)">
                        <div class="row">
                            <div class="col" style="border-right: 1px solid #e9ecef; padding-right: 2rem">
                                <!-- Clustering Section -->
                                <section>
                                    <h5>Clustering</h5>
                                    <div class="form-group">
                                        <label for="clusteringTransactions">Transactions</label>
                                        <input type="text" id="clusteringTransactions" v-model="CLUSTERING_TRANSACTIONS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="clusteringFeatures">Features</label>
                                        <input type="text" id="clusteringFeatures" v-model="CLUSTERING_FEATURES" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="clusteringClusters">Clusters</label>
                                        <input type="text" id="clusteringClusters" v-model="CLUSTERING_CLUSTERS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="clusteringLookbackSums">Lookback Sums</label>
                                        <input type="text" id="clusteringLookbackSums" v-model="CLUSTERING_LOOKBACK_SUMS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                </section>
                                <!-- Thresholds Section -->
                                <section>
                                    <h5>Thresholds</h5>
                                    <div class="form-group">
                                        <label for="thresholdsTransactions">Transactions</label>
                                        <input type="text" id="thresholdsTransactions" v-model="THRESHOLDS_TRANSACTIONS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="thresholdsParameters">Parameters</label>
                                        <input type="text" id="thresholdsParameters" v-model="THRESHOLDS_PARAMETERS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="thresholdsL2RecallTrain">L2 Recall Train</label>
                                        <input type="number" id="thresholdsL2RecallTrain" v-model.number="THRESHOLDS_L2_RECALL_TRAIN" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="thresholdsL2RecallTest">L2 Recall Test</label>
                                        <input type="number" id="thresholdsL2RecallTest" v-model.number="THRESHOLDS_L2_RECALL_TEST" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="thresholdsLookbackSums">Lookback Sums</label>
                                        <input type="text" id="thresholdsLookbackSums" v-model="THRESHOLDS_LOOKBACK_SUMS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="thresholdsFeatures">Features</label>
                                        <input type="text" id="thresholdsFeatures" v-model="THRESHOLDS_FEATURES" class="form-control" @input="syncJsonString()" />
                                    </div>
                                </section>
                            </div>
                            <div class="col" style="padding-left: 2rem">


                                <!-- Alerting Section -->
                                <section>
                                    <h5>Alerting</h5>
                                    <div class="form-group">
                                        <label for="alertingTransactions">Transactions</label>
                                        <input type="text" id="alertingTransactions" v-model="ALERTING_TRANSACTIONS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group" style="display: flex; align-items: center;">
                                        <label for="alertingProdAlerts" style="margin-right: 10px;">Prod Alerts</label>
                                        <select
                                                id="alertingProdAlerts"
                                                v-model="ALERTING_PROD_ALERTS"
                                                class="form-control"
                                                @change="syncJsonString()"
                                                multiple
                                                style="flex-grow: 1; margin-right: 10px;"
                                        >
                                            <option v-for="model in all_prod_alerts" :key="model.id" :value="model">
                                                {{model}}</option>
                                        </select>
                                        <select
                                                id="modelSelection"
                                                v-model="selectedModel"
                                                class="form-control"
                                                @change="switchModel()"
                                                style="width: auto;"
                                        >
                                            <option value="SAM3">SAM3</option>
                                            <option value="SAM8">SAM8</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="alertingProdAlertsKey">Prod Alerts Key</label>
                                        <input type="text" id="alertingProdAlertsKey" v-model="ALERTING_PROD_ALERTS_KEY" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="alertingParameters">Parameters</label>
                                        <input type="text" id="alertingParameters" v-model="ALERTING_PARAMETERS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="alertingLookbackSums">Lookback Sums</label>
                                        <input type="text" id="alertingLookbackSums" v-model="ALERTING_LOOKBACK_SUMS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="alertingThresholds">Thresholds</label>
                                        <input type="text" id="alertingThresholds" v-model="ALERTING_THRESHOLDS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="alertingAnalysisDates">Analysis Dates</label>
                                        <select
                                                id="alertingAnalysisDates"
                                                v-model="ALERTING_ANALYSIS_DATES"
                                                class="form-control"
                                                @change="syncJsonString()"
                                        >
                                            <option value=""></option>
                                            <option value="TRAIN">TRAIN</option>
                                            <option value="TEST">TEST</option>
                                        </select>
                                    </div>
                                </section>

                                <!-- KPIs Section -->
                                <section>
                                    <h5>KPIs</h5>
                                    <div class="form-group">
                                        <label for="kpisTransactions">Transactions</label>
                                        <input type="text" id="kpisTransactions" v-model="KPIS_TRANSACTIONS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="kpisAlerts">Alerts</label>
                                        <input type="text" id="kpisAlerts" v-model="KPIS_ALERTS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="kpisBaseline">Baseline</label>
                                        <input type="text" id="kpisBaseline" v-model="KPIS_BASELINE" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="kpisParameters">Parameters</label>
                                        <input type="text" id="kpisParameters" v-model="KPIS_PARAMETERS" class="form-control" @input="syncJsonString()" />
                                    </div>
                                    <div class="form-group">
                                        <label for="kpisAnalysisDates">Analysis Dates</label>
                                        <select
                                                id="kpisAnalysisDates"
                                                v-model="KPIS_ANALYSIS_DATES"
                                                class="form-control"
                                                @change="syncJsonString()"
                                        >
                                            <option value=""></option>
                                            <option value="TRAIN">TRAIN</option>
                                            <option value="TEST">TEST</option>
                                        </select>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </form>
                </div>
                <div v-else style="padding: 1rem">
                    <textarea v-model="jsonString" @input="updateFormDataFromJson" class="form-control" style="height: 500px;"></textarea>
                </div>
            </template>
        </CollapsibleCard>
    </div>
</template>
<script>
    import CollapsibleCard from '../components/CollapsibleCard';
    import axios from "axios";
    import {getBaseUrl} from "../../utils/baseUrl";

    export default {
        name: 'PipelineSettings',
        components: { CollapsibleCard },
        props:["simulationId"],
        data() {
            return {
                selectedModel: 'SAM8',
                sam3_prod_alerts: ["3PP", "ADR", "EPC", "HBC", "KEY", "LOW", "NBI", "SCT", "STP", "EFT", "FTF", "TSD"],
                sam8_prod_alerts: ["ADR", "CTF", "EPC", "KHI", "KLO", "LTH", "NBI", "SBP", "STP", "THV", "EFT", "FTF", "TSD"],
                all_prod_alerts: ['KHI', 'THV', '3PP', 'SBP', 'LTH', 'SCT', 'EPC', 'KLO', 'LOW', 'STP', 'EFT', 'FTF', 'TSD', 'KEY', 'CTF', 'NBI', 'HBC', 'ADR'],
                CLUSTERING_TRANSACTIONS: "RAW",
                CLUSTERING_FEATURES: "run0_simul",
                CLUSTERING_CLUSTERS: "KEY",
                CLUSTERING_LOOKBACK_SUMS: "RAW",
                THRESHOLDS_TRANSACTIONS: "KEY",
                THRESHOLDS_PARAMETERS: "RAW",
                THRESHOLDS_L2_RECALL_TRAIN: 100.0,
                THRESHOLDS_L2_RECALL_TEST: 100.0,
                THRESHOLDS_LOOKBACK_SUMS: "KEY",
                THRESHOLDS_FEATURES: "run0_simul",
                ALERTING_TRANSACTIONS: "KEY",
                ALERTING_PROD_ALERTS: ["3PP", "ADR", "EPC", "HBC", "KEY", "LOW", "NBI", "SCT", "STP"],
                ALERTING_PROD_ALERTS_KEY: "truth",
                ALERTING_PARAMETERS: "RAW",
                ALERTING_LOOKBACK_SUMS: "KEY",
                ALERTING_THRESHOLDS: "KEY",
                ALERTING_ANALYSIS_DATES: "TRAIN",
                KPIS_TRANSACTIONS: "KEY",
                KPIS_ALERTS: "KEY",
                KPIS_BASELINE: "truth",
                KPIS_PARAMETERS: "RAW",
                KPIS_ANALYSIS_DATES: "TRAIN",
                jsonString: ''
            };
        },

        watch: {
            jsonString: {
                handler() {
                    this.updateFormDataFromJson();
                    console.log(this.jsonString);
                },
                immediate: true,
            },
        },
        created() {
            this.syncJsonString();
        },
        mounted() {
            this.loadInitialData();
        },
        methods: {
            switchModel() {
                // Logic to switch the model
                if (this.selectedModel === 'SAM3') {
                    this.ALERTING_PROD_ALERTS = this.sam3_prod_alerts;
                } else if (this.selectedModel === 'SAM8') {
                    this.ALERTING_PROD_ALERTS = this.sam8_prod_alerts;
                }
            },
            loadInitialData() {
                axios.get(getBaseUrl() + '/api/load-step/' + this.simulationId + '/2')
                    .then(response => {
                        this.jsonString = JSON.stringify(response.data, null, 2);
                        this.updateFormDataFromJson();
                    })
                    .catch(error => {
                        console.error('Error loading initial data:', error);
                    });
            },
            handleSaveStep() {
                console.log('Save Step button clicked');
                this.syncJsonString();
                axios.post(getBaseUrl() + '/api/save-step/' + this.simulationId + '/2', { data: this.jsonString })
                    .then(response => {
                        console.log('Save successful:', response.data);
                    })
                    .catch(error => {
                        console.error('Save error:', error);
                    });
            },
            handleRunStep() {
                console.log('Run Step button clicked');
                this.syncJsonString();
                axios.post(getBaseUrl() + '/api/run-step/' + this.simulationId + '/2', { data: this.jsonString })
                    .then(response => {
                        console.log('Run successful:', response.data);
                    })
                    .catch(error => {
                        console.error('Run error:', error);
                    });
            },
            handleEditStep() {

            },
            handleSubmit(formData) {
                this.jsonString = JSON.stringify(this.convertFormDataToJson(), null, 2);
                console.log('Form submitted', formData);
            },
            syncJsonString() {
                this.jsonString = JSON.stringify(this.convertFormDataToJson(), null, 2);
            },
            convertFormDataToJson() {
                return {
                    PIPELINE_STEPS: {
                        CLUSTERING: {
                            TRANSACTIONS: this.CLUSTERING_TRANSACTIONS,
                            FEATURES: this.CLUSTERING_FEATURES,
                            CLUSTERS: this.CLUSTERING_CLUSTERS,
                            LOOKBACK_SUMS: this.CLUSTERING_LOOKBACK_SUMS
                        },
                        THRESHOLDS: {
                            TRANSACTIONS: this.THRESHOLDS_TRANSACTIONS,
                            PARAMETERS: this.THRESHOLDS_PARAMETERS,
                            L2_RECALL_TRAIN: this.THRESHOLDS_L2_RECALL_TRAIN,
                            L2_RECALL_TEST: this.THRESHOLDS_L2_RECALL_TEST,
                            LOOKBACK_SUMS: this.THRESHOLDS_LOOKBACK_SUMS,
                            FEATURES: this.THRESHOLDS_FEATURES,
                        },
                        ALERTING: {
                            TRANSACTIONS: this.ALERTING_TRANSACTIONS,
                            PROD_ALERTS: this.ALERTING_PROD_ALERTS,
                            PROD_ALERTS_KEY: this.ALERTING_PROD_ALERTS_KEY,
                            PARAMETERS: this.ALERTING_PARAMETERS,
                            LOOKBACK_SUMS: this.ALERTING_LOOKBACK_SUMS,
                            THRESHOLDS: this.ALERTING_THRESHOLDS,
                            ANALYSIS_DATES: this.ALERTING_ANALYSIS_DATES
                        },
                        KPIS: {
                            TRANSACTIONS: this.KPIS_TRANSACTIONS,
                            ALERTS: this.KPIS_ALERTS,
                            BASELINE: this.KPIS_BASELINE,
                            PARAMETERS: this.KPIS_PARAMETERS,
                            ANALYSIS_DATES: this.KPIS_ANALYSIS_DATES
                        },
                    }
                };
            },
            updateFormDataFromJson() {
                try {
                    const parsed = JSON.parse(this.jsonString);
                    this.convertJsonToFormData(parsed);
                } catch (e) {
                    console.error('Invalid JSON');
                    console.error(e);
                }
            },
            convertJsonToFormData(jsonData) {
                this.CLUSTERING_TRANSACTIONS = jsonData.PIPELINE_STEPS.CLUSTERING.TRANSACTIONS;
                this.CLUSTERING_FEATURES = jsonData.PIPELINE_STEPS.CLUSTERING.FEATURES;
                this.CLUSTERING_CLUSTERS = jsonData.PIPELINE_STEPS.CLUSTERING.CLUSTERS;
                this.CLUSTERING_LOOKBACK_SUMS = jsonData.PIPELINE_STEPS.CLUSTERING.LOOKBACK_SUMS;
                this.THRESHOLDS_TRANSACTIONS = jsonData.PIPELINE_STEPS.THRESHOLDS.TRANSACTIONS;
                this.THRESHOLDS_PARAMETERS = jsonData.PIPELINE_STEPS.THRESHOLDS.PARAMETERS;
                this.THRESHOLDS_L2_RECALL_TRAIN = jsonData.PIPELINE_STEPS.THRESHOLDS.L2_RECALL_TRAIN;
                this.THRESHOLDS_L2_RECALL_TEST = jsonData.PIPELINE_STEPS.THRESHOLDS.L2_RECALL_TEST;
                this.THRESHOLDS_LOOKBACK_SUMS = jsonData.PIPELINE_STEPS.THRESHOLDS.LOOKBACK_SUMS;
                this.THRESHOLDS_FEATURES = jsonData.PIPELINE_STEPS.THRESHOLDS.FEATURES;
                this.ALERTING_TRANSACTIONS = jsonData.PIPELINE_STEPS.ALERTING.TRANSACTIONS;
                this.ALERTING_PROD_ALERTS = jsonData.PIPELINE_STEPS.ALERTING.PROD_ALERTS;
                this.ALERTING_PROD_ALERTS_KEY = jsonData.PIPELINE_STEPS.ALERTING.PROD_ALERTS_KEY;
                this.ALERTING_PARAMETERS = jsonData.PIPELINE_STEPS.ALERTING.PARAMETERS;
                this.ALERTING_LOOKBACK_SUMS = jsonData.PIPELINE_STEPS.ALERTING.LOOKBACK_SUMS;
                this.ALERTING_THRESHOLDS = jsonData.PIPELINE_STEPS.ALERTING.THRESHOLDS;
                this.ALERTING_ANALYSIS_DATES = jsonData.PIPELINE_STEPS.ALERTING.ANALYSIS_DATES;
                this.KPIS_TRANSACTIONS = jsonData.PIPELINE_STEPS.KPIS.TRANSACTIONS;
                this.KPIS_ALERTS = jsonData.PIPELINE_STEPS.KPIS.ALERTS;
                this.KPIS_BASELINE = jsonData.PIPELINE_STEPS.KPIS.BASELINE;
                this.KPIS_PARAMETERS = jsonData.PIPELINE_STEPS.KPIS.PARAMETERS;
                this.KPIS_ANALYSIS_DATES = jsonData.PIPELINE_STEPS.KPIS.ANALYSIS_DATES;
            }
        }
    };
</script>
<style scoped>
    .form-group {
        margin-bottom: 1rem;
    }
    .form-control {
        font-family: monospace;
    }
</style>
