<template>
    <div class="card">
        <div class="card-header pb-0">
            <h6>Recent Simulations</h6>
        </div>
        <div class="table-responsive">
            <table class="table align-items-center mb-0">
                <thead>
                <tr>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Date Started</th>
                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Collaborators</th>
                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Completion</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="simulation in simulations" :key="simulation.id">
                    <td>
                        <p class="text-xs font-weight-bold mb-0">{{ simulation.name }}</p>
                    </td>
                    <td>
                        <p class="text-xs font-weight-bold mb-0">{{ simulation.dateStarted }}</p>
                    </td>
                    <td>
                        <div class="avatar-group">
                <span v-for="collaborator in simulation.collaborators" :key="collaborator.id" class="avatar avatar-xs" :title="collaborator.name">
                  <img src="../../assets/img/small-logos/logo-jira.svg" alt="avatar" class="rounded-circle">
                </span>
                        </div>
                    </td>
                    <td class="align-middle text-center">
                        <div class="d-flex align-items-center justify-content-center">
                            <span class="me-2 text-xs font-weight-bold">{{ simulation.completion }}%</span>
                            <div>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" :style="{width: simulation.completion + '%'}" :aria-valuenow="simulation.completion" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
    export default {
        name: "SimulationCard",
        props: {
            simulations: {
                type: Array,
                required: true
            }
        }
    };
</script>

<style scoped>
    .avatar-group .avatar {
        margin-right: -0.5rem;
    }
    .progress {
        height: 8px;
    }
</style>
