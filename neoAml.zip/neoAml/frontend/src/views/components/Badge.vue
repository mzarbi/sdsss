<template>
  <span :class="['badge2', badgeClass]">
    <slot></slot>
  </span>
</template>

<script>
    export default {
        name: "badge",
        props: {
            type: {
                type: String,
                default: 'primary',
            },
        },
        computed: {
            badgeClass() {
                return {
                    'badge-primary': this.type === 'primary',
                    'badge-success': this.type === 'success',
                    'badge-danger': this.type === 'danger',
                };
            },
        },
    };
</script>

<style scoped>
    .badge2 {
        display: inline-block;
        padding: 0.25em 0.4em;
        font-size: 75%;
        font-weight: 700;
        line-height: 1;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: 0.25rem;
    }

    .badge2-primary {
        color: #fff;
        background-color: #007bff;
    }

    .badge2-success {
        color: #fff;
        background-color: #28a745;
    }

    .badge2-danger {
        color: #fff;
        background-color: #dc3545;
    }
</style>
