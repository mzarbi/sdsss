<template>
  <div class="fixed-plugin">
    <a
      class="px-3 py-2 fixed-plugin-button text-dark position-fixed"
      @click="toggle"
    >
      <i class="py-2 fa fa-cog"> </i>
    </a>
    <div class="shadow-lg card blur">
      <div class="pt-3 pb-0 bg-transparent card-header">
        <div class="float-start">
          <h5 class="mt-3 mb-0">Create New Simulation</h5>
        </div>
        <div class="mt-4 float-end" @click="toggle">
          <button class="p-0 btn btn-link text-dark fixed-plugin-close-button">
            <i class="fa fa-close"></i>
          </button>
        </div>
      </div>
      <hr class="my-1 horizontal dark" />
      <div class="card-body">
        <div class="row">
            <button class="btn btn-primary" @click="onCreateSimulation">
              Create Simulation
            </button>
            <div v-if="isLoading">
              <loading-spinner :isLoading="isLoading" class="mt-3"></loading-spinner>
            </div>
        </div>

        <div v-if="events.length" class="mt-3">
          <h6>Server Events:</h6>
          <ul>
            <div v-for="(event, index) in events" :key="index">
              <span v-if="event.type === 'success'">{{ '✅'  }}{{ event.message }}</span>
              <span v-else>{{ '❌'  }}{{ event.message }}</span>
            </div>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import LoadingSpinner from "./LoadingSpinner.vue";

  export default {
  name: "new-sim-configurator",
  props: ["toggle", "events", "isLoading"],
  components: {
    LoadingSpinner
  },
  data() {
  },
  methods: {
    onCreateSimulation() {
      this.$emit('create-simulation');
    }
  },

  beforeMount() {
    this.$store.state.isTransparent = "bg-transparent";
    window.addEventListener("resize", this.sidenavTypeOnResize);
    window.addEventListener("load", this.sidenavTypeOnResize);
  },
};
</script>
