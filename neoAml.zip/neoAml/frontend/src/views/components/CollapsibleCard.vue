<template>
    <div class="card mb-4 soft-ui-card">
        <div class="card-header pb-0 d-flex justify-content-between align-items-center" style="padding: 0rem !important;">
            <div style="padding: 1rem; width: 100%;">
                <div class="row">
                    <div class="col hoverable" @click="toggleCollapse">
                        <h6 class="mb-0">{{ title }}</h6>
                    </div>
                    <div class="col">
                        <div class="text-end" style="width: 100%">
                            <div class="ms-auto buttons">
                                <a class="btn btn-link text-primary px-1 mb-0 hoverable" @click="$emit('save-step')">
                                    <i class="text-primary fas fa-save me-2" aria-hidden="true"></i>
                                </a>
                                <a v-if="showRunBtn" class="btn btn-link text-success px-1 mb-0 hoverable" @click="$emit('run-step')">
                                    <i class="text-success fas fa-play me-2" aria-hidden="true"></i>
                                </a>
                                <a class="btn btn-link text-secondary px-1 mb-0 hoverable" @click="emitEditStep">
                                    <i class="text-secondary fas fa-edit me-2" aria-hidden="true"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <p class="text-xs mb-0 text-muted">{{ description }}</p>
            </div>
        </div>
        <div v-show="!isCollapsed" class="card-body px-0 pt-0 pb-2">
            <slot :isEditMode="isEditMode" :formData="formData" :updateFormData="updateFormData"></slot>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'CollapsibleCard',
        props: {
            title: {
                type: String,
                required: true
            },
            description: {
                type: String,
                required: true
            },
            showRunBtn:{
                type: Boolean,
                default: true
            },
            collapsed:{
                type: Boolean,
                default: false
            },
        },
        data() {
            return {
                isCollapsed: this.collapsed,
                isEditMode: true,
                formData: {
                    input1: '',
                    input2: ''
                }
            };
        },
        methods: {
            toggleCollapse() {
                this.isCollapsed = !this.isCollapsed;
            },
            emitEditStep() {
                this.isEditMode = !this.isEditMode;
                this.$emit('edit-step', this.isEditMode);
            },
            updateFormData(newData) {
                this.formData = { ...newData };
            }
        }
    };
</script>

<style scoped>
    .hoverable {
        opacity: 1;
    }
    .hoverable:hover {
        cursor: pointer;
        opacity: 0.7;
    }
    .card {
        border-radius: 1rem;
        box-shadow: 0 10px 20px 0 rgba(0, 0, 0, 0.1);
        border: 0;
    }
    .card-header {
        background-color: #f8f9fa;
        border-bottom: 1px solid #dee2e6;
        border-top-left-radius: 1rem;
        border-top-right-radius: 1rem;
    }
    .card-body {
        padding: 1rem;
        border-bottom-left-radius: 1rem;
        border-bottom-right-radius: 1rem;
    }
    .btn {
        background: none;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 0;
    }
    .soft-ui-card {
        background: #fff;
        border-radius: 1rem;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.15);
        transition: box-shadow 0.3s ease;
    }
    .soft-ui-card:hover {
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }
</style>
