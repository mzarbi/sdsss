<template>
    <div>
        <div class="ms-auto text-start buttons">
            <a class="btn btn-link text-primary px-3 mb-0" @click="createFolder">
                <i class="text-primary fas fa-folder-plus me-2" aria-hidden="true"></i>Create Folder
            </a>
            <a class="btn btn-link text-success px-3 mb-0" @click="uploadFile">
                <i class="text-success fas fa-upload me-2" aria-hidden="true"></i>Upload File
            </a>
            <a class="btn btn-link text-info px-3 mb-0" @click="downloadFile">
                <i class="text-info fas fa-download me-2" aria-hidden="true"></i>Download
            </a>
            <a class="btn btn-link text-info px-3 mb-0" @click="downloadFolder">
                <i class="text-info fas fa-folder-open me-2" aria-hidden="true"></i>Download Folder
            </a>
            <a class="btn btn-link text-warning px-3 mb-0" @click="renameFileOrFolder">
                <i class="text-warning fas fa-edit me-2" aria-hidden="true"></i>Rename
            </a>
            <a class="btn btn-link text-secondary px-3 mb-0" @click="moveFileOrFolder">
                <i class="text-secondary fas fa-arrows-alt me-2" aria-hidden="true"></i>Move
            </a>
            <a class="btn btn-link text-danger px-3 mb-0" @click="deleteFileOrFolder">
                <i class="text-danger fas fa-trash-alt me-2" aria-hidden="true"></i>Delete
            </a>
            <a class="btn btn-link text-success px-3 mb-0" @click="copyFile">
                <i class="text-success fas fa-copy me-2" aria-hidden="true"></i>Copy
            </a>
        </div>
        <input type="file" ref="fileInput" style="display: none" @change="handleFileUpload" />
        <div ref="tree"></div>
    </div>
</template>




<script>
    import $ from 'jquery';
    import 'jquery.fancytree/dist/skin-lion/ui.fancytree.css';
    import 'jquery.fancytree';
    import 'jquery.fancytree/dist/modules/jquery.fancytree.multi';
    import axios from 'axios';
    import Swal from 'sweetalert2';
    import 'sweetalert2/src/sweetalert2.scss';
    import {
        showLoadingDialog,
        showSuccessDialog,
        showErrorDialog,
        showConfirmDialog
    } from '@/utils/dialogs';
    import {getBaseUrl} from "../../utils/baseUrl";  // Adjust the import path accordingly

    export default {
        name: 'FileExplorer',
        props: ["simulationId"],
        data() {
            return {
                selectedNode: null,
            };
        },
        mounted() {
            this.initializeFancyTree();
        },
        methods: {
            initializeFancyTree() {
                $(this.$refs.tree).fancytree({
                    source: {
                        url: getBaseUrl() + '/fs/list/' + this.simulationId,
                        cache: false,
                    },
                    extensions: ['multi'],
                    selectMode: 2, // Multiple selection
                    activate: (event, data) => {
                        this.selectedNode = data.node;
                    },
                    select: (event, data) => {
                        const selectedNodes = $.map(data.tree.getSelectedNodes(), function (node) {
                            return node;
                        });
                        console.log(selectedNodes);
                    }
                });
            },
            async createFolder() {
                const { value: folderName } = await Swal.fire({
                    title: 'Enter folder name',
                    input: 'text',
                    inputPlaceholder: 'Folder name',
                    showCancelButton: true,
                    inputValidator: (value) => {
                        if (!value) {
                            return 'You need to write something!';
                        }
                    }
                });

                if (folderName) {
                    showLoadingDialog('Creating folder...');
                    const parentPath = this.selectedNode ? this.selectedNode.key : '';
                    const newPath = `${parentPath}/${folderName}`;
                    try {
                        await axios.post(`${getBaseUrl()}/fs/create_folder/${this.simulationId}`, { path: newPath });
                        if (this.selectedNode) {
                            this.selectedNode.addChildren({ title: folderName, key: newPath, folder: true });
                        } else {
                            $(this.$refs.tree).fancytree("getRootNode").addChildren({ title: folderName, key: newPath, folder: true });
                        }
                        showSuccessDialog('Folder created successfully');
                    } catch (error) {
                        showErrorDialog('Failed to create folder');
                    }
                }
            },
            uploadFile() {
                this.$refs.fileInput.click();
            },
            async handleFileUpload(event) {
                const file = event.target.files[0];
                if (file) {
                    showLoadingDialog('Uploading file...');
                    const formData = new FormData();
                    formData.append('file', file);
                    const path = this.selectedNode ? this.selectedNode.key : '';
                    formData.append('path', path);
                    try {
                        await axios.post(`${getBaseUrl()}/fs/upload/${this.simulationId}`, formData);
                        if (this.selectedNode) {
                            this.selectedNode.addChildren({ title: file.name, key: `${path}/${file.name}` });
                        } else {
                            $(this.$refs.tree).fancytree("getRootNode").addChildren({ title: file.name, key: `${path}/${file.name}` });
                        }
                        showSuccessDialog('File uploaded successfully');
                    } catch (error) {
                        showErrorDialog('Failed to upload file');
                    }
                }
            },
            async downloadFile() {
                if (this.selectedNode) {
                    const url = `${getBaseUrl()}/fs/download/${this.simulationId}?path=${this.selectedNode.key}`;
                    window.open(url, '_blank');
                }
            },
            async downloadFolder() {
                if (this.selectedNode && this.selectedNode.folder) {
                    const url = `${getBaseUrl()}/fs/download_folder/${this.simulationId}?path=${this.selectedNode.key}`;
                    window.open(url, '_blank');
                } else {
                    showErrorDialog("Please select a folder to download.");
                }
            },
            async renameFileOrFolder() {
                const { value: newName } = await Swal.fire({
                    title: 'Enter new name',
                    input: 'text',
                    inputPlaceholder: 'New name',
                    showCancelButton: true,
                    inputValue: this.selectedNode.title,
                    inputValidator: (value) => {
                        if (!value) {
                            return 'You need to write something!';
                        }
                    }
                });

                if (newName) {
                    showLoadingDialog('Renaming...');
                    const oldPath = this.selectedNode.key;
                    const newPath = oldPath.split('/').slice(0, -1).concat(newName).join('/');
                    try {
                        if (this.selectedNode.folder) {
                            await axios.post(`${getBaseUrl()}/fs/rename_directory/${this.simulationId}`, { oldPath, newPath });
                        } else {
                            await axios.post(`${getBaseUrl()}/fs/rename/${this.simulationId}`, { oldPath, newPath });
                        }
                        this.selectedNode.setTitle(newName);
                        this.selectedNode.key = newPath;
                        showSuccessDialog('Renamed successfully');
                    } catch (error) {
                        showErrorDialog('Failed to rename');
                    }
                }
            },
            async moveFileOrFolder() {
                const { value: newParentPath } = await Swal.fire({
                    title: 'Enter new parent path',
                    input: 'text',
                    inputPlaceholder: 'New parent path',
                    showCancelButton: true,
                    inputValidator: (value) => {
                        if (!value) {
                            return 'You need to write something!';
                        }
                    }
                });

                if (newParentPath) {
                    showLoadingDialog('Moving...');
                    const srcPath = this.selectedNode.key;
                    const dstPath = `${newParentPath}/${this.selectedNode.title}`;
                    try {
                        if (this.selectedNode.folder) {
                            await axios.post(`${getBaseUrl()}/fs/move_directory/${this.simulationId}`, { srcPath, dstPath });
                        } else {
                            await axios.post(`${getBaseUrl()}/fs/move/${this.simulationId}`, { srcPath, dstPath });
                        }
                        this.selectedNode.remove();
                        showSuccessDialog('Moved successfully');
                    } catch (error) {
                        showErrorDialog('Failed to move');
                    }
                }
            },
            async deleteFileOrFolder() {
                showConfirmDialog('Are you sure you want to delete this?', async () => {
                    const path = this.selectedNode.key;
                    showLoadingDialog('Deleting...');
                    try {
                        if (this.selectedNode.folder) {
                            await axios.post(`${getBaseUrl()}/fs/delete_directory/${this.simulationId}`, { path });
                        } else {
                            await axios.post(`${getBaseUrl()}/fs/delete/${this.simulationId}`, { path });
                        }
                        this.selectedNode.remove();
                        showSuccessDialog('Deleted successfully');
                    } catch (error) {
                        showErrorDialog('Failed to delete');
                    }
                });
            },
            async copyFile() {
                if (this.selectedNode && !this.selectedNode.folder) {
                    const { value: newParentPath } = await Swal.fire({
                        title: 'Enter destination path',
                        input: 'text',
                        inputPlaceholder: 'Destination path',
                        showCancelButton: true,
                        inputValidator: (value) => {
                            if (!value) {
                                return 'You need to write something!';
                            }
                        }
                    });

                    if (newParentPath) {
                        showLoadingDialog('Copying...');
                        const srcPath = this.selectedNode.key;
                        const dstPath = `${newParentPath}/${this.selectedNode.title}`;
                        try {
                            await axios.post(`${getBaseUrl()}/fs/copy/${this.simulationId}`, { srcPath, dstPath });
                            showSuccessDialog('Copied successfully');
                        } catch (error) {
                            showErrorDialog('Failed to copy');
                        }
                    }
                } else {
                    showErrorDialog("Only files can be copied.");
                }
            },
        },
    };
</script>

<style scoped>
    .buttons {
        margin-top: 10px;
    }
    .buttons button {
        margin-right: 5px;
    }
</style>
