<template>
    <div class="log-display">
        <div class="ms-auto text-end">
            <a class="btn btn-link text-success px-3 mb-0" @click="startFetching" v-if="!isFetching">
                <i class="text-success fas fa-play me-2" aria-hidden="true"></i>Start Polling
            </a>
            <a class="btn btn-link text-danger px-3 mb-0" @click="stopFetching" v-if="isFetching">
                <i class="fas fa-stop-circle text-danger me-2" aria-hidden="true" :class="{ 'fa-spin': isFetching }"></i>Stop
            </a>
        </div>
        <textarea ref="logArea" class="log-area" readonly v-model="logs"></textarea>
    </div>
</template>

<script>
    import axios from 'axios';
    import {getBaseUrl} from "../../utils/baseUrl";

    export default {
        name: 'LogDisplay',
        props: ['simulationId'],
        data() {
            return {
                logs: '',
                isFetching: false,
                fetchInterval: null,
                pollCount: 0,
                maxPolls: 10, // Set the maximum number of polls
            };
        },
        methods: {
            startFetching() {
                if (!this.isFetching) {
                    this.isFetching = true;
                    this.pollCount = 0; // Reset poll count when starting
                    this.fetchLogs();
                    this.fetchInterval = setInterval(this.fetchLogs, 1000); // Fetch logs every 5 seconds
                }
            },
            stopFetching() {
                if (this.isFetching) {
                    clearInterval(this.fetchInterval);
                    this.isFetching = false;
                }
            },
            fetchLogs() {
                if (this.pollCount < this.maxPolls) {
                    axios.get(`${getBaseUrl()}/api/logs/${this.simulationId}`)
                        .then(response => {
                            this.logs = response.data;
                            this.pollCount++;
                            this.scrollToBottom();
                        })
                        .catch(error => {
                            console.error("Error fetching logs:", error);
                        });
                } else {
                    this.stopFetching();
                }
            },
            scrollToBottom() {
                this.$nextTick(() => {
                    const logArea = this.$refs.logArea;
                    logArea.scrollTop = logArea.scrollHeight;
                });
            }
        },
        beforeUnmount() {
            this.stopFetching();
        }
    };
</script>

<style scoped>
    .log-display {
        display: flex;
        flex-direction: column;
        align-items: center;
        width: 100%;
    }

    .controls {
        margin-bottom: 10px;
    }

    .log-area {
        width: 100%;
        height: 400px;
        background-color: black;
        color: #00FF00; /* Greenish text */
        font-family: monospace;
        padding: 10px;
        border: none;
        resize: none;
    }

    .fa-spin {
        animation: fa-spin 2s infinite linear;
    }

    @keyframes fa-spin {
        0% {
            opacity: 0.2;
        }
        100% {
            opacity: 1;
        }
    }
</style>
