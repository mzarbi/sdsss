<template>
  <div>
      <div class="d-flex align-items-center mb-3">
        <input name="search" placeholder="Filter..." autocomplete="off" class="form-control me-2" />
        <button id="btnResetSearch" class="btn btn-outline-secondary" style="margin-bottom: 0rem !important;">&times;</button>
      </div>
    <div ref="tree2"></div>
  </div>
</template>

<script>
  import $ from 'jquery';
  import 'jquery.fancytree/dist/skin-lion/ui.fancytree.css';
  import 'jquery.fancytree';
  import 'jquery.fancytree/dist/modules/jquery.fancytree.childcounter';
  import 'jquery.fancytree/dist/modules/jquery.fancytree.filter.js';


  import axios from 'axios';
  import {getBaseUrl} from "../utils/baseUrl";

  export default {
    name: 'FileExplorer',
    data() {
      return {
        selectedNode: null,
      };
    },
    mounted() {
      this.initializeFancyTree();
    },
    methods: {
      async fetchFileTree() {
        const response = await axios.get(`${getBaseUrl()}/fs/list-s3`);
        return response.data;
      },
      initializeFancyTree() {
        this.fetchFileTree().then(data => {
          $(this.$refs.tree2).fancytree({
            source: data.children,
            extensions: ['multi', 'childcounter', "filter"],
            quicksearch: true,
            selectMode: 2,
            filter: {
              autoApply: true,   // Re-apply last filter if lazy data is loaded
              autoExpand: false, // Expand all branches that contain matches while filtered
              counter: true,     // Show a badge with number of matching child nodes near parent icons
              fuzzy: false,      // Match single characters in order, e.g. 'fb' will match 'FooBar'
              hideExpandedCounter: true,  // Hide counter badge if parent is expanded
              hideExpanders: false,       // Hide expanders if all child nodes are hidden by filter
              highlight: true,   // Highlight matches by wrapping inside <mark> tags
              leavesOnly: false, // Match end nodes only
              nodata: true,      // Display a 'no data' status node if result is empty
              mode: "dimm"       // Grayout unmatched nodes (pass "hide" to remove unmatched node instead)
            },
            childcounter: {
              deep: true,
              hideZeros: true,
              hideExpanded: true
            },
            activate: (event, data) => {
              this.selectedNode = data.node;
            },
            select: (event, data) => {
              const selectedNodes = $.map(data.tree.getSelectedNodes(), function (node) {
                return node;
              });
              console.log(selectedNodes);
            }
          });
        }).catch(error => {
          console.error("Error loading file tree:", error);
        });

        $("input[name=search]").on("keyup", function(e){
          var n,
                  tree = $.ui.fancytree.getTree(),
                  args = "autoApply autoExpand fuzzy hideExpanders highlight leavesOnly nodata".split(" "),
                  opts = {},
                  filterFunc = $("#branchMode").is(":checked") ? tree.filterBranches : tree.filterNodes,
                  match = $(this).val();

          $.each(args, function(i, o) {
            opts[o] = $("#" + o).is(":checked");
          });
          opts.mode = $("#hideMode").is(":checked") ? "hide" : "dimm";

          if(e && e.which === $.ui.keyCode.ESCAPE || $.trim(match) === ""){
            $("button#btnResetSearch").trigger("click");
            return;
          }
          if($("#regex").is(":checked")) {
            // Pass function to perform match
            n = filterFunc.call(tree, function(node) {
              return new RegExp(match, "i").test(node.title);
            }, opts);
          } else {
            // Pass a string to perform case insensitive matching
            n = filterFunc.call(tree, match, opts);
          }
          $("button#btnResetSearch").attr("disabled", false);
          $("span#matches").text("(" + n + " matches)");
        }).focus();


        $("button#btnResetSearch").click(function(){
          $("input[name=search]").val("");
          $("span#matches").text("");
          const tree = $.ui.fancytree.getTree()
          tree.clearFilter();
        }).attr("disabled", true);
      }
    }
  };
</script>

<style scoped>
  /* Add any necessary styles here */
</style>