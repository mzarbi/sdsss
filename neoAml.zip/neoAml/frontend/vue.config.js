module.exports = {
  publicPath: '/app/'
};
