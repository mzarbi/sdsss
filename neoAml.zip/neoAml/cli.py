import os

import click
from dotenv import load_dotenv
from huey.consumer import Consumer

from tq.tasks import task_queue


@click.group()
def cli():
    """A simple CLI group."""
    pass


@cli.command()
def init_environment():
    load_dotenv()
    cache_path = os.environ["CACHE_PATH"]
    os.makedirs(os.path.join(cache_path, "SIMULATIONS"), exist_ok=True)
    os.makedirs(os.path.join(cache_path, "CACHED_PROPERTIES"), exist_ok=True)

@cli.command()
@click.option('--db-path', default='huey_tinydb.json', help='Path to the TinyDB file.')
@click.option('--workers', default=5, help='Number of worker threads.')
@click.option('--periodic', is_flag=True, help='Run periodic tasks.')
@click.option('--initial-delay', default=1, help='Initial delay before starting worker threads.')
def start_consumer(db_path, workers, periodic, initial_delay):
    """Start the Huey consumer."""
    consumer = Consumer(task_queue, workers=workers, periodic=periodic, initial_delay=initial_delay)
    consumer.run()


if __name__ == '__main__':
    cli()
