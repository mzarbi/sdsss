import logging
import os

from flasgger import Swagger
from flask import Flask, g, jsonify
from flask_cors import CORS


def app_factory(script_info=None):
    # instantiate the app
    logger = logging.getLogger()
    vue_dist_path = os.path.join(os.getcwd(), 'frontend', 'dist')
    app = Flask(__name__, static_folder=vue_dist_path, template_folder=vue_dist_path, static_url_path=f'/{os.environ["APP_BRANCH"][:-1]}')

    @app.before_request
    def load_user_id():
        g.user_id = "e63551"
        g.user_email = "medzied.arbi@bnp.com"
        g.user_name = "Mohamed Zied El Arbi"

    @app.errorhandler(404)
    def not_found_error(error):
        return jsonify(error="Resource not found", message=str(error)), 404

    @app.errorhandler(500)
    def internal_error(error):
        app.logger.error(f"Server Error: {str(error)}")
        return jsonify(error="Internal server error",
                       message="An unexpected error occurred. Please try again later."), 500

    CORS(app, resources={r'/*': {'origins': '*'}})
    Swagger(app)
    # set config
    for key, value in os.environ.items():
        app.config[key] = value

    logger.info("Registering blueprints")

    logger.info(f"\tRegistering blueprint : /api")
    from .api import api_blueprint
    app.register_blueprint(api_blueprint, url_prefix=f'/{os.environ["APP_BRANCH"]}api')

    logger.info(f"\tRegistering blueprint : /fs")
    from .file_system import fs_blueprint
    app.register_blueprint(fs_blueprint, url_prefix=f'/{os.environ["APP_BRANCH"]}fs')

    logger.info(f"\tRegistering blueprint : /dashboard")
    from .dashboard import dashboard_blueprint
    app.register_blueprint(dashboard_blueprint, url_prefix=f'/{os.environ["APP_BRANCH"]}dashboard')

    logger.info(f"\tRegistering blueprint : /client")
    from .client import client_blueprint
    app.register_blueprint(client_blueprint, url_prefix=f'/{os.environ["APP_BRANCH"]}')

    # shell context for flask cli
    app.shell_context_processor({"app": app})
    with app.app_context():
        pass
    return app
