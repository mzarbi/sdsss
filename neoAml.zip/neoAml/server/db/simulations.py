# database.py
from tinydb import TinyDB, Query
from filelock import FileLock

from server.utils.cache import db_path

# Initialize the database and lock
db = TinyDB(db_path())
lock = FileLock(f"{db_path()}.lock")

# Define the table for simulations
simulations_table = db.table('simulations')


def add_simulation(simulation):
    with lock:
        simulations_table.insert(simulation)


def get_simulations():
    return simulations_table.all()


def get_simulation_by_id(simulation_id):
    Simulation = Query()
    return simulations_table.get(Simulation.id == simulation_id)


def update_simulation(simulation_id, data):
    Simulation = Query()
    with lock:
        simulations_table.update(data, Simulation.id == simulation_id)


def delete_simulation(simulation_id):
    Simulation = Query()
    with lock:
        simulations_table.remove(Simulation.id == simulation_id)
