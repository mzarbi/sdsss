import os

from flask import Blueprint, current_app, send_from_directory, g, render_template

client_blueprint = Blueprint("client", __name__)


@client_blueprint.route('/', defaults={'path': ''}, methods=['GET'])
@client_blueprint.route('/dashboard', defaults={'path': ''}, methods=['GET'])
@client_blueprint.route('/<path:path>', methods=['GET'])
def serve_vue_app(path):
    if path != "" and os.path.exists(os.path.join(current_app.static_folder, path)):
        return send_from_directory(current_app.static_folder, path)
    else:
        return render_template(
            'index.html',
            user_id=g.user_id,
            user_name=g.user_name,
            user_email=g.user_email,
            app_host=os.environ["APP_ROOT"]
        )
