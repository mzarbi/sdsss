from flask import Blueprint, jsonify

dashboard_blueprint = Blueprint("dashboard", __name__)


@dashboard_blueprint.route('data', methods=['GET'])
def get_dashboard_data():
    data = {
        "statisticsCards": [
            {
                "title": "Active Users",
                "value": "2,300",
                "percentage": {"value": "+5%", "color": "text-success"},
                "icon": {"component": "ni ni-circle-08", "background": "bg-gradient-success"}
            },
            {
                "title": "Simulations",
                "value": "1,200",
                "percentage": {"value": "+10%", "color": "text-success"},
                "icon": {"component": "ni ni-app", "background": "bg-gradient-success"}
            },
            {
                "title": "Ingested Files",
                "value": "300",
                "percentage": {"value": "+2%", "color": "text-success"},
                "icon": {"component": "ni ni-folder-17", "background": "bg-gradient-success"}
            },
            {
                "title": "Completed Tasks",
                "value": "850",
                "percentage": {"value": "+7%", "color": "text-success"},
                "icon": {"component": "ni ni-check-bold", "background": "bg-gradient-success"}
            },
        ],
        "barChartData": {
            "labels": ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            "datasets": {
                "label": "Users",
                "data": [450, 200, 100, 220, 500, 100, 400, 230, 500]
            }
        },
        "barChartItems": [
            {
                "icon": {"color": "primary", "component": "faUsers"},
                "label": "users",
                "progress": {"content": "2,300K", "percentage": 60}
            }
        ],
        "lineChartData": {
            "labels": ["Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
            "datasets": [
                {
                    "label": "Simulations",
                    "data": [300, 400, 200, 300, 500, 200, 300, 400, 600]
                },
                {
                    "label": "Completed Tasks",
                    "data": [200, 300, 150, 250, 400, 300, 350, 200, 500]
                }
            ]
        },
        "recentSimulations": [
            {
                "id": 1,
                "name": "Simulation Alpha",
                "dateStarted": "2023-05-20",
                "collaborators": [
                    {"id": 1, "name": "Alice", "avatar": "path/to/avatar1.jpg"},
                    {"id": 2, "name": "Bob", "avatar": "path/to/avatar2.jpg"}
                ],
                "completion": 75
            },
            {
                "id": 2,
                "name": "Simulation Beta",
                "dateStarted": "2023-05-22",
                "collaborators": [
                    {"id": 3, "name": "Charlie", "avatar": "path/to/avatar3.jpg"},
                    {"id": 4, "name": "David", "avatar": "path/to/avatar4.jpg"}
                ],
                "completion": 50
            }
        ],
        "timelineItems": [
            {"color": "success", "icon": "bell-55", "title": "Simulation #123 completed", "dateTime": "22 DEC 7:20 PM"},
            {"color": "danger", "icon": "html5", "title": "New simulation #1832412 started",
             "dateTime": "21 DEC 11 PM"},
            {"color": "info", "icon": "cart", "title": "Files ingested for simulation #4321",
             "dateTime": "21 DEC 9:34 PM"},
            {"color": "warning", "icon": "credit-card", "title": "New file added for simulation #4395133",
             "dateTime": "20 DEC 2:20 AM"},
            {"color": "primary", "icon": "key-25", "title": "Unlock package for simulation #2431",
             "dateTime": "18 DEC 4:54 AM"},
            {"color": "info", "icon": "check-bold", "title": "Simulation #1234 completed", "dateTime": "15 DEC"}
        ],
        "barChartDescription": "Monthly active users",
        "lineChartDescription": "Trend of simulations over the months",
        "timelineDescription": "Overview of recent simulation activities"
    }

    return jsonify(data)
