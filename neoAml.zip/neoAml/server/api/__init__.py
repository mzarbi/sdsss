import json
import os
import uuid

from flask import Blueprint, jsonify, request

from server.utils.cache import simulation_path
from server.utils.default_steps import create_default_steps
from server.utils.loggers import setup_logger

api_blueprint = Blueprint("api", __name__)


@api_blueprint.route('/create-simulation-folder', methods=['POST'])
def create_simulation_folder():
    data = request.json
    sim_dir = simulation_path(data["id"])
    os.makedirs(sim_dir, exist_ok=True)

    with open(os.path.join(sim_dir, "flow.json"), "w") as f:
        json.dump(data, f, indent=4)

    os.makedirs(os.path.join(sim_dir, "SETTINGS"), exist_ok=True)
    with open(os.path.join(sim_dir, "SETTINGS", "gs.json"), "w") as f:
        json.dump({
            "MODEL_VERSION": f"SAM{data['flowActimizeVersion'][1:]}",
            "LIST_MODEL": data['flowModels'],
            "BU": data['flowBusinessUnit'],
            "LOCAL_CURRENCY_RATE": data['flowLocalCurrencyRate'],
            "LOOKBACK_PERIOD": data['flowLookbackPeriod'],
            "BUCKET_MAPPING_MODE": data['flowBucketMappingMode'],
            "EFT_CONSTANT_THRESHOLDS": {
              "Cash": 15000,
              "Check": 15000
            },
            "ANALYSIS_DATES": {
              "DATA": {
                   "FROM": data['flowDataStartDate'],
                   "TO": data['flowDataEndDate']
              },
              "TRAIN": {
                   "FROM": data['flowTrainStartDate'],
                   "TO": data['flowTrainEndDate']
              },
              "TEST": {
                   "FROM": data['flowTestStartDate'],
                   "TO": data['flowTestEndDate']
              }
            },
            "STANDARD_PERCENTILE": {
              "Excessive Single Transactions": [
                   95,
                   85,
                   75
              ],
              "Flow Through of Funds (Credits / Debits)": [
                   95,
                   85,
                   75
              ],
              "Transfer to/from High-Risk Countries (Level 3)": [
                   98,
                   85,
                   75
              ],
              "Transfer to/from Very High-Risk Countries (Level 4)": [
                   95,
                   80,
                   70
              ]
            },
            "PERCENT_ESCALATION_SIGNIFICANTLY_BELOW": {
              "Flow Through of Funds (Credits / Debits)": 60,
              "Excessive Single Transactions": 60,
              "Transfer to/from High-Risk Countries (Level 3)": 60,
              "Transfer to/from Very High-Risk Countries (Level 4)": 30
            },
            "HITS_ACCOUNT_SIGNIFICANTLY_ABOVE": {
              "Flow Through of Funds (Credits / Debits)": 25,
              "Excessive Single Transactions": 50,
              "Transfer to/from High-Risk Countries (Level 3)": 50,
              "Transfer to/from Very High-Risk Countries (Level 4)": 130
            },
            "HITS_FROM_ESCALATION_SIGNIFICANTLY_ABOVE": {
              "Flow Through of Funds (Credits / Debits)": 25,
              "Excessive Single Transactions": 50,
              "Transfer to/from High-Risk Countries (Level 3)": 50,
              "Transfer to/from Very High-Risk Countries (Level 4)": 130
            }
        }, f, indent=4)

    response = {
        "status": "success",
        "message": "Simulation folder created successfully"
    }
    logger = setup_logger(simulation_path(), data["id"])

    logger.info("Creating default steps")
    create_default_steps(sim_dir)

    logger.info("Simulation folder created with success")
    return jsonify(response)


@api_blueprint.route('/simulations', methods=['POST'])
def create_simulation():
    data = request.json
    simulation_id = str(uuid.uuid4())[:8]
    simulation = {
        'id': simulation_id,
        'name': data.get('flowName'),
        'description': data.get('flowDescription'),
        'business_unit': data.get('flowBusinessUnit'),
        'data_start_date': data.get('flowDataStartDate'),
        'data_end_date': data.get('flowDataEndDate'),
        'status': 'created'
    }
    from server.db.simulations import add_simulation
    add_simulation(simulation)
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Simulation created with success")
    return jsonify({'status': 'success', 'message': 'Simulation created successfully', 'simulation': simulation})


@api_blueprint.route('/simulations', methods=['GET'])
def get_all_simulations():
    page = int(request.args.get('page', 1))
    size = int(request.args.get('size', 5))
    from server.db.simulations import get_simulations
    simulations = get_simulations()
    total = len(simulations)
    start = (page - 1) * size
    end = start + size
    return jsonify({
        'simulations': simulations[start:end],
        'total': total
    })


@api_blueprint.route('/simulations/<simulation_id>', methods=['GET'])
def get_single_simulation(simulation_id):
    from server.db.simulations import get_simulation_by_id
    simulation = get_simulation_by_id(simulation_id)
    if simulation:
        logger = setup_logger(simulation_path(), simulation_id)
        logger.info("Retrieved simulation: %s", simulation_id)
        return jsonify(simulation)
    else:
        logger = setup_logger(simulation_path(), simulation_id)
        logger.warning("Simulation not found: %s", simulation_id)
        return jsonify({'status': 'error', 'message': 'Simulation not found'}), 404


@api_blueprint.route('/simulations/flow/<simulation_id>', methods=['GET'])
def get_simulation_flow(simulation_id):
    BASE_DIR = simulation_path(simulation_id)
    with open(os.path.join(BASE_DIR, "flow.json"), "r") as f:
        return jsonify(json.load(f))


@api_blueprint.route('/simulations/<simulation_id>', methods=['PUT'])
def update_simulation_route(simulation_id):
    data = request.json
    update_data = {}
    if 'name' in data:
        update_data['name'] = data['name']
    if 'description' in data:
        update_data['description'] = data['description']
    if 'business_unit' in data:
        update_data['business_unit'] = data['business_unit']
    if 'data_start_date' in data:
        update_data['data_start_date'] = data['data_start_date']
    if 'data_end_date' in data:
        update_data['data_end_date'] = data['data_end_date']

    from server.db.simulations import update_simulation
    update_simulation(simulation_id, update_data)

    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Updated simulation %s with data: %s", simulation_id, data)

    return jsonify({'status': 'success', 'message': 'Simulation updated successfully'})


@api_blueprint.route('/simulations/<simulation_id>', methods=['DELETE'])
def delete_simulation_route(simulation_id):
    from server.db.simulations import delete_simulation
    delete_simulation(simulation_id)
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Deleted simulation: %s", simulation_id)
    return jsonify({'status': 'success', 'message': 'Simulation deleted successfully'})


@api_blueprint.route('logs/<simulation_id>', methods=['GET'])
def get_logs(simulation_id):
    log_file = os.path.join(simulation_path(), simulation_id, 'simulation.log')
    with open(log_file, "r") as f:
        return jsonify(f.read())


@api_blueprint.route('load-step/<simulation_id>/<step>', methods=['GET'])
def load_data(simulation_id, step):
    step_file = os.path.join(simulation_path(), simulation_id, 'SETTINGS', f"{step}.json")
    with open(step_file, "r") as f:
        return jsonify(json.load(f))


@api_blueprint.route('save-step/<simulation_id>/<step>', methods=['POST'])
def save_data(simulation_id, step):
    data = request.json.get('data')
    step_file = os.path.join(simulation_path(), simulation_id, 'SETTINGS', f"{step}.json")
    with open(step_file, "w") as f:
        json.dump(data, f, indent=5)

    logger = setup_logger(simulation_path(), simulation_id)
    logger.info(f"Data received for saving: simulation/{simulation_id} step/{step}")
    return jsonify({"status": "success", "message": "Data saved successfully"})


@api_blueprint.route('run/<simulation_id>/<step>', methods=['POST'])
def run_data(simulation_id, step):
    data = request.json.get('data')
    step_file = os.path.join(simulation_path(), simulation_id, 'SETTINGS', f"{step}.json")
    with open(step_file, "w") as f:
        json.dump(data, f, indent=5)

    logger = setup_logger(simulation_path(), simulation_id)
    logger.info(f"Run request received: simulation/{simulation_id} step/{step}")
    return jsonify({"status": "success", "message": "Run started successfully"})


@api_blueprint.route('load-gs/<simulation_id>', methods=['GET'])
def load_gs(simulation_id):
    step_file = os.path.join(simulation_path(), simulation_id, "SETTINGS", f"gs.json")
    with open(step_file, "r") as f:
        return jsonify(json.load(f))


@api_blueprint.route('save-gs/<simulation_id>', methods=['POST'])
def save_gs(simulation_id):
    data = request.json.get('data')
    step_file = os.path.join(simulation_path(), simulation_id, "SETTINGS", f"gs.json")
    with open(step_file, "w") as f:
        json.dump(data, f, indent=5)

    logger = setup_logger(simulation_path(), simulation_id)
    logger.info(f"Data received for saving: simulation/{simulation_id}")
    return jsonify({"status": "success", "message": "Data saved successfully"})
