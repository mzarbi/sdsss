import os


def simulation_path(id=None):
    if id:
        return os.path.join(os.environ["CACHE_PATH"], "SIMULATIONS", id)
    return os.path.join(os.environ["CACHE_PATH"], "SIMULATIONS")


def db_path():
    return os.path.join(os.environ["CACHE_PATH"], "manifest.json")
