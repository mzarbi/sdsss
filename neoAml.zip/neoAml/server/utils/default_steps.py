import json
import os

DEFAULT_STEPS = {
    "0": {
        "EXPERIMENT_KEY": "RAW",
        "PIPELINE_STEPS": {
            "PARAMETERS_SERIALIZATION": {
                "PARAMETERS": "KEY"
            },
            "DATA_SERIALIZATION": {
                "ALERTS_SERIALISATION": True,
                "TRANSACTIONS_SERIALISATION": True,
                "AMLIT_ALERTS_SERIALISATION": "",
                "LOOKBACK_SUMS": True
            }
        }
    },
    "1": {
        "EXPERIMENT_KEY": "run0_simul",
        "PIPELINE_STEPS": {
            "CLUSTERING_FEATURES": {
                "TRANSACTIONS": "RAW",
                "PARAMETERS": "RAW",
                "LOOKBACK_SUMS": "RAW"
            },
        }
    },
    "2": {
        "PIPELINE_STEPS": {
            "CLUSTERING": {
                "TRANSACTIONS": "RAW",
                "FEATURES": "run0_simul",
                "CLUSTERS": "KEY",
                "LOOKBACK_SUMS": "RAW"
            },
            "THRESHOLDS": {
                "TRANSACTIONS": "KEY",
                "PARAMETERS": "RAW",
                "L2_RECALL_TRAIN": 100.0,
                "L2_RECALL_TEST": 100.0,
                "LOOKBACK_SUMS": "KEY",
                "FEATURES": "run0_simul",
            },
            "ALERTING": {
                "TRANSACTIONS": "KEY",
                "PROD_ALERTS": ["3PP", "ADR", "EPC", "HBC", "KEY", "LOW", "NBI", "SCT", "STP"],
                "PROD_ALERTS_KEY": "truth",
                "PARAMETERS": "RAW",
                "LOOKBACK_SUMS": "KEY",
                "THRESHOLDS": "KEY",
                "ANALYSIS_DATES": "TRAIN"
            },
            "KPIS": {
                "TRANSACTIONS": "KEY",
                "ALERTS": "KEY",
                "BASELINE": "truth",
                "PARAMETERS": "RAW",
                "ANALYSIS_DATES": "TRAIN"
            },
        }
    },
    "3": {
        "EXPERIMENT_KEY": "run0_simul",
        "PIPELINE_STEPS": {
            "CLUSTERING": {
                "TRANSACTIONS": "RAW",
                "FEATURES": "run0_simul",
                "CLUSTERS": "KEY",  # pour injecter dans les transactions
                "LOOKBACK_SUMS": "RAW"
            },
            "THRESHOLDS": {
                "TRANSACTIONS": "KEY",
                "PARAMETERS": "RAW",
                "L2_RECALL_TRAIN": 100.0,  # à voir si on le set up correctement dans le code
                "L2_RECALL_TEST": 100.0,
                "LOOKBACK_SUMS": "KEY",
                "FEATURES": "run0_simul",
            },
            "ALERTING": {
                "TRANSACTIONS": "KEY",
                "PROD_ALERTS": ["3PP", "ADR", "EPC", "HBC", "KEY", "LOW", "NBI", "SCT", "STP"],
                # modèles V3, à changer sur run 1 pour intégrer les alertes v8 du run 1
                "PROD_ALERTS_KEY": "truth",
                "PARAMETERS": "RAW",
                "LOOKBACK_SUMS": "KEY",
                "THRESHOLDS": "KEY",
                "ANALYSIS_DATES": "TEST"  # TEST SET!!
            },
            "KPIS": {
                "TRANSACTIONS": "KEY",
                "ALERTS": "KEY",
                "BASELINE": "truth",
                "PARAMETERS": "RAW",
                "ANALYSIS_DATES": "TEST"  # TEST SET!!
            },
            "FILES_EXPORT": {
                "FEATURES": "run0_simul",
                "THRESHOLDS": "KEY",
                "PARAMETERS": "RAW",
                "TRANSACTIONS": "KEY",
                "CLUSTERS": "KEY",
                "ALERTS": "KEY"
            }
        }
    },
    "4": {
        "EXPERIMENT_KEY": "run0_simul",
        "PIPELINE_STEPS": {
            "DATA_SERIALIZATION": {
                "ALERTS_SERIALISATION": False,
                "TRANSACTIONS_SERIALISATION": False,
                "AMLIT_ALERTS_SERIALISATION": "run0",
                "LOOKBACK_SUMS": False
            },
            "ALERTING": {
                "TRANSACTIONS": "run0_simul",
                "PROD_ALERTS": ["ADR", "CTF", "EPC", "KHI", "KLO", "LTH", "NBI", "SBP", "STP", "THV"],
                "PROD_ALERTS_KEY": "run0_AMLIT",
                "PARAMETERS": "RAW",
                "LOOKBACK_SUMS": "run0_simul",
                "THRESHOLDS": "run0_simul",
                "ANALYSIS_DATES": "TEST",
            },
            "KPIS": {
                "TRANSACTIONS": "run0_simul",
                "ALERTS": "KEY",
                "BASELINE": "run0_AMLIT",
                "PARAMETERS": "RAW",
                "ANALYSIS_DATES": "TEST",
            },
        }

    },
    "5": {
        "EXPERIMENT_KEY": "run0_simul",
        "PIPELINE_STEPS": {
            "FILES_EXPORT": {
                "FEATURES": "run0_simul",
                "THRESHOLDS": "run0_simul",
                "PARAMETERS": "RAW",
                "TRANSACTIONS": "run0_simul",
                "CLUSTERS": "run0_simul",
                "ALERTS": "run0_AMLIT"
            }
        }

    },
    "6": {
        "EXPERIMENT_KEY": "run0_simul",
        "PIPELINE_STEPS": {
            "PARAMETERS_SERIALIZATION": {
                "PARAMETERS": "RAW"
            },
            "CLUSTERING_FEATURES": {
                "TRANSACTIONS": "RAW",
                "PARAMETERS": "KEY",
                "LOOKBACK_SUMS": "RAW"
            },
            "CLUSTERING": {
                "TRANSACTIONS": "RAW",
                "FEATURES": "KEY",
                "CLUSTERS": "KEY",
                "LOOKBACK_SUMS": "RAW"
            },
            "THRESHOLDS": {
                "TRANSACTIONS": "KEY",
                "PARAMETERS": "KEY",
                "L2_RECALL_TRAIN": 100.0,
                "L2_RECALL_TEST": 100.0,
                "LOOKBACK_SUMS": "KEY",
                "FEATURES": "KEY"
            },
            "ALERTING": {
                "TRANSACTIONS": "KEY",
                "PROD_ALERTS": ["ADR", "CTF", "EPC", "KHI", "KLO", "LTH", "NBI", "SBP", "STP", "THV"],
                "PROD_ALERTS_KEY": "truth",
                "PARAMETERS": "KEY",
                "LOOKBACK_SUMS": "KEY",
                "THRESHOLDS": "KEY",
                "ANALYSIS_DATES": "TEST"
            },
            "KPIS": {
                "TRANSACTIONS": "KEY",
                "ALERTS": "KEY",
                "BASELINE": "truth",
                "PARAMETERS": "KEY",
                "ANALYSIS_DATES": "TEST"
            },
            "FILES_EXPORT": {
                "FEATURES": "KEY",
                "THRESHOLDS": "KEY",
                "PARAMETERS": "KEY",
                "TRANSACTIONS": "KEY",
                "CLUSTERS": "KEY",
                "ALERTS": "KEY"
            }
        }
    }
}


def create_default_steps(simulation_dir, step=None):
    steps_path = os.path.join(simulation_dir, "SETTINGS")
    os.makedirs(steps_path, exist_ok=True)
    if step:
        with open(os.path.join(steps_path, f"{step}.json"), "w") as f:
            json.dump(DEFAULT_STEPS[step], f, indent=5)
        return
    for k, v in DEFAULT_STEPS.items():
        with open(os.path.join(steps_path, f"{k}.json"), "w") as f:
            json.dump(v, f, indent=5)