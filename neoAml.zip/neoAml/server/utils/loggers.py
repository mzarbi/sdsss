import logging
from logging.handlers import RotatingFileHandler
import os


def setup_logger(simulations_folder, simulation_id):
    logger = logging.getLogger(f'simulation_{simulation_id}')
    logger.setLevel(logging.INFO)

    # Ensure the directory exists
    log_dir = os.path.join(simulations_folder, simulation_id)
    os.makedirs(log_dir, exist_ok=True)

    handler = RotatingFileHandler(os.path.join(log_dir, 'simulation.log'), maxBytes=10000, backupCount=3)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    if not logger.hasHandlers():
        logger.addHandler(handler)

    return logger
