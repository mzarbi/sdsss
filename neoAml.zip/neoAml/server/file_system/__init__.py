import os
import shutil
import zipfile
from io import BytesIO

from flask import Blueprint, request, jsonify, send_from_directory, send_file

from server.file_system.utils import list_s3, build_virtual_dir, list_dir
from server.utils.cache import simulation_path
from server.utils.loggers import setup_logger

fs_blueprint = Blueprint("fs", __name__)



@fs_blueprint.route('/list-s3', methods=['GET'])
def list_s3_files():
    prefix = ""  # Add a way to dynamically get prefix if needed
    file_list = list_s3("", prefix)
    virtual_tree = build_virtual_dir(file_list)

    response = {
        'title': '',
        'key': "",
        'folder': True,
        'children': [{
            'title': 'ROOT',
            'key': "",
            'folder': True,
            'children':virtual_tree
        }]
    }
    return jsonify(response)





@fs_blueprint.route('/list/<simulation_id>', methods=['GET'])
def list_files(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Listing files for simulation: %s", simulation_id)

    BASE_DIR = simulation_path(simulation_id)
    response = {
        'title': '',
        'key': "",
        'folder': True,
        'children': [{
            'title': simulation_id,
            'key': os.path.join(simulation_path(simulation_id)),
            'folder': True,
            'children': list_dir(BASE_DIR)
        }]
    }
    return jsonify(response)


@fs_blueprint.route('/upload/<simulation_id>', methods=['POST'])
def upload_file(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Uploading file for simulation: %s", simulation_id)

    BASE_DIR = simulation_path(simulation_id)
    file = request.files['file']
    path = request.form.get('path', "")
    file.save(os.path.join(BASE_DIR, path, file.filename))
    logger.info("Uploaded file: %s to path: %s", file.filename, path)
    return jsonify({'status': 'success', 'message': 'File uploaded successfully'})


@fs_blueprint.route('/download/<simulation_id>', methods=['GET'])
def download_file(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Downloading file for simulation: %s", simulation_id)

    relative_path = request.args.get('path')
    file_path = os.path.join(simulation_path(simulation_id), relative_path)
    directory, filename = os.path.split(file_path)
    logger.info("Downloading file: %s from path: %s", filename, directory)
    return send_from_directory(directory, filename, as_attachment=True)


@fs_blueprint.route('/download_folder/<simulation_id>', methods=['GET'])
def download_folder(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Downloading folder for simulation: %s", simulation_id)

    relative_path = request.args.get('path')
    folder_path = os.path.join(simulation_path(simulation_id), relative_path)

    if not os.path.isdir(folder_path):
        logger.warning("Path is not a directory: %s", folder_path)
        return jsonify({'error': 'Not a directory'}), 400

    # Create a zip file in memory
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, folder_path)
                zip_file.write(file_path, arcname)

    zip_buffer.seek(0)

    logger.info("Created zip for folder: %s", folder_path)
    return send_file(zip_buffer, mimetype='application/zip', as_attachment=True,
                     download_name=f"{os.path.basename(folder_path)}.zip")


@fs_blueprint.route('/rename/<simulation_id>', methods=['POST'])
def rename_file(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Renaming file for simulation: %s", simulation_id)

    data = request.json
    BASE_DIR = simulation_path(simulation_id)
    old_path = os.path.join(BASE_DIR, data['oldPath'])
    new_path = os.path.join(BASE_DIR, data['newPath'])
    os.rename(old_path, new_path)
    logger.info("Renamed file from %s to %s", old_path, new_path)
    return jsonify({'status': 'success'})


@fs_blueprint.route('/move/<simulation_id>', methods=['POST'])
def move_file(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Moving file for simulation: %s", simulation_id)

    data = request.json
    BASE_DIR = simulation_path(simulation_id)
    src_path = os.path.join(BASE_DIR, data['srcPath'])
    dst_path = os.path.join(BASE_DIR, data['dstPath'])
    shutil.move(src_path, dst_path)
    logger.info("Moved file from %s to %s", src_path, dst_path)
    return jsonify({'status': 'success'})


@fs_blueprint.route('/delete/<simulation_id>', methods=['POST'])
def delete_file(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Deleting file for simulation: %s", simulation_id)

    data = request.json
    BASE_DIR = simulation_path(simulation_id)
    path = os.path.join(BASE_DIR, data['path'])
    if os.path.isdir(path):
        shutil.rmtree(path)
        logger.info("Deleted directory: %s", path)
    else:
        os.remove(path)
        logger.info("Deleted file: %s", path)
    return jsonify({'status': 'success'})


@fs_blueprint.route('/copy/<simulation_id>', methods=['POST'])
def copy_file(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Copying file for simulation: %s", simulation_id)

    data = request.json
    BASE_DIR = simulation_path(simulation_id)
    src_path = os.path.join(BASE_DIR, data['srcPath'])
    dst_path = os.path.join(BASE_DIR, data['dstPath'])
    if os.path.isdir(src_path):
        shutil.copytree(src_path, dst_path)
        logger.info("Copied directory from %s to %s", src_path, dst_path)
    else:
        shutil.copy2(src_path, dst_path)
        logger.info("Copied file from %s to %s", src_path, dst_path)
    return jsonify({'status': 'success'})


@fs_blueprint.route('/create_folder/<simulation_id>', methods=['POST'])
def create_folder(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Creating folder for simulation: %s", simulation_id)

    data = request.json
    BASE_DIR = simulation_path(simulation_id)
    path = os.path.join(BASE_DIR, data['path'])
    os.makedirs(path, exist_ok=True)
    logger.info("Created folder: %s", path)
    return jsonify({'status': 'success'})


@fs_blueprint.route('/check_existence/<simulation_id>', methods=['GET'])
def check_existence(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Checking existence for simulation: %s", simulation_id)

    path = request.args.get('path')
    exists = os.path.exists(os.path.join(simulation_path(simulation_id), path))
    logger.info("Path %s exists: %s", path, exists)
    return jsonify({'exists': exists})


@fs_blueprint.route('/file_info/<simulation_id>', methods=['GET'])
def file_info(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Retrieving file info for simulation: %s", simulation_id)

    path = request.args.get('path')
    abs_path = os.path.join(simulation_path(simulation_id), path)
    if os.path.exists(abs_path):
        info = {
            'size': os.path.getsize(abs_path),
            'is_directory': os.path.isdir(abs_path),
            'modification_time': os.path.getmtime(abs_path)
        }
        logger.info("Retrieved info for path: %s", abs_path)
        return jsonify(info)
    else:
        logger.warning("File or directory does not exist: %s", abs_path)
        return jsonify({'error': 'File or directory does not exist'}), 404


@fs_blueprint.route('/list_directory/<simulation_id>', methods=['GET'])
def list_directory(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Listing directory for simulation: %s", simulation_id)

    BASE_DIR = simulation_path(simulation_id)
    path = request.args.get('path', "")
    if os.path.isdir(os.path.join(BASE_DIR, path)):
        logger.info("Directory exists: %s", path)
        return jsonify(list_dir(BASE_DIR, path))
    else:
        logger.warning("Not a directory: %s", path)
        return jsonify({'error': 'Not a directory'}), 400


@fs_blueprint.route('/delete_directory/<simulation_id>', methods=['POST'])
def delete_directory(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Deleting directory for simulation: %s", simulation_id)

    data = request.json
    BASE_DIR = simulation_path(simulation_id)
    path = os.path.join(BASE_DIR, data['path'])
    if os.path.isdir(path):
        shutil.rmtree(path)
        logger.info("Deleted directory: %s", path)
        return jsonify({'status': 'success'})
    else:
        logger.warning("Not a directory: %s", path)
        return jsonify({'error': 'Not a directory'}), 400


@fs_blueprint.route('/move_directory/<simulation_id>', methods=['POST'])
def move_directory(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Moving directory for simulation: %s", simulation_id)

    data = request.json
    BASE_DIR = simulation_path(simulation_id)
    src_path = os.path.join(BASE_DIR, data['srcPath'])
    dst_path = os.path.join(BASE_DIR, data['dstPath'])
    if os.path.isdir(src_path):
        shutil.move(src_path, dst_path)
        logger.info("Moved directory from %s to %s", src_path, dst_path)
        return jsonify({'status': 'success'})
    else:
        logger.warning("Source path is not a directory: %s", src_path)
        return jsonify({'error': 'Source path is not a directory'}), 400


@fs_blueprint.route('/rename_directory/<simulation_id>', methods=['POST'])
def rename_directory(simulation_id):
    logger = setup_logger(simulation_path(), simulation_id)
    logger.info("Renaming directory for simulation: %s", simulation_id)

    data = request.json
    BASE_DIR = simulation_path(simulation_id)
    old_path = os.path.join(BASE_DIR, data['oldPath'])
    new_path = os.path.join(BASE_DIR, data['newPath'])
    if os.path.isdir(old_path):
        os.rename(old_path, new_path)
        logger.info("Renamed directory from %s to %s", old_path, new_path)
        return jsonify({'status': 'success'})
    else:
        logger.warning("Old path is not a directory: %s", old_path)
        return jsonify({'error': 'Old path is not a directory'}), 400


@fs_blueprint.route('/check_files', methods=['POST'])
def check_files():
    data = request.json
    data_type = data['dataType']
    start_date = data['startDate']
    end_date = data['endDate']
    actimize_version = data['actimizeVersion']
    file_count = 0
    return jsonify({'count': file_count})


@fs_blueprint.route('/download_files/<simulation_id>', methods=['POST'])
def download_files(simulation_id):
    data = request.json
    data_type = data['dataType']
    start_date = data['startDate']
    end_date = data['endDate']
    actimize_version = data['actimizeVersion']

    BASE_DIR = simulation_path(simulation_id)
    DOWNLOAD_DIR = os.path.join(BASE_DIR, 'INPUT')
    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    logger = setup_logger(BASE_DIR, simulation_id)
    logger.info("Initiating download for data type: %s, start date: %s, end date: %s, actimize version: %s",
                data_type, start_date, end_date, actimize_version)

    logger.info("Download completed. Files saved to %s", DOWNLOAD_DIR)
    return jsonify({'status': 'success', 'message': 'Files are being downloaded to the simulation directory.'})
