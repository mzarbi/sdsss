import os


def list_s3(bucket_name, prefix=""):
    return []


def build_virtual_dir(file_list):
    virtual_dir = {}

    for file_path in file_list:
        parts = file_path.split('/')
        current_level = virtual_dir

        for part in parts:
            if part not in current_level:
                current_level[part] = {}
            current_level = current_level[part]

    def dict_to_tree(d):
        return [{'title': k, 'key': k, 'folder': bool(v), 'children': dict_to_tree(v)} for k, v in d.items()]

    return dict_to_tree(virtual_dir)


def list_dir(base_path, relative_path=""):
    items = []
    path = os.path.join(base_path, relative_path)
    for name in os.listdir(path):
        item_path = os.path.join(relative_path, name)
        abs_item_path = os.path.join(base_path, item_path)
        if os.path.isdir(abs_item_path):
            items.append({
                'title': name,
                'key': item_path,
                'folder': True,
                'children': list_dir(base_path, item_path)
            })
        else:
            items.append({
                'title': name,
                'key': item_path,
                'folder': False,
                'children': []
            })
    return items
