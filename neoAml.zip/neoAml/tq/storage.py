import hashlib
import itertools
import os
import shutil
import struct
import threading
import time

from huey.constants import EmptyData
from huey.storage import BaseStorage
from tinydb import TinyDB, Query
from filelock import FileLock
from contextlib import contextmanager
import base64
import datetime
from huey.utils import text_type

@contextmanager
def open_db(db_path):
    lock_path = f"{db_path}.lock"
    lock = FileLock(lock_path)
    with lock:
        db = TinyDB(db_path)
        yield db
        db.close()


import os
import time
import threading
import struct
import itertools
import hashlib
import shutil
from huey.storage import BaseStorage
import portalocker

class FileStorage2(BaseStorage):
    """
    Simple file-system storage implementation.

    This storage implementation should NOT be used in production as it utilizes
    exclusive locks around all file-system operations. This is done to prevent
    race-conditions when reading from the file-system.
    """
    MAX_PRIORITY = 0xffff

    def __init__(self, name, path, levels=2, use_thread_lock=False,
                 **storage_kwargs):
        super(FileStorage2, self).__init__(name, **storage_kwargs)

        self.path = path
        if os.path.exists(self.path) and not os.path.isdir(self.path):
            raise ValueError('path "%s" is not a directory' % path)
        if levels < 0 or levels > 4:
            raise ValueError('%s levels must be between 0 and 4' % self)

        self.queue_path = os.path.join(self.path, 'queue')
        self.schedule_path = os.path.join(self.path, 'schedule')
        self.result_path = os.path.join(self.path, 'results')
        self.levels = levels

        if use_thread_lock:
            self.lock = threading.Lock()
        else:
            self.lock_file = os.path.join(self.path, '.lock')

    def _flush_dir(self, path):
        if os.path.exists(path):
            shutil.rmtree(path)
            os.makedirs(path)

    def enqueue(self, data, priority=None):
        priority = priority or 0
        if priority < 0: raise ValueError('priority must be a positive number')
        if priority > self.MAX_PRIORITY:
            raise ValueError('priority must be <= %s' % self.MAX_PRIORITY)

        with portalocker.Lock(self.lock_file, 'w'):
            if not os.path.exists(self.queue_path):
                os.makedirs(self.queue_path)

            # Encode the filename so that tasks are sorted by priority (desc) and
            # timestamp (asc).
            prefix = '%04x-%012x' % (
                self.MAX_PRIORITY - priority,
                int(time.time() * 1000))

            base = filename = os.path.join(self.queue_path, prefix)
            conflict = 0
            while os.path.exists(filename):
                conflict += 1
                filename = '%s.%03d' % (base, conflict)

            with open(filename, 'wb') as fh:
                fh.write(data)

    def _get_sorted_filenames(self, path):
        if not os.path.exists(path):
            return ()
        return [f for f in sorted(os.listdir(path)) if not f.endswith('.tmp')]

    def dequeue(self):
        with portalocker.Lock(self.lock_file, 'w'):
            filenames = self._get_sorted_filenames(self.queue_path)
            if not filenames:
                return

            filename = os.path.join(self.queue_path, filenames[0])
            tmp_dest = filename + '.tmp'
            os.rename(filename, tmp_dest)

            with open(tmp_dest, 'rb') as fh:
                data = fh.read()
            os.unlink(tmp_dest)
        return data

    def queue_size(self):
        with portalocker.Lock(self.lock_file, 'w'):
            return len(self._get_sorted_filenames(self.queue_path))

    def enqueued_items(self, limit=None):
        with portalocker.Lock(self.lock_file, 'w'):
            filenames = self._get_sorted_filenames(self.queue_path)[:limit]
            accum = []
            for filename in filenames:
                with open(os.path.join(self.queue_path, filename), 'rb') as fh:
                    accum.append(fh.read())
            return accum

    def flush_queue(self):
        with portalocker.Lock(self.lock_file, 'w'):
            self._flush_dir(self.queue_path)

    def _timestamp_to_prefix(self, ts):
        ts = time.mktime(ts.timetuple()) + (ts.microsecond * 1e-6)
        return '%012x' % int(ts * 1000)

    def add_to_schedule(self, data, ts, utc):
        with portalocker.Lock(self.lock_file, 'w'):
            if not os.path.exists(self.schedule_path):
                os.makedirs(self.schedule_path)

            ts_prefix = self._timestamp_to_prefix(ts)
            base = filename = os.path.join(self.schedule_path, ts_prefix)
            conflict = 0
            while os.path.exists(filename):
                conflict += 1
                filename = '%s.%03d' % (base, conflict)

            with open(filename, 'wb') as fh:
                fh.write(data)

    def read_schedule(self, ts):
        with portalocker.Lock(self.lock_file, 'w'):
            prefix = self._timestamp_to_prefix(ts)
            accum = []
            for basename in self._get_sorted_filenames(self.schedule_path):
                if basename[:12] > prefix:
                    break
                filename = os.path.join(self.schedule_path, basename)
                new_filename = filename + '.tmp'
                os.rename(filename, new_filename)
                accum.append(new_filename)

            tasks = []
            for filename in accum:
                with open(filename, 'rb') as fh:
                    tasks.append(fh.read())
                    os.unlink(filename)

        return tasks

    def schedule_size(self):
        with portalocker.Lock(self.lock_file, 'w'):
            return len(self._get_sorted_filenames(self.schedule_path))

    def scheduled_items(self, limit=None):
        with portalocker.Lock(self.lock_file, 'w'):
            filenames = self._get_sorted_filenames(self.schedule_path)[:limit]
            accum = []
            for filename in filenames:
                with open(os.path.join(self.schedule_path, filename), 'rb') as fh:
                    accum.append(fh.read())
            return accum

    def flush_schedule(self):
        with portalocker.Lock(self.lock_file, 'w'):
            self._flush_dir(self.schedule_path)

    def path_for_key(self, key):
        if isinstance(key, str):
            key = key.encode('utf8')
        checksum = hashlib.md5(key).hexdigest()
        prefix = checksum[:self.levels]
        prefix_filename = itertools.chain(prefix, (checksum,))
        return os.path.join(self.result_path, *prefix_filename)

    def put_data(self, key, value, is_result=False):
        if isinstance(key, str):
            key = key.encode('utf8')

        filename = self.path_for_key(key)
        dirname = os.path.dirname(filename)

        with portalocker.Lock(self.lock_file, 'w'):
            if not os.path.exists(dirname):
                os.makedirs(dirname)

            with open(self.path_for_key(key), 'wb') as fh:
                key_len = len(key)
                fh.write(struct.pack('>I', key_len))
                fh.write(key)
                fh.write(value)

    def _unpack_result(self, data):
        key_len, = struct.unpack('>I', data[:4])
        key = data[4:4 + key_len]
        if len(key) != key_len:
            return None, None
        return key, data[4 + key_len:]

    def peek_data(self, key):
        filename = self.path_for_key(key)
        if not os.path.exists(filename):
            return None

        with open(filename, 'rb') as fh:
            _, value = self._unpack_result(fh.read())

        return value

    def pop_data(self, key):
        filename = self.path_for_key(key)

        with portalocker.Lock(self.lock_file, 'w'):
            if not os.path.exists(filename):
                return None

            with open(filename, 'rb') as fh:
                _, value = self._unpack_result(fh.read())

            os.unlink(filename)

        return value

    def has_data_for_key(self, key):
        with portalocker.Lock(self.lock_file, 'w'):
            return os.path.exists(self.path_for_key(key))

    def result_store_size(self):
        with portalocker.Lock(self.lock_file, 'w'):
            return sum(len(filenames) for _, _, filenames in os.walk(self.result_path))

    def result_items(self):
        accum = {}
        with portalocker.Lock(self.lock_file, 'w'):
            for root, _, filenames in os.walk(self.result_path):
                for filename in filenames:
                    path = os.path.join(root, filename)
                    with open(path, 'rb') as fh:
                        key, value = self._unpack_result(fh.read())
                    accum[key] = value
        return accum

    def flush_results(self):
        with portalocker.Lock(self.lock_file, 'w'):
            self._flush_dir(self.result_path)


class TinyDBStorage(BaseStorage):
    def __init__(self, name='TQ', path='huey_tinydb.json'):
        self.db_path = path
        self.name = name

    def encode_data(self, data):
        return base64.b64encode(data).decode('utf-8')

    def decode_data(self, encoded_data):
        return base64.b64decode(encoded_data.encode('utf-8'))

    def enqueue(self, data, priority=None):
        encoded_data = self.encode_data(data)
        with open_db(self.db_path) as db:
            tasks_table = db.table('tasks')
            tasks_table.insert({'data': encoded_data, 'priority': priority})

    def dequeue(self):
        with open_db(self.db_path) as db:
            tasks_table = db.table('tasks')
            Task = Query()
            task = tasks_table.get(Task.data.exists())
            if task:
                tasks_table.remove(doc_ids=[task.doc_id])
                return self.decode_data(task['data'])
        return None

    def unqueue(self, data):
        encoded_data = self.encode_data(data)
        with open_db(self.db_path) as db:
            tasks_table = db.table('tasks')
            Task = Query()
            tasks_table.remove(Task.data == encoded_data)

    def flush_queue(self):
        with open_db(self.db_path) as db:
            tasks_table = db.table('tasks')
            tasks_table.truncate()

    def queue_size(self):
        with open_db(self.db_path) as db:
            tasks_table = db.table('tasks')
            return len(tasks_table)

    def enqueued_items(self, limit=None):
        with open_db(self.db_path) as db:
            tasks_table = db.table('tasks')
            tasks = tasks_table.all()
            if limit:
                tasks = tasks[:limit]
            return [self.decode_data(task['data']) for task in tasks]

    def add_to_schedule(self, data, timestamp):
        encoded_data = self.encode_data(data)
        with open_db(self.db_path) as db:
            schedule_table = db.table('schedule')
            schedule_table.insert({'data': encoded_data, 'timestamp': timestamp.isoformat()})

    def read_schedule(self, timestamp):
        with open_db(self.db_path) as db:
            schedule_table = db.table('schedule')
            Task = Query()
            tasks = schedule_table.search(Task.timestamp <= timestamp.isoformat())
            schedule_table.remove(Task.timestamp <= timestamp.isoformat())
            return [self.decode_data(task['data']) for task in tasks]

    def flush_schedule(self):
        with open_db(self.db_path) as db:
            schedule_table = db.table('schedule')
            schedule_table.truncate()

    def schedule_size(self):
        with open_db(self.db_path) as db:
            schedule_table = db.table('schedule')
            return len(schedule_table)

    def put_data(self, key, value):
        encoded_value = self.encode_data(value)
        with open_db(self.db_path) as db:
            data_table = db.table('data')
            data_table.upsert({'key': key, 'value': encoded_value}, Query().key == key)

    def peek_data(self, key):
        with open_db(self.db_path) as db:
            data_table = db.table('data')
            item = data_table.get(Query().key == key)
            if item:
                return self.decode_data(item['value'])
        return None

    def pop_data(self, key):
        with open_db(self.db_path) as db:
            data_table = db.table('data')
            item = data_table.get(Query().key == key)
            if item:
                data_table.remove(Query().key == key)
                return self.decode_data(item['value'])
        return None

    def has_data_for_key(self, key):
        with open_db(self.db_path) as db:
            data_table = db.table('data')
            return data_table.contains(Query().key == key)
