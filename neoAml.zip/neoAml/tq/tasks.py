from huey import Huey

from tq.storage import TinyDBStorage, FileStorage2


class TinyDBTaskQueue(Huey):
    storage_class = FileStorage2


task_queue = TinyDBTaskQueue(path=r"C:\Users\medzi\Desktop\bnp\neoAml\cache\TQ")


@task_queue.task()
def add(a, b):
    return a + b

from huey import SqliteHuey, crontab
from huey.api import MemoryHuey
from huey.signals import SIGNAL_COMPLETE, SIGNAL_ERROR, SIGNAL_START
from huey.contrib.djhuey import db_task

from database import add_simulation, update_simulation
import uuid
import datetime

huey = MemoryHuey()

@huey.signal(SIGNAL_START)
def task_started(signal, task, *args, **kwargs):
    simulation = {
        'id': str(uuid.uuid4()),
        'name': task.name,
        'description': 'Task started',
        'business_unit': 'FRA',
        'data_start_date': str(datetime.date.today()),
        'data_end_date': '',
        'status': 'started'
    }
    add_simulation(simulation)

@huey.signal(SIGNAL_COMPLETE)
def task_completed(signal, task, *args, **kwargs):
    update_data = {
        'status': 'completed',
        'data_end_date': str(datetime.date.today())
    }
    update_simulation(task.id, update_data)

@huey.signal(SIGNAL_ERROR)
def task_error(signal, task, error, *args, **kwargs):
    update_data = {
        'status': 'error',
        'data_end_date': str(datetime.date.today()),
        'description': str(error)
    }
    update_simulation(task.id, update_data)

@huey.task()
def example_task():
    # Simulate a task
    pass

