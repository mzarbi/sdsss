from flask import Flask, send_from_directory, render_template

app = Flask(__name__, static_folder='frontend/dist/static', template_folder='frontend/dist')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/<path:path>')
def static_proxy(path):
    # Send static files from the Vue's dist directory
    return send_from_directory('frontend/dist', path)

if __name__ == '__main__':
    app.run(debug=True)
